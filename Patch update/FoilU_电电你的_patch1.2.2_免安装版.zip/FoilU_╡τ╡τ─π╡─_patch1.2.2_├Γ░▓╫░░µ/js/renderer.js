(function () {
  'use strict';

  var MAX_MASK_DIM = 6144;
  var MAX_MASK_AREA = 30e6;
  var TILE = 1024;

  var QUAD_VS = [
    'attribute vec2 aPos;',
    'void main() { gl_Position = vec4(aPos, 0.0, 1.0); }'
  ].join('\n');

  var MAIN_FS = [
    'precision highp float;',
    'uniform sampler2D uMask;',
    'uniform sampler2D uBevel;',
    'uniform sampler2D uFoil;',
    'uniform vec2 uDocSize;',
    'uniform vec2 uDocOrigin;',
    'uniform float uRenderScale;',
    'uniform vec2 uTileOrigin;',
    'uniform float uTileH;',
    'uniform vec2 uMaskTexel;',
    'uniform float uDepth;',
    'uniform vec2 uLight;',
    'uniform float uSpec;',
    'uniform float uGloss;',
    'uniform float uPearl;',
    'uniform float uTransparent;',
    'uniform vec3 uPearlColor;',
    'uniform float uAlphaMul;',
    'uniform float uCrease;',
    'uniform vec2 uFoilRepeat;',
    'uniform sampler2D uCut;',
    'uniform float uUseCut;',
    'void main() {',
    '  vec2 outPx = vec2(uTileOrigin.x + gl_FragCoord.x, uTileOrigin.y + uTileH - gl_FragCoord.y);',
    '  vec2 docPx = uDocOrigin + outPx / uRenderScale;',
    '  vec2 uv = docPx / uDocSize;',
    '  float cut = 1.0;',
    '  if (uUseCut > 0.5) {',
    '    cut = texture2D(uCut, uv).a;',
    '    if (cut < 0.004) { gl_FragColor = vec4(0.0); return; }',
    '  }',
    '  float cov = texture2D(uMask, uv).a;',
    '  float bl = texture2D(uBevel, uv).a;',
    '  if (cov < 0.003 && bl < 0.02) { gl_FragColor = vec4(0.0); return; }',
    '  float gx = texture2D(uBevel, uv + vec2(uMaskTexel.x, 0.0)).a - texture2D(uBevel, uv - vec2(uMaskTexel.x, 0.0)).a;',
    '  float gy = texture2D(uBevel, uv + vec2(0.0, uMaskTexel.y)).a - texture2D(uBevel, uv - vec2(0.0, uMaskTexel.y)).a;',
    '  vec2 g = vec2(gx, gy);',
    '  vec3 N = normalize(vec3(g.x * uDepth, g.y * uDepth, 1.0));',
    '  vec3 L = normalize(vec3(uLight, 0.8));',
    '  vec3 H = normalize(L + vec3(0.0, 0.0, 1.0));',
    '  float diff = max(dot(N, L), 0.0);',
    '  float sp = pow(max(dot(N, H), 0.0), uGloss);',
    '  vec2 uvF = docPx / uFoilRepeat;',
    '  vec4 fo = texture2D(uFoil, uvF);',
    '  float flo = dot(fo.rgb, vec3(0.299, 0.587, 0.114));',
    '  vec3 col = fo.rgb;',
    '  if (uPearl > 0.5) {',
    '    col = uPearlColor * (0.32 + 0.92 * flo) + (fo.rgb - vec3(flo)) * 0.35;',
    '  }',
    '  float shade = 0.42 + 0.62 * diff;',
    '  float glint = pow(clamp(flo, 0.0, 1.0), 4.0) * 0.45;',
    '  float fres = pow(1.0 - N.z, 3.0);',
    '  vec3 lit = col * (shade + glint * uSpec);',
    '  lit += vec3(1.0) * sp * uSpec;',
    '  lit += (col + vec3(0.25)) * fres * 0.35;',
    '  float alpha = cov;',
    '  if (uTransparent > 0.5) {',
    '    float reflA = clamp(sp * uSpec * 1.4 + fres * 0.7 + glint * 0.5, 0.0, 1.0);',
    '    vec3 reflCol = vec3(0.80, 0.87, 0.96);',
    '    lit = mix(reflCol, lit, clamp(fo.a * 1.35, 0.0, 1.0));',
    '    alpha = cov * max(fo.a, reflA * 0.85);',
    '  }',
    '  alpha *= uAlphaMul;',
    '  if (uCrease > 0.001) {',
    '    float outside = 1.0 - smoothstep(0.3, 0.7, cov);',
    '    float band = smoothstep(0.02, 0.4, bl);',
    '    float lit2 = 0.5 + 0.5 * dot(normalize(g + vec2(0.0001, 0.0001)), uLight);',
    '    float cA = outside * band * uCrease * 0.5;',
    '    if (cA > 0.001) {',
    '      vec3 cCol = mix(vec3(0.05, 0.04, 0.03), vec3(0.98, 0.95, 0.90), lit2);',
    '      float a2 = cA * (1.0 - alpha);',
    '      float outA = alpha + a2;',
    '      lit = (lit * alpha + cCol * a2) / max(outA, 0.0001);',
    '      alpha = outA;',
    '    }',
    '  }',
    '  alpha *= cut;',
    '  float dith = fract(sin(dot(docPx, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;',
    '  lit += dith * (1.0 / 255.0);',
    '  gl_FragColor = vec4(clamp(lit, 0.0, 1.0), clamp(alpha, 0.0, 1.0));',
    '}'
  ].join('\n');

  var BLUR_VS = [
    'attribute vec2 aPos;',
    'varying vec2 vUv;',
    'uniform vec4 uRect;',
    'void main() {',
    '  vUv = uRect.xy + (aPos * 0.5 + 0.5) * uRect.zw;',
    '  gl_Position = vec4(aPos, 0.0, 1.0);',
    '}'
  ].join('\n');

  var BLUR_FS = [
    'precision highp float;',
    'varying vec2 vUv;',
    'uniform sampler2D uTex;',
    'uniform vec2 uStep;',
    'void main() {',
    '  vec4 s = vec4(0.0);',
    '  float t = 0.0;',
    '  for (int i = -9; i <= 9; i++) {',
    '    float fi = float(i);',
    '    float w = exp(-fi * fi / 18.0);',
    '    s += texture2D(uTex, vUv + uStep * fi) * w;',
    '    t += w;',
    '  }',
    '  gl_FragColor = s / t;',
    '}'
  ].join('\n');

  function compile(gl, type, src) {
    var sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      throw new Error('shader: ' + gl.getShaderInfoLog(sh));
    }
    return sh;
  }

  function makeProgram(gl, vsSrc, fsSrc) {
    var p = gl.createProgram();
    gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vsSrc));
    gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fsSrc));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      throw new Error('link: ' + gl.getProgramInfoLog(p));
    }
    var u = {};
    var n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (var i = 0; i < n; i++) {
      var info = gl.getActiveUniform(p, i);
      if (info) u[info.name] = gl.getUniformLocation(p, info.name);
    }
    var a = {};
    var m = gl.getProgramParameter(p, gl.ACTIVE_ATTRIBUTES);
    for (var j = 0; j < m; j++) {
      var ai = gl.getActiveAttrib(p, j);
      if (ai) a[ai.name] = gl.getAttribLocation(p, ai.name);
    }
    return { prog: p, u: u, a: a };
  }

  function FoilRenderer() {
    this.glCanvas = document.createElement('canvas');
    this.glCanvas.width = TILE;
    this.glCanvas.height = TILE;
    var opts = { alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: true, antialias: false, depth: false, stencil: false };
    this.gl = this.glCanvas.getContext('webgl2', opts) ||
      this.glCanvas.getContext('webgl', opts) ||
      this.glCanvas.getContext('experimental-webgl', opts);
    if (!this.gl) throw new Error('当前环境不支持 WebGL');
    var gl = this.gl;
    this.isGL2 = !!(window.WebGL2RenderingContext && gl instanceof window.WebGL2RenderingContext);
    this.maxTex = Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE) || 4096, 8192);
    this.anisoExt = gl.getExtension('EXT_texture_filter_anisotropic') ||
      gl.getExtension('WEBKIT_EXT_texture_filter_anisotropic') ||
      gl.getExtension('MOZ_EXT_texture_filter_anisotropic');
    this.main = makeProgram(gl, QUAD_VS, MAIN_FS);
    this.blur = makeProgram(gl, BLUR_VS, BLUR_FS);
    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.disable(gl.BLEND);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    this.docW = 0;
    this.docH = 0;
    this.maskScale = 1;
    this.maskW = 0;
    this.maskH = 0;
    this.maskTex = null;
    this.bevelTex = null;
    this.blurSigma = -1;
    this.foilTex = null;
    this.foilReady = false;
    this.rtA = null;
    this.rtB = null;
    this.cutTex = null;
    this.hasCut = false;
  }

  FoilRenderer.prototype.setCut = function (canvas) {
    var gl = this.gl;
    if (this.cutTex) {
      gl.deleteTexture(this.cutTex);
      this.cutTex = null;
    }
    this.hasCut = false;
    if (!canvas) return;
    this.cutTex = this._uploadCanvas(canvas, gl.CLAMP_TO_EDGE, this.isGL2);
    this.hasCut = true;
  };

  FoilRenderer.prototype._bindQuad = function (loc) {
    var gl = this.gl;
    if (loc === undefined || loc === null || loc < 0) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  };

  FoilRenderer.prototype._uploadCanvas = function (canvas, wrapMode, mips) {
    var gl = this.gl;
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapMode);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapMode);
    if (mips) {
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    } else {
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    }
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    if (this.anisoExt) {
      gl.texParameterf(gl.TEXTURE_2D, this.anisoExt.TEXTURE_MAX_ANISOTROPY_EXT, 8);
    }
    return tex;
  };

  FoilRenderer.prototype.setFoil = function (image, mirror) {
    var gl = this.gl;
    var s = 2048;
    var c = document.createElement('canvas');
    c.width = s;
    c.height = s;
    var ctx = c.getContext('2d');
    ctx.drawImage(image, 0, 0, s, s);
    if (this.foilTex) gl.deleteTexture(this.foilTex);
    this.foilTex = this._uploadCanvas(c, mirror ? gl.MIRRORED_REPEAT : gl.REPEAT, true);
    this.foilReady = true;
  };

  FoilRenderer.prototype._makeRT = function (w, h) {
    var gl = this.gl;
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    var fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    var st = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (st !== gl.FRAMEBUFFER_COMPLETE) {
      gl.deleteFramebuffer(fb);
      gl.deleteTexture(tex);
      throw new Error('FBO incomplete: ' + st);
    }
    return { tex: tex, fb: fb, w: w, h: h };
  };

  FoilRenderer.prototype._disposeMask = function () {
    var gl = this.gl;
    if (this.maskTex) { gl.deleteTexture(this.maskTex); this.maskTex = null; }
    if (this.bevelTex) { gl.deleteTexture(this.bevelTex); this.bevelTex = null; }
    if (this.rtA) { gl.deleteTexture(this.rtA.tex); gl.deleteFramebuffer(this.rtA.fb); this.rtA = null; }
    if (this.rtB) { gl.deleteTexture(this.rtB.tex); gl.deleteFramebuffer(this.rtB.fb); this.rtB = null; }
  };

  FoilRenderer.prototype._buildMask = function (image, mw, mh) {
    var gl = this.gl;
    var c = document.createElement('canvas');
    c.width = mw;
    c.height = mh;
    var ctx = c.getContext('2d');
    ctx.drawImage(image, 0, 0, mw, mh);
    this._disposeMask();
    this.maskW = mw;
    this.maskH = mh;
    this.maskTex = this._uploadCanvas(c, gl.CLAMP_TO_EDGE, this.isGL2);
    this.rtA = this._makeRT(mw, mh);
    this.rtB = this._makeRT(mw, mh);
    this.blurSigma = -1;
  };

  FoilRenderer.prototype.setMask = function (image, docW, docH, srcW, srcH) {
    var sw = srcW || docW;
    var sh = srcH || docH;
    var capDim = Math.min(this.maxTex, MAX_MASK_DIM);
    var capArea = MAX_MASK_AREA;
    var s = Math.min(1, capDim / sw, capDim / sh, Math.sqrt(capArea / (sw * sh)));
    while (true) {
      var mw = Math.max(4, Math.round(sw * s));
      var mh = Math.max(4, Math.round(sh * s));
      try {
        this._buildMask(image, mw, mh);
        this.docW = docW;
        this.docH = docH;
        this.maskScale = mw / docW;
        return { w: mw, h: mh, scale: mw / docW };
      } catch (e) {
        if (s < 0.05) throw e;
        s *= 0.5;
      }
    }
  };

  FoilRenderer.prototype._computeBevel = function (sigma) {
    var gl = this.gl;
    var sig = Math.max(0.6, Math.min(sigma, 80));
    if (this.bevelTex && Math.abs(this.blurSigma - sig) < 0.01) return;
    this.blurSigma = sig;
    var p = this.blur;
    gl.useProgram(p.prog);
    this._bindQuad(p.a.aPos);
    gl.uniform4f(p.u.uRect, 0, 0, 1, 1);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.maskTex);
    gl.uniform1i(p.u.uTex, 0);
    var step = sig / 3.0;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.rtA.fb);
    gl.viewport(0, 0, this.maskW, this.maskH);
    gl.uniform2f(p.u.uStep, step / this.maskW, 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.rtB.fb);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.rtA.tex);
    gl.uniform2f(p.u.uStep, 0, step / this.maskH);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.bevelTex = this.rtB.tex;
    if (this.isGL2) {
      gl.bindTexture(gl.TEXTURE_2D, this.bevelTex);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    }
  };

  FoilRenderer.prototype.render = function (outCtx, outW, outH, rect, params) {
    var gl = this.gl;
    if (!this.maskTex) throw new Error('尚未加载图层蒙版');
    if (!this.foilReady) throw new Error('尚未加载烫材贴图');
    var sigma = params.depthMm * params.pxPerMm * this.maskScale * 0.45;
    var sigmaClamped = Math.max(0.6, Math.min(sigma, 80));
    this._computeBevel(sigma);
    var p = this.main;
    gl.useProgram(p.prog);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.maskTex);
    gl.uniform1i(p.u.uMask, 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.bevelTex);
    gl.uniform1i(p.u.uBevel, 1);
    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, this.foilTex);
    gl.uniform1i(p.u.uFoil, 2);
    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, this.cutTex || this.maskTex);
    gl.uniform1i(p.u.uCut, 3);
    var useCut = params.useCut && this.hasCut && this.cutTex;
    gl.uniform1f(p.u.uUseCut, useCut ? 1 : 0);
    gl.uniform2f(p.u.uDocSize, this.docW, this.docH);
    gl.uniform2f(p.u.uDocOrigin, rect.x, rect.y);
    gl.uniform1f(p.u.uRenderScale, outW / rect.w);
    gl.uniform2f(p.u.uMaskTexel, 1 / this.maskW, 1 / this.maskH);
    gl.uniform1f(p.u.uDepth, params.relief * sigmaClamped * 0.55);
    var ang = params.light * Math.PI / 180;
    gl.uniform2f(p.u.uLight, Math.cos(ang), -Math.sin(ang));
    gl.uniform1f(p.u.uSpec, params.spec);
    gl.uniform1f(p.u.uGloss, params.gloss || 36);
    gl.uniform1f(p.u.uPearl, params.pearl ? 1 : 0);
    gl.uniform1f(p.u.uTransparent, params.transparent ? 1 : 0);
    var pc = params.pearlColor || [255, 255, 255];
    gl.uniform3f(p.u.uPearlColor, pc[0] / 255, pc[1] / 255, pc[2] / 255);
      var alphaMul = 1;
      var pearlMul = (typeof params.pearlAlpha === 'number') ? params.pearlAlpha : 0.6;
      var tranMul = (typeof params.tranAlpha === 'number') ? params.tranAlpha : 0.4;
      if (params.pearl) alphaMul *= params.pearlWhite ? pearlMul * (0.35 / 0.6) : pearlMul;
      if (params.transparent && !params.noDim) alphaMul *= tranMul;
      gl.uniform1f(p.u.uAlphaMul, alphaMul);
    gl.uniform1f(p.u.uCrease, params.crease);
    var repeatPx = Math.max(2, 30 * params.pxPerMm / Math.max(0.05, params.texScale));
    gl.uniform2f(p.u.uFoilRepeat, repeatPx, repeatPx);
    this._bindQuad(p.a.aPos);
    for (var y = 0; y < outH; y += TILE) {
      var h = Math.min(TILE, outH - y);
      for (var x = 0; x < outW; x += TILE) {
        var w = Math.min(TILE, outW - x);
        gl.viewport(0, 0, w, h);
        gl.uniform2f(p.u.uTileOrigin, x, y);
        gl.uniform1f(p.u.uTileH, h);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        var px = new Uint8Array(w * h * 4);
        gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
        var img = outCtx.createImageData(w, h);
        var data = img.data;
        var row = w * 4;
        for (var ry = 0; ry < h; ry++) {
          var src = (h - 1 - ry) * row;
          data.set(px.subarray(src, src + row), ry * row);
        }
        outCtx.putImageData(img, x, y);
      }
    }
  };

  window.FoilRenderer = FoilRenderer;
})();
