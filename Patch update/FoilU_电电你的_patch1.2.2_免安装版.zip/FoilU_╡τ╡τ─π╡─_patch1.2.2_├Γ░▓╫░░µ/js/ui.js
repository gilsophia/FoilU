(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var cep = window.FoilUCep;
  var ps = window.FoilUPs;

  var DEFAULT_PARAMS = {
    depthMm: 0.3,
    relief: 0.8,
    spec: 0.45,
    light: 135,
    texScale: 0.5,
    crease: 0.45,
    gloss: 36,
    pearlAlpha: 0.8,
    tranAlpha: 0.65,
    alphaV: 2
  };

  var MATERIAL_PHYSICAL_MM = {
    '银猫眼': 150,
    '6804蓝': 150,
    '晨辉-L04-02银万花筒': 150,
    '金穗-L04-81-透明万花筒': 150,
    '晨辉-L8-520透明爱心': 150,
    '金穗-L35-11-金火焰': 150,
    '金穗-VG-4-金': 150,
    '晨辉-L66B1青砖': 150,
    '臻彩-金幻彩': 150,
    '金橘皮': 150,
    '金烧箔': 150,
    '金穗-银火焰': 150,
    '银橘皮': 150
  };

  var state = {
    view: 'main',
    materialPath: '',
    materialName: '',
    materialImg: null,
    flatImg: null,
    cut: false,
    cutPattern: '模切|刀线',
    cutMode: 'auto',
    cutInfo: null,
    cutCanvas: null,
    autoProcess: true,
    seamFeather: 0.18,
    processMode: 'fusion',
    customMeta: {},
    pearl: false,
    transparent: false,
    pearlColor: { r: 255, g: 255, b: 255 },
    params: JSON.parse(JSON.stringify(DEFAULT_PARAMS)),
    zoom: 'fit',
    doc: null,
    session: null,
    stale: false,
    busy: false,
    autoTried: false,
    builtin: [],
    custom: [],
    thumbCache: {},
    stars: [],
    libTag: 'all',
    libBrand: '',
    libSearch: '',
    matScales: {},
    layers: [],
    layerRoles: {},
    layerPrio: {},
    layerMat: {},
    layerMatSource: {},
    layerTouched: {},
    autoMatchedKey: '',
    matPool: [],
    savedLayerAssign: null,
    viewRotAngle: 0,
    viewRotOffset: 0,
    viewRotInfo: null,
    maskCov: null
  };

  var renderer = null;
  var wheel = null;
  var renderTimer = 0;
  var renderCanvas = document.createElement('canvas');
  var renderCtx = renderCanvas.getContext('2d');
  var thumbQueue = [];

  var lastMsg = { text: '就绪', kind: 'info', time: 0 };

  function status(text, kind) {
    lastMsg = { text: text, kind: kind || 'info', time: Date.now() };
    renderStatus();
  }

  function renderStatus() {
    $('statusText').textContent = lastMsg.text;
    var dot = $('statusDot');
    dot.className = lastMsg.kind === 'ok' ? 'ok' : lastMsg.kind === 'err' ? 'err' : lastMsg.kind === 'busy' ? 'busy' : '';
  }

  function setBusy(b) {
    state.busy = b;
    $('btnApply').disabled = b;
    $('btnRefresh').disabled = b;
  }

  function pad2(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  function mmOf(px, dpi) {
    return ((px / (dpi || 72)) * 25.4).toFixed(1);
  }

  function materialDefaultScale(name) {
    var mm = MATERIAL_PHYSICAL_MM[name] || 60;
    return 30 / mm;
  }

  function userScaleFor(name) {
    var v = state.matScales[name];
    if (typeof v === 'number' && v > 0.01 && v < 10) return v;
    return materialDefaultScale(name);
  }

  function syncScaleUI() {
    $('rngScale').value = Math.round(state.params.texScale * 100);
    $('valScale').textContent = (30 / state.params.texScale).toFixed(1) + 'mm';
  }

  function syncSeamUI() {
    $('autoProcess').checked = state.autoProcess;
    $('rngSeamFeather').value = Math.round(state.seamFeather * 100);
    $('valSeamFeather').textContent = Math.round(state.seamFeather * 100) + '%';
    $('processMode').value = state.processMode;
    $('processOpts').style.display = state.autoProcess ? '' : 'none';
    $('seamFeatherRow').style.display = (state.autoProcess && state.processMode === 'fusion') ? '' : 'none';
    $('procCrop').disabled = !state.autoProcess;
    $('procDering').disabled = !state.autoProcess;
  }

  function canvasAlphaBBox(canvas) {
    var w = canvas.width;
    var h = canvas.height;
    var ctx = canvas.getContext('2d');
    var data = ctx.getImageData(0, 0, w, h).data;
    var minX = w;
    var minY = h;
    var maxX = -1;
    for (var y = 0; y < h; y++) {
      var row = y * w * 4;
      for (var x = 0; x < w; x++) {
        if (data[row + x * 4 + 3] > 2) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
        }
      }
    }
    if (maxX < 0) return null;
    return { x0: minX, y0: minY };
  }

  var GEN_MARK = '\u200B';

  function timestampName() {
    var d = new Date();
    return String(d.getFullYear()).slice(-2) + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '-' +
      pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds());
  }

  function buildDiagnostics() {
    var d = new Date();
    var lines = [];
    lines.push('FoilU/电电你的 诊断信息 ' + d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
      ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()));
    lines.push('状态：' + lastMsg.text);
    if (state.doc) {
      lines.push('文档：' + state.doc.docName + ' | ' + state.doc.widthPx + 'x' + state.doc.heightPx + 'px | ' +
        state.doc.dpi + 'dpi | ' + mmOf(state.doc.widthPx, state.doc.dpi) + 'x' + mmOf(state.doc.heightPx, state.doc.dpi) + 'mm | ' +
        (state.doc.mode || '?') + ' ' + (state.doc.bits || '?') + 'bit | 选中：' + state.doc.layerName);
      if (state.doc.psv) lines.push('Photoshop：' + state.doc.psv);
    } else {
      lines.push('文档：未检测到');
    }
    lines.push('烫材：' + (state.materialName || '无') + ' | 珠光：' + (state.pearl ? '开' : '关') + ' | 透明：' + (state.transparent ? '开' : '关'));
    lines.push('视图旋转：angle=' + (state.viewRotAngle || 0) + ' 偏移=' + (state.viewRotOffset || 0) +
      ' 来源=' + (state.viewRotInfo ? (state.viewRotInfo.src || '未找到') : '-') +
      ' 候选=' + (state.viewRotInfo ? (state.viewRotInfo.keys || '无') : '-'));
    lines.push('置入方式：' + (state.placeMode || '未使用') + ' | 蒙版覆盖：' + (state.maskCov == null ? '-' : Math.round(state.maskCov * 100) + '%'));
    lines.push('刀线：' + (state.cut ? '开' : '关') + ' | 匹配「' + state.cutPattern + '」 | 模式：' +
      (state.cutMode === 'auto' ? '自动' : state.cutMode === 'line' ? '描边（手动）' : '填充（手动）') + ' | ' +
      (state.cutInfo ? (state.cutInfo.found ? '已识别：' + (state.cutInfo.names || '') + '（' + (state.cutInfo.mode === 'fill' ? '填充' : '轮廓') + '，覆盖率' + Math.round((state.cutInfo.coverage || 0) * 100) + '%）' : '未找到匹配图层') : '未识别'));
    var p = state.params;
    lines.push('参数：凹陷=' + p.depthMm.toFixed(2) + 'mm 立体=' + Math.round(p.relief * 100) + '% 反光=' +
      Math.round(p.spec * 100) + '% 光照=' + p.light + '° 缩放=' + Math.round(p.texScale * 100) + '% 压痕=' +
      Math.round(p.crease * 100) + '%');
    if (renderer && renderer.gl) {
      try {
        lines.push('渲染：WebGL' + (renderer.isGL2 ? '2' : '1') + ' | 蒙版 ' + renderer.maskW + 'x' + renderer.maskH + ' | 上限 ' + renderer.maxTex);
      } catch (e) {}
    } else {
      lines.push('渲染：WebGL 不可用');
    }
    lines.push('环境：' + navigator.userAgent);
    return lines.join('\n');
  }

  function copyText(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    ta.style.opacity = '0';
    ta.style.userSelect = 'text';
    ta.style.webkitUserSelect = 'text';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    var ok = false;
    try {
      ok = document.execCommand('copy');
    } catch (e) {}
    document.body.removeChild(ta);
    return ok;
  }

  function onCopyStatus() {
    var ok = copyText(buildDiagnostics());
    var b = $('btnCopyStatus');
    b.textContent = ok ? '已复制' : '复制失败';
    if (b._timer) clearTimeout(b._timer);
    b._timer = setTimeout(function () {
      b.textContent = '复制';
    }, 1200);
  }

  function loadState() {
    try {
      var s = JSON.parse(localStorage.getItem('foilu.state') || '{}');
      if (s.params) {
        for (var k in DEFAULT_PARAMS) {
          if (typeof s.params[k] === 'number') state.params[k] = s.params[k];
        }
        if (s.params.alphaV !== 2) {
          state.params.pearlAlpha = DEFAULT_PARAMS.pearlAlpha;
          state.params.tranAlpha = DEFAULT_PARAMS.tranAlpha;
        }
        state.params.alphaV = 2;
        state.params.pearlAlpha = Math.max(0.1, Math.min(1, state.params.pearlAlpha));
        state.params.tranAlpha = Math.max(0.1, Math.min(1, state.params.tranAlpha));
      }
      if (s.materialPath) state.materialPath = s.materialPath;
      if (s.pearlColor) {
        state.pearlColor = { r: s.pearlColor.r | 0, g: s.pearlColor.g | 0, b: s.pearlColor.b | 0 };
      }
      if (typeof s.pearl === 'boolean') state.pearl = s.pearl;
      if (typeof s.transparent === 'boolean') state.transparent = s.transparent;
      if (s.zoom === 'fit' || s.zoom === '100' || s.zoom === '200') state.zoom = s.zoom;
      if (typeof s.cut === 'boolean') state.cut = s.cut;
      if (typeof s.cutPattern === 'string' && s.cutPattern) state.cutPattern = s.cutPattern;
      if (s.cutMode === 'auto' || s.cutMode === 'line' || s.cutMode === 'fill') state.cutMode = s.cutMode;
      if (typeof s.autoProcess === 'boolean') state.autoProcess = s.autoProcess;
      if (typeof s.libTag === 'string' && s.libTag) state.libTag = s.libTag;
      if (typeof s.libBrand === 'string') state.libBrand = s.libBrand;
      if (s.matScales && typeof s.matScales === 'object') {
        var ms = s.matScales;
        for (var mk in ms) {
          if (ms.hasOwnProperty(mk) && typeof ms[mk] === 'number') state.matScales[mk] = ms[mk];
        }
      }
      if (s.layerAssign && Object.prototype.toString.call(s.layerAssign) === '[object Array]') state.savedLayerAssign = s.layerAssign;
      if (typeof s.viewRotOffset === 'number' && isFinite(s.viewRotOffset)) state.viewRotOffset = s.viewRotOffset;
      if (typeof s.seamFeather === 'number' && s.seamFeather >= 0.05 && s.seamFeather <= 0.4) state.seamFeather = s.seamFeather;
      if (s.processMode === 'fusion' || s.processMode === 'mirror') state.processMode = s.processMode;
    } catch (e) {}
  }

  function saveState() {
    try {
      localStorage.setItem('foilu.state', JSON.stringify({
        params: state.params,
        materialPath: state.materialPath,
        pearlColor: state.pearlColor,
        pearl: state.pearl,
        transparent: state.transparent,
        zoom: state.zoom,
        cut: state.cut,
        cutPattern: state.cutPattern,
        cutMode: state.cutMode,
        autoProcess: state.autoProcess,
        seamFeather: state.seamFeather,
        processMode: state.processMode,
        libTag: state.libTag,
        libBrand: state.libBrand,
        matScales: state.matScales,
        layerAssign: (function () {
          var arr = [];
          for (var i = 0; i < state.layers.length; i++) {
            var L = state.layers[i];
            var r = state.layerRoles[L.id] || 'ignore';
            var p = state.layerPrio[L.id] || 1;
            var m2 = state.layerMat[L.id] || '';
            if (r !== 'ignore' || m2 || state.layerTouched[L.id]) {
              arr.push({ id: L.id, name: L.name, role: r, prio: p, mat: m2, matSource: state.layerMatSource[L.id] || '', touched: !!state.layerTouched[L.id] });
            }
          }
          state.savedLayerAssign = arr;
          return arr;
        })(),
        viewRotOffset: state.viewRotOffset
      }));
    } catch (e) {}
  }

  function scanLibrary() {
    var builtinDir = (cep.nativePath || '') + '/materials';
    state.builtin = cep.listImages(builtinDir).map(function (f) {
      return { name: f.replace(/\.[^.]+$/, ''), file: f, path: builtinDir + '/' + f, custom: false };
    });
    state.custom = cep.listImages(cep.customDir).map(function (f) {
      return { name: f.replace(/\.[^.]+$/, ''), file: f, path: cep.customDir + '/' + f, custom: true };
    });
    state.customMeta = cep.readMeta();
    state.stars = [];
    if (cep.readStars) {
      try {
        var st = cep.readStars();
        if (Object.prototype.toString.call(st) === '[object Array]') state.stars = st;
      } catch (e2) {}
    }
  }

  function findMaterial(path) {
    var all = state.builtin.concat(state.custom);
    for (var i = 0; i < all.length; i++) {
      if (all[i].path === path) return all[i];
    }
    return null;
  }

  function hx(v) {
    var s = v.toString(16).toUpperCase();
    return s.length < 2 ? '0' + s : s;
  }

  function pearlHex() {
    return '#' + hx(state.pearlColor.r) + hx(state.pearlColor.g) + hx(state.pearlColor.b);
  }

  function updatePearlSwatches() {
    var css = 'rgb(' + state.pearlColor.r + ',' + state.pearlColor.g + ',' + state.pearlColor.b + ')';
    $('pearlDot').style.background = css;
    $('fxPearlSwatch').style.background = css;
    $('wheelPreview').style.background = css;
    $('valPearlColor').textContent = pearlHex();
    $('wheelHex').textContent = pearlHex();
  }

  function updateSpecialLabels() {
    var pe = $('specialPearlPct');
    if (pe) pe.textContent = '当前 ' + Math.round(state.params.pearlAlpha * 100) + '%';
    var tr = $('specialTransparentPct');
    if (tr) tr.textContent = '当前 ' + Math.round(state.params.tranAlpha * 100) + '%';
  }

  function syncSpecialUI() {
    updatePearlSwatches();
    updateSpecialLabels();
  }

  var THUMB_CONC = 3;
  var thumbActive = 0;

  function thumbKey(path) {
    var name = String(path).split('/').pop();
    var size = 0;
    try { size = cep.fs.statSync(path).size; } catch (e) {}
    return name.replace(/[\\/:*?"<>|]/g, '_') + '_' + size;
  }

  function queueThumb(path, imgEl) {
    imgEl.decoding = 'async';
    thumbQueue.push([path, imgEl]);
    pumpThumbs();
  }

  function pumpThumbs() {
    while (thumbActive < THUMB_CONC && thumbQueue.length) {
      var job = thumbQueue.shift();
      var cached = state.thumbCache[job[0]];
      if (cached) {
        job[1].src = cached;
        continue;
      }
      thumbActive++;
      (function (jp) {
        var key = thumbKey(jp[0]);
        cep.readThumb(key, function (hit) {
          if (hit) {
            state.thumbCache[jp[0]] = hit;
            jp[1].src = hit;
            thumbActive--;
            pumpThumbs();
            return;
          }
          cep.imageDataUrl(jp[0], function (url) {
            if (!url) {
              thumbActive--;
              pumpThumbs();
              return;
            }
            var img = new Image();
            img.decoding = 'async';
            img.onload = function () {
              try {
                var c = document.createElement('canvas');
                c.width = 96;
                c.height = 96;
                c.getContext('2d').drawImage(img, 0, 0, 96, 96);
                c.toBlob(function (blob) {
                  if (!blob) {
                    thumbActive--;
                    pumpThumbs();
                    return;
                  }
                  var fr = new FileReader();
                  fr.onload = function () {
                    var dataUrl = fr.result;
                    state.thumbCache[jp[0]] = dataUrl;
                    jp[1].src = dataUrl;
                    try {
                      var b64 = String(dataUrl).split(',')[1];
                      var bin = atob(b64);
                      var bytes = new Uint8Array(bin.length);
                      for (var bi = 0; bi < bin.length; bi++) bytes[bi] = bin.charCodeAt(bi);
                      cep.writeThumb(key, bytes);
                    } catch (eW) {}
                    thumbActive--;
                    pumpThumbs();
                  };
                  fr.readAsDataURL(blob);
                }, 'image/webp', 0.8);
              } catch (e) {
                thumbActive--;
                pumpThumbs();
              }
            };
            img.onerror = function () {
              thumbActive--;
              pumpThumbs();
            };
            img.src = url;
          });
        });
      })(job);
    }
  }

  function rebuildMaterialUI() {
    if (!findMaterial(state.materialPath)) {
      state.materialPath = state.builtin.length ? state.builtin[0].path : (state.custom.length ? state.custom[0].path : '');
    }
    $('libCount').textContent = '（' + state.builtin.length + ' 款内置' + (state.custom.length ? ' + ' + state.custom.length + ' 款自定义' : '') + '）';
    buildLibBrands();
    buildLibTags();
    buildLibGrid();
    buildCustomList();
    buildRandomFilters();
  }

  var TAG_DEFS = [
    { id: 'star', label: '★ 星标', keys: null },
    { id: 'all', label: '全部', keys: null },
    { id: 'jin', label: '金', keys: ['金'] },
    { id: 'yin', label: '银', keys: ['银'] },
    { id: 'tou', label: '透明', keys: ['透明'] },
    { id: 'zhu', label: '珠光', keys: ['珠光'] },
    { id: 'hong', label: '红', keys: ['红'] },
    { id: 'fen', label: '粉', keys: ['粉', '桃', '玫'] },
    { id: 'lv', label: '绿', keys: ['绿'] },
    { id: 'lan', label: '蓝', keys: ['蓝', '兰', '青'] },
    { id: 'zi', label: '紫', keys: ['紫'] },
    { id: 'huang', label: '黄', keys: ['黄'] },
    { id: 'cheng', label: '橙', keys: ['橙'] },
    { id: 'tong', label: '古铜', keys: ['古铜', '咖啡', '棕', '铜'] },
    { id: 'hei', label: '黑', keys: ['黑'] },
    { id: 'bai', label: '白', keys: ['白', 'White'] },
    { id: 'hui', label: '灰', keys: ['灰'] },
    { id: 'cai', label: '彩', keys: ['彩虹', '幻彩', '七彩', '镭射', '彩云', '云'] },
    { id: 'custom', label: '自定义', keys: null },
    { id: 'other', label: '其他', keys: null }
  ];

  var BRAND_WORDS = ['金穗', '金昌泰', '金合彩', '金彩虹', '臻彩', '库尔兹', 'KURZ', '卓鑫', '皇泰烫金', '鑫昌泰', '恒昌', '晨辉', '辉煌', '殷帆', '升盛'];

  var LIB_BRANDS = ['皇泰烫金', '金昌泰', '金合彩', '金彩虹', '金穗', '臻彩', '库尔兹', 'KURZ', '卓鑫', '鑫昌泰', '恒昌', '晨辉', '辉煌', '殷帆', '升盛'];

  function brandOf(name) {
    var n = String(name || '');
    for (var i = 0; i < LIB_BRANDS.length; i++) {
      if (n.indexOf(LIB_BRANDS[i]) === 0) return LIB_BRANDS[i];
    }
    return '';
  }

  function stripBrands(name) {
    var n = String(name || '');
    for (var i = 0; i < BRAND_WORDS.length; i++) {
      var w = BRAND_WORDS[i];
      if (!w) continue;
      while (n.indexOf(w) === 0) n = n.substring(w.length);
      n = n.split('（' + w + '）').join('');
      n = n.split('(' + w + ')').join('');
      n = n.split('[' + w + ']').join('');
    }
    return n;
  }

  var MANUAL_TAGS = {
    '殷帆-20-03LB': ['yin'],
    '殷帆-20-114': ['cai'],
    'H3-703': ['jin', 'huang'],
    '恒昌-HC-Y19507': ['lan'],
    '金穗-J302-3': ['zi', 'cai'],
    '卓鑫-K-8812死鱼': ['yin', 'cai'],
    '晨辉-L51C1': ['hong'],
    '卓鑫-YM0118': ['huang'],
    '卓鑫-ZX-404': ['cheng'],
    '晨辉-L6-003万花筒A': ['lan', 'zi'],
    '库尔兹-LP岩浆': ['lan', 'cai'],
    '库尔兹-SB彩纸': ['cai'],
    '库尔兹-SB晨露': ['bai'],
    '库尔兹-SB丛林碎片': ['cai'],
    '库尔兹-SB反射碎面': ['cai'],
    '库尔兹-SB光波': ['cai'],
    '库尔兹-SB虹膜曲线': ['yin'],
    '库尔兹-SB箭头': ['cai'],
    '库尔兹-SB交叉光带': ['cai'],
    '库尔兹-SB霓虹': ['cai'],
    '库尔兹-SB爬虫鳞纹': ['yin'],
    '库尔兹-SB闪烁': ['lan'],
    '库尔兹-SB水纹': ['lan'],
    '库尔兹-SB撕裂线': ['lan'],
    '库尔兹-SB网点': ['cai'],
    '库尔兹-SB心形': ['cai'],
    '库尔兹-SB印象矩形': ['lan'],
    '库尔兹-SB圆点': ['cai'],
    '库尔兹-冰川蓝': ['lan'],
    '库尔兹-基础圆点螺旋': ['yin'],
    '库尔兹-三角矩阵': ['yin'],
    '库尔兹-碎裂': ['cai'],
    '库尔兹-太空': ['cai'],
    '库尔兹-无限棱镜': ['yin']
  };

  function tagsOf(name) {
    var manual = MANUAL_TAGS[name];
    if (manual) return manual.slice();
    name = stripBrands(name);
    var out = [];
    for (var i = 0; i < TAG_DEFS.length; i++) {
      var t = TAG_DEFS[i];
      if (!t.keys) continue;
      for (var k = 0; k < t.keys.length; k++) {
        if (name.indexOf(t.keys[k]) >= 0) {
          out.push(t.id);
          break;
        }
      }
    }
    return out;
  }

  function findMaterialByName(name) {
    var all = state.builtin.concat(state.custom);
    for (var i = 0; i < all.length; i++) {
      if (all[i].name === name) return all[i];
    }
    return null;
  }

  function buildLibTags() {
    var box = $('libTags');
    if (!box) return;
    box.innerHTML = '';
    var lbl = document.createElement('span');
    lbl.className = 'tagRowLabel';
    lbl.textContent = '色彩';
    box.appendChild(lbl);
    var all = state.builtin.concat(state.custom);
    var counts = {};
    counts.star = state.stars.length;
    counts.all = all.length;
    counts.custom = state.custom.length;
    var otherCount = 0;
    for (var i = 0; i < all.length; i++) {
      var tg = tagsOf(all[i].name);
      if (!tg.length) otherCount++;
      for (var j = 0; j < tg.length; j++) counts[tg[j]] = (counts[tg[j]] || 0) + 1;
    }
    counts.other = otherCount;
    for (var d = 0; d < TAG_DEFS.length; d++) {
      var t = TAG_DEFS[d];
      var n = counts[t.id] || 0;
      if (n === 0 && t.id !== 'star' && t.id !== 'all' && t.id !== 'custom') continue;
      var btn = document.createElement('button');
      btn.className = 'libTag' + (state.libTag === t.id ? ' on' : '');
      var lb = document.createElement('span');
      lb.textContent = t.label;
      btn.appendChild(lb);
      var cn = document.createElement('span');
      cn.className = 'tagN';
      cn.textContent = n;
      btn.appendChild(cn);
      (function (tid) {
        btn.addEventListener('click', function () {
          state.libTag = tid;
          saveState();
          buildLibTags();
          buildLibGrid();
          var g = $('libGrid');
          if (g && g.scrollTop) g.scrollTop = 0;
        });
      })(t.id);
      box.appendChild(btn);
    }
  }

  var libObserver = null;
  if (typeof IntersectionObserver === 'function') {
    try {
      libObserver = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].isIntersecting) {
            var el = entries[i].target;
            libObserver.unobserve(el);
            if (el.dataset && el.dataset.thumbPath) queueThumb(el.dataset.thumbPath, el);
          }
        }
      }, { rootMargin: '160px' });
    } catch (eIO) {
      libObserver = null;
    }
  }

  function queueThumbLazy(path, imgEl) {
    if (state.thumbCache[path]) {
      imgEl.src = state.thumbCache[path];
      return;
    }
    if (libObserver) {
      imgEl.dataset.thumbPath = path;
      libObserver.observe(imgEl);
    } else {
      queueThumb(path, imgEl);
    }
  }

  function isStarred(name) {
    return state.stars.indexOf(name) >= 0;
  }

  function isPooled(name) {
    return state.matPool.indexOf(name) >= 0;
  }

  function togglePool(name) {
    var idx = state.matPool.indexOf(name);
    if (idx >= 0) state.matPool.splice(idx, 1);
    else state.matPool.push(name);
    updatePoolUI();
    renderLayerList();
    status(isPooled(name) ? '已加入备选烫材池：' + name : '已移出备选烫材池：' + name, 'ok');
    return isPooled(name);
  }

  function updatePoolUI() {
    var pc = $('poolCount');
    if (pc) pc.textContent = state.matPool.length;
    updateGuide();
  }

  function updateGuide() {
    var mn = $('routeMat');
    if (mn) {
      if (state.matPool.length) {
        var preview = state.matPool.slice(0, 3).join('、');
        mn.textContent = '烫材：备选池 ' + state.matPool.length + ' 款（' + preview + (state.matPool.length > 3 ? '…' : '') + '）';
      } else {
        mn.textContent = '烫材池为空也可生成：手动选择优先，其余按名称 / 花纹与颜色自动匹配';
      }
    }
    var ct = $('routeCut');
    if (ct) {
      var modeTxt = state.cutMode === 'auto' ? '自动' : state.cutMode === 'line' ? '描边（手动）' : '填充（手动）';
      var found = state.cutInfo && state.cutInfo.found;
      ct.textContent = '刀线：' + (found ? '已识别（' + (state.cutInfo.names || '') + '，覆盖 ' + Math.round((state.cutInfo.coverage || 0) * 100) + '%）' : '未识别（在主页把刀线层设为「模切」）') + ' · 模式 ' + modeTxt + ' —— 请到「刀线裁切」核对';
    }
  }

  function applyLayerAssign() {
    var byId = {};
    var byName = {};
    var saved = state.savedLayerAssign || [];
    for (var i = 0; i < saved.length; i++) {
      var e = saved[i];
      if (e.id != null) byId[e.id] = e;
      if (e.name) byName[e.name] = e;
    }
    state.layerRoles = {};
    state.layerPrio = {};
    state.layerMat = {};
    state.layerMatSource = {};
    state.layerTouched = {};
    for (var j = 0; j < state.layers.length; j++) {
      var L = state.layers[j];
      var se = byId[L.id] || byName[L.name] || null;
      state.layerRoles[L.id] = se ? (se.role || 'ignore') : 'ignore';
      state.layerPrio[L.id] = se && se.prio ? se.prio : 1;
      state.layerMat[L.id] = se ? (se.mat || '') : '';
      state.layerMatSource[L.id] = se ? (se.matSource || (se.touched && se.mat ? 'manual' : '')) : '';
      if (se && se.touched) state.layerTouched[L.id] = true;
    }
  }

  function isGeneratedLayerName(nm) {
    return nm.indexOf(GEN_MARK) >= 0 || /^[0-9]{6}-[0-9]{6}-/.test(nm);
  }

  function matchingLibrary() {
    return state.builtin.concat(state.custom).map(function(m) { return {name:m.name,tags:tagsOf(m.name)}; });
  }

  function materialSpecials(name) {
    var m = findMaterialByName(name);
    var meta = m && m.custom && m.file ? state.customMeta[m.file] : null;
    return {
      pearl: /珠光/.test(name) || !!(meta && meta.pearl),
      transparent: /透明|冰川蓝/.test(name) || !!(meta && meta.transparent),
      noDim: /冰川蓝/.test(name)
    };
  }

  function matchMaterialByName(layerName) {
    var result=window.FoilUMatching.match(layerName,matchingLibrary());
    return result ? result.name : '';
  }

  function resolveLayerMaterial(L) {
    var current=state.layerMat[L.id],source=state.layerMatSource[L.id];
    if((source==='manual' || source==='random') && current) {
      if(findMaterialByName(current))return current;
      return ''; // A missing explicit choice must not silently change to another foil.
    }
    var hit=window.FoilUMatching.match(L.name,matchingLibrary());
    if(hit){state.layerMat[L.id]=hit.name;state.layerMatSource[L.id]=hit.method;return hit.name;}
    var all=state.builtin.concat(state.custom),fallback=null;
    for(var i=0;i<state.matPool.length && !fallback;i++)fallback=findMaterialByName(state.matPool[i]);
    fallback=fallback||findMaterial(state.materialPath)||(all.length?all[0]:null);
    state.layerMat[L.id]=fallback?fallback.name:'';
    state.layerMatSource[L.id]=fallback?'default':'';
    return state.layerMat[L.id];
  }

  function previewLayerEntry() {
    if (!state.doc) return null;
    for (var i = 0; i < state.layers.length; i++) {
      if (state.layers[i].id === state.doc.layerId) return state.layers[i];
    }
    return null;
  }

  function previewTargetMaterial() {
    var L = previewLayerEntry();
    if (!L) return '';
    if (state.layerRoles[L.id] === 'foil') return resolveLayerMaterial(L);
    var hit = window.FoilUMatching.match(L.name, matchingLibrary());
    return hit ? hit.name : '';
  }

  function syncPreviewMaterial() {
    var name = previewTargetMaterial();
    if (!name || name === state.materialName) return;
    var m = findMaterialByName(name);
    if (!m) return;
    selectMaterial(m.path, false);
  }

  function autoMatchLayer(L, full) {
    var nm=String(L.name||'');
    if(!nm || isGeneratedLayerName(nm))return;
    var locked=state.layerMatSource[L.id]==='manual'||state.layerMatSource[L.id]==='random';
    if(!state.layerTouched[L.id]) {
      var role='';
      try {if(new RegExp(state.cutPattern||'模切|刀线').test(nm))role='cut';} catch(e){if(/模切|刀线/.test(nm))role='cut';}
      if(!role && /印刷|柄图/.test(nm))role='print';
      if(!role && /烫/.test(nm))role='foil';
      if(!role) {
        // 名字能明确匹配烫材的图层（如「透明红」）也算烫色层
        var mh=window.FoilUMatching.match(nm,matchingLibrary());
        if(mh && (mh.method==='exact'||mh.method==='name'||mh.method==='fuzzy'||mh.score>=100))role='foil';
      }
      if(role)state.layerRoles[L.id]=role;
      else if(full && !locked)state.layerRoles[L.id]='ignore';
    }
    if(state.layerRoles[L.id]==='foil')resolveLayerMaterial(L);
  }

  function assignPrioritiesByOrder(full) {
    var rank = 0;
    for (var i = 0; i < state.layers.length; i++) {
      var L = state.layers[i];
      if ((state.layerRoles[L.id] || 'ignore') !== 'foil') continue;
      rank++;
      if (!full && state.layerTouched[L.id]) continue;
      var pr = 8 - (rank - 1);
      if (pr < 1) pr = 1;
      state.layerPrio[L.id] = pr;
    }
  }

  function runAutoMatch(full) {
    for(var j=0;j<state.layers.length;j++)autoMatchLayer(state.layers[j],full);
    assignPrioritiesByOrder(full);
    saveState();renderLayerList();updatePoolUI();
  }

  function buildRandomFilters() {
    var brand=$('randomBrand'),color=$('randomColor');if(!brand||!color)return;
    var oldBrand=brand.value,oldColor=color.value,brands=[];
    state.builtin.concat(state.custom).forEach(function(m){var b=brandOf(m.name);if(b && brands.indexOf(b)<0)brands.push(b);});
    brand.innerHTML='';color.innerHTML='';
    function option(select,value,label){var o=document.createElement('option');o.value=value;o.textContent=label;select.appendChild(o);}
    option(brand,'','全部厂家');brands.sort().forEach(function(b){option(brand,b,b);});
    option(brand,'none','未标注厂家');
    TAG_DEFS.forEach(function(t){if(t.id==='all')option(color,'all','全部色彩');else if(t.keys)option(color,t.id,t.label);});
    if(brands.indexOf(oldBrand)>=0 || oldBrand==='none')brand.value=oldBrand;
    color.value=oldColor||'all';if(!color.value)color.value='all';
  }

  function randomMatchMaterials() {
    if(state.busy)return;
    var b=$('randomBrand').value,c=$('randomColor').value;
    var candidates=state.builtin.concat(state.custom).filter(function(m){
      var mb=brandOf(m.name);return (!b||(b==='none'?!mb:mb===b)) && (c==='all'||tagsOf(m.name).indexOf(c)>=0);
    });
    if(!candidates.length){status('没有符合厂家和色彩筛选的烫材，请调整筛选', 'err');return;}
    var count=0,skipped=0;
    state.layers.forEach(function(L){
      if(state.layerRoles[L.id]!=='foil')return;
      if(state.layerMatSource[L.id]==='manual'){skipped++;return;}
      var choices=candidates.filter(function(m){return m.name!==state.layerMat[L.id];});
      if(!choices.length)choices=candidates;
      var selected=choices[Math.floor(Math.random()*choices.length)];
      state.layerMat[L.id]=selected.name;state.layerMatSource[L.id]='random';count++;
    });
    if(!count){status(skipped?'所有烫色层已手动指定；先重置要随机的图层':'请先刷新并分配烫色图层','info');return;}
    saveState();renderLayerList();updateGuide();
    status('已随机匹配 '+count+' 个烫色层'+(skipped?'，保留 '+skipped+' 个手动选择':''),'ok');
  }

  function renderLayerList() {
    var box = $('layerList');
    if (!box) return;
    box.innerHTML = '';
    var cnt = $('layerCount');
    if (cnt) cnt.textContent = state.layers.length ? '（' + state.layers.length + ' 个）' : '';
    if (!state.layers.length) {
      var tip = document.createElement('div');
      tip.className = 'hintLine dim';
      tip.textContent = '点击预览区的「刷新」读取文档图层列表。';
      box.appendChild(tip);
      return;
    }
    var ROLE_OPTS = [['ignore', '忽略'], ['foil', '烫色'], ['print', '印刷'], ['cut', '模切']];
    state.layers.forEach(function (L) {
      var role = state.layerRoles[L.id] || 'ignore';
      var row = document.createElement('div');
      row.className = 'layerRow' + (role !== 'ignore' ? ' seg' : '');
      var nm = document.createElement('div');
      nm.className = 'layerName' + (L.group ? ' group' : '');
      nm.textContent = (L.depth ? '　└ ' : '') + L.name;
      nm.title = L.name;
      row.appendChild(nm);
      var sel = document.createElement('select');
      sel.className = 'layerSel';
      for (var r = 0; r < ROLE_OPTS.length; r++) {
        var op = document.createElement('option');
        op.value = ROLE_OPTS[r][0];
        op.textContent = ROLE_OPTS[r][1];
        sel.appendChild(op);
      }
      sel.value = role;
      sel.addEventListener('change', function () {
        var prevRole = state.layerRoles[L.id];
        var newRole = this.value;
        state.layerRoles[L.id] = newRole;
        state.layerTouched[L.id] = true;
        saveState();
        renderLayerList();
        updateGuide();
        if (state.cut && (prevRole === 'cut' || newRole === 'cut')) refreshCut();
      });
      row.appendChild(sel);
      if (role === 'foil') {
        var psel = document.createElement('select');
        psel.className = 'layerSel mini';
        psel.title = '优先级：数字越大，导出后越靠上';
        for (var p = 1; p <= 8; p++) {
          var pop = document.createElement('option');
          pop.value = String(p);
          pop.textContent = '优' + p;
          psel.appendChild(pop);
        }
        psel.value = String(state.layerPrio[L.id] || 1);
        psel.addEventListener('change', function () {
          state.layerPrio[L.id] = Number(this.value) || 1;
          state.layerTouched[L.id] = true;
          saveState();
        });
        row.appendChild(psel);
        var msel = document.createElement('select');
        msel.className = 'layerSel';
        msel.title = '手动选择优先；未选择时按图层名称、花纹和颜色自动匹配';
        var cur = state.layerMat[L.id] || '';
        var opts = state.matPool.filter(function(name){return !!findMaterialByName(name);});
        if (!opts.length) opts = state.builtin.concat(state.custom).map(function(m){return m.name;});
        if (cur && opts.indexOf(cur) < 0) opts.unshift(cur);
        if (!opts.length) {
          var eop = document.createElement('option');
          eop.value = '';
          eop.textContent = '（材质库为空）';
          msel.appendChild(eop);
        } else {
          var eop2 = document.createElement('option');
          eop2.value = '';
          eop2.textContent = '自动匹配（生成时）';
          msel.appendChild(eop2);
          for (var oi2 = 0; oi2 < opts.length; oi2++) {
            var mop = document.createElement('option');
            mop.value = opts[oi2];
            mop.textContent = opts[oi2];
            msel.appendChild(mop);
          }
        }
        msel.value = cur;
        msel.addEventListener('change', function () {
          state.layerMat[L.id] = this.value;
          state.layerMatSource[L.id] = this.value ? 'manual' : '';
          state.layerTouched[L.id] = true;
          saveState();
          renderLayerList();
          updateGuide();
        });
        row.appendChild(msel);
        var reason = document.createElement('span');
        reason.className = 'layerMatchReason';
        var labels = {manual:'手动',random:'随机',exact:'名称',name:'名称',fuzzy:'模糊',similar:'近似',default:'默认'};
        reason.textContent = labels[state.layerMatSource[L.id]] || '自动';
        reason.title = state.layerMatSource[L.id] === 'default' ? '名称未提供可识别的花纹或颜色，使用默认材质；可手动更换' : '手动指定与随机结果会保留，重置后恢复自动匹配';
        row.appendChild(reason);
        var rst = document.createElement('button');
        rst.className = 'miniBtn';
        rst.textContent = '重置';
        rst.title = '清除该烫色层的烫材与优先级';
        rst.addEventListener('click', function () {
          state.layerMat[L.id] = '';
          delete state.layerMatSource[L.id];
          state.layerPrio[L.id] = 1;
          state.layerTouched[L.id] = true;
          saveState();
          renderLayerList();
        });
        row.appendChild(rst);
      }
      box.appendChild(row);
    });
    syncPreviewMaterial();
  }

  function refreshLayerList() {
    if (!cep.available || !ps.listLayers) return;
    ps.listLayers(cep.workDir, 0, function (r) {
      if (!r || !r.ok) return;
      try {
        var txt = cep.fs.readFileSync(cep.workDir + '/layerlist.json', 'utf8');
        var list = JSON.parse(txt);
        if (Object.prototype.toString.call(list) === '[object Array]') {
          state.layers = list;
          applyLayerAssign();
          var docKey = (state.doc ? state.doc.docName : '') + '|' + list.length;
          if (state.autoMatchedKey !== docKey) {
            state.autoMatchedKey = docKey;
            for (var i = 0; i < list.length; i++) autoMatchLayer(list[i], false);
            assignPrioritiesByOrder(false);
            saveState();
          }
          renderLayerList();
          updateGuide();
          updatePoolUI();
        }
      } catch (e) {}
    });
  }

  function buildLibBrands() {
    var box = $('libBrands');
    if (!box) return;
    box.innerHTML = '';
    var lbl = document.createElement('span');
    lbl.className = 'tagRowLabel';
    lbl.textContent = '厂家';
    box.appendChild(lbl);
    var all = state.builtin.concat(state.custom);
    var counts = {};
    var noneCount = 0;
    for (var i = 0; i < all.length; i++) {
      var b = brandOf(all[i].name);
      if (!b) noneCount++;
      else counts[b] = (counts[b] || 0) + 1;
    }
    function addTag(id, label, n) {
      var btn = document.createElement('button');
      btn.className = 'libTag' + (state.libBrand === id ? ' on' : '');
      var lb = document.createElement('span');
      lb.textContent = label;
      btn.appendChild(lb);
      var cn = document.createElement('span');
      cn.className = 'tagN';
      cn.textContent = n;
      btn.appendChild(cn);
      btn.addEventListener('click', function () {
        state.libBrand = (state.libBrand === id) ? '' : id;
        saveState();
        buildLibBrands();
        buildLibGrid();
      });
      box.appendChild(btn);
    }
    addTag('', '全部', all.length);
    var brandIds = Object.keys(counts).sort(function (a, b2) { return counts[b2] - counts[a]; });
    for (var j = 0; j < brandIds.length; j++) {
      addTag(brandIds[j], brandIds[j], counts[brandIds[j]]);
    }
    if (noneCount > 0) addTag('_none', '未标注', noneCount);
  }

  var libSearchTimer = 0;

  function libSearchRe() {
    var q = state.libSearch;
    if (!q) return null;
    try {
      return new RegExp(q, 'i');
    } catch (e) {
      var esc = String(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      try { return new RegExp(esc, 'i'); } catch (e2) { return null; }
    }
  }

  function persistStars() {
    if (cep.writeStars) {
      try { cep.writeStars(state.stars); } catch (e) {}
    }
  }

  function toggleStar(name) {
    var idx = state.stars.indexOf(name);
    if (idx >= 0) state.stars.splice(idx, 1);
    else state.stars.push(name);
    persistStars();
    if (state.libTag === 'star') buildLibGrid();
    buildLibTags();
    status(isStarred(name) ? '已加入星标：' + name : '已移出星标：' + name, 'ok');
    return isStarred(name);
  }

  function removeStar(name) {
    if (!window.confirm('从星标中删除「' + name + '」？（不会删除任何贴图文件）')) return;
    var idx = state.stars.indexOf(name);
    if (idx >= 0) state.stars.splice(idx, 1);
    persistStars();
    buildLibTags();
    buildLibGrid();
    status('已从星标删除', 'ok');
  }

  var remountName = '';

  function startRemount(name) {
    remountName = name;
    $('remountFile').click();
  }

  function handleRemount(file, name) {
    var fr = new FileReader();
    fr.onload = function () {
      var img = new Image();
      img.onload = function () {
        try {
          var c = document.createElement('canvas');
          c.width = 1000;
          c.height = 1000;
          var ctx = c.getContext('2d');
          var s = Math.max(1000 / img.width, 1000 / img.height);
          var dw = Math.round(img.width * s);
          var dh = Math.round(img.height * s);
          ctx.drawImage(img, Math.round((1000 - dw) / 2), Math.round((1000 - dh) / 2), dw, dh);
          c.toBlob(function (blob) {
            if (!blob) {
              status('重新挂载失败：无法生成图片', 'err');
              return;
            }
            var fr2 = new FileReader();
            fr2.onload = function () {
              var bytes = new Uint8Array(fr2.result);
              var safe = name.replace(/[\\/:*?"<>|]/g, '_');
              var dest = cep.customDir + '/' + safe + '.png';
              if (!cep.writeBuffer(dest, bytes)) {
                status('重新挂载失败：无法写入文件', 'err');
                return;
              }
              delete state.thumbCache[dest];
              scanLibrary();
              var m = findMaterialByName(name);
              if (m && m.path) state.materialPath = m.path;
              rebuildMaterialUI();
              if (state.materialPath) selectMaterial(state.materialPath, true);
              status('已重新挂载：' + name, 'ok');
            };
            fr2.readAsArrayBuffer(blob);
          }, 'image/png');
        } catch (eR) {
          status('重新挂载失败：' + eR.message, 'err');
        }
      };
      img.onerror = function () {
        status('重新挂载失败：图片解码错误', 'err');
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  function makeLibItem(m) {
    var item = document.createElement('div');
    if (m.missing) {
      item.className = 'libItem missing';
      var box = document.createElement('div');
      box.className = 'missBox';
      box.textContent = '⚠ 贴图已丢失';
      item.appendChild(box);
      var nm0 = document.createElement('span');
      nm0.className = 'libName';
      nm0.textContent = m.name;
      item.appendChild(nm0);
      var btns = document.createElement('div');
      btns.className = 'missBtns';
      var bR = document.createElement('button');
      bR.className = 'missBtn';
      bR.textContent = '重新挂载';
      bR.addEventListener('click', function (ev) {
        ev.stopPropagation();
        startRemount(m.name);
      });
      var bD = document.createElement('button');
      bD.className = 'missBtn';
      bD.textContent = '删除';
      bD.addEventListener('click', function (ev) {
        ev.stopPropagation();
        removeStar(m.name);
      });
      btns.appendChild(bR);
      btns.appendChild(bD);
      item.appendChild(btns);
      return item;
    }
    item.className = 'libItem' + (m.path === state.materialPath ? ' sel' : '');
    item.dataset.path = m.path;
    var thumb = document.createElement('img');
    item.appendChild(thumb);
    var nm = document.createElement('span');
    nm.className = 'libName';
    nm.textContent = m.name;
    item.appendChild(nm);
    var star = document.createElement('span');
    star.className = 'libStar' + (isStarred(m.name) ? ' on' : '');
    star.textContent = '★';
    star.title = '加入 / 移出星标';
    star.addEventListener('click', function (ev) {
      ev.stopPropagation();
      var on = toggleStar(m.name);
      star.className = 'libStar' + (on ? ' on' : '');
    });
    item.appendChild(star);
    var pool = document.createElement('span');
    pool.className = 'libPool' + (isPooled(m.name) ? ' on' : '');
    pool.textContent = '+';
    pool.title = '加入 / 移出备选烫材池（主页烫色层从这里选烫材）';
    pool.addEventListener('click', function (ev) {
      ev.stopPropagation();
      var on = togglePool(m.name);
      pool.className = 'libPool' + (on ? ' on' : '');
    });
    item.appendChild(pool);
    item.addEventListener('click', function () {
      selectMaterial(m.path, false);
    });
    queueThumbLazy(m.path, thumb);
    return item;
  }

  function buildLibGrid() {
    var grid = $('libGrid');
    if (!grid) return;
    if (libObserver) libObserver.disconnect();
    grid.innerHTML = '';
    var tag = state.libTag || 'all';
    var list = [];
    var i;
    if (tag === 'star') {
      for (i = 0; i < state.stars.length; i++) {
        var sn = state.stars[i];
        var sm = findMaterialByName(sn);
        list.push(sm ? sm : { name: sn, missing: true });
      }
    } else {
      var all = state.builtin.concat(state.custom);
      for (i = 0; i < all.length; i++) {
        var mm = all[i];
        var ok = false;
        if (tag === 'all') ok = true;
        else if (tag === 'custom') ok = mm.custom;
        else if (tag === 'other') ok = tagsOf(mm.name).length === 0;
        else ok = tagsOf(mm.name).indexOf(tag) >= 0;
        if (ok) list.push(mm);
      }
      if (tag !== 'custom') {
        list.sort(function (a, b) {
          return String(a.name).localeCompare(String(b.name), 'zh-Hans-CN');
        });
      }
    }
    var re = libSearchRe();
    var brand = state.libBrand;
    if (re || brand) {
      list = list.filter(function (m) {
        if (re && !re.test(String(m.name))) return false;
        if (brand) {
          var b = brandOf(m.name);
          if (brand === '_none') {
            if (b) return false;
          } else if (b !== brand) {
            return false;
          }
        }
        return true;
      });
    }
    for (var q = 0; q < list.length; q++) {
      grid.appendChild(makeLibItem(list[q]));
    }
    if (!list.length) {
      var tip = document.createElement('div');
      tip.className = 'hintLine dim';
      if (tag === 'star' && !state.stars.length) {
        tip.textContent = '星标为空：点击任意烫材预览图右下角的 ★ 即可收藏，星标会随插件更新保留。';
      } else {
        tip.textContent = '没有符合当前筛选条件的烫材。';
      }
      grid.appendChild(tip);
    }
  }

  function buildCustomList() {
    var list = $('customList');
    list.innerHTML = '';
    if (!state.custom.length) {
      var empty = document.createElement('div');
      empty.className = 'hintLine dim';
      empty.textContent = '暂无自定义材质。请上传 1000×1000px 的四方连续贴图。';
      list.appendChild(empty);
    }
    state.custom.forEach(function (m) {
      var item = document.createElement('div');
      item.className = 'customItem' + (m.path === state.materialPath ? ' sel' : '');
      item.dataset.path = m.path;
      var img = document.createElement('img');
      item.appendChild(img);
      var nm = document.createElement('div');
      nm.className = 'cName';
      nm.textContent = m.name;
      nm.title = '双击可重命名';
      nm.addEventListener('dblclick', function (ev) {
        ev.stopPropagation();
        startRenameCustom(m, nm);
      });
      item.appendChild(nm);
      if (state.customMeta[m.file] && state.customMeta[m.file].mirror) {
        var badge = document.createElement('span');
        badge.className = 'cBadge';
        badge.textContent = '镜像';
        item.appendChild(badge);
      }
      var cstar = document.createElement('div');
      cstar.className = 'cStar' + (isStarred(m.name) ? ' on' : '');
      cstar.textContent = '★';
      cstar.title = '加入 / 移出星标';
      cstar.addEventListener('click', function (ev) {
        ev.stopPropagation();
        var on = toggleStar(m.name);
        cstar.className = 'cStar' + (on ? ' on' : '');
      });
      item.appendChild(cstar);
      var del = document.createElement('div');
      del.className = 'cDel';
      del.textContent = '×';
      del.title = '删除该材质';
      del.addEventListener('click', function (ev) {
        ev.stopPropagation();
        deleteCustom(m);
      });
      item.appendChild(del);
      item.addEventListener('click', function () {
        selectMaterial(m.path, false);
      });
      list.appendChild(item);
      queueThumb(m.path, img);
    });
    $('customCount').textContent = state.custom.length ? '（' + state.custom.length + ' 款）' : '';
  }

  function markSelections() {
    var items = document.querySelectorAll('.libItem');
    for (var i = 0; i < items.length; i++) {
      items[i].classList.toggle('sel', items[i].dataset.path === state.materialPath);
    }
    var citems = document.querySelectorAll('.customItem');
    for (var j = 0; j < citems.length; j++) {
      citems[j].classList.toggle('sel', citems[j].dataset.path === state.materialPath);
    }
  }

  function drawChip(img) {
    var chip = $('matChip');
    if (!chip) return;
    var ctx = chip.getContext('2d');
    ctx.clearRect(0, 0, chip.width, chip.height);
    ctx.drawImage(img, 0, 0, chip.width, chip.height);
  }

  function selectMaterial(path, keepFlags) {
    var m = findMaterial(path);
    var mirror = !!(m && m.custom && state.customMeta[m.file] && state.customMeta[m.file].mirror);
    state.materialPath = path;
    state.materialName = m ? m.name : path.replace(/\.[^.]+$/, '');
    if (!keepFlags) {
      var sp = materialSpecials(state.materialName);
      state.pearl = sp.pearl;
      state.transparent = sp.transparent;
      state.params.texScale = userScaleFor(state.materialName);
      syncScaleUI();
    }
    syncSpecialUI();
    var msel = $('materialSelect');
    if (msel) msel.value = path;
    markSelections();
    saveState();
    cep.imageDataUrl(path, function (url) {
      if (!url) {
        status('无法读取烫材贴图：' + path, 'err');
        return;
      }
      var img = new Image();
      img.onload = function () {
        state.materialImg = img;
        drawChip(img);
        if (renderer) {
          try {
            renderer.setFoil(img, mirror);
          } catch (e) {
            status('贴图加载失败：' + e.message, 'err');
          }
        }
        scheduleRender();
      };
      img.onerror = function () {
        status('烫材贴图解码失败：' + path, 'err');
      };
      img.src = url;
    });
  }

  function deleteCustom(m) {
    if (!window.confirm('删除自定义材质「' + m.name + '」？')) return;
    try {
      cep.fs.unlinkSync(m.path);
    } catch (e) {
      status('删除失败：' + e.message, 'err');
      return;
    }
    if (state.customMeta[m.file]) {
      delete state.customMeta[m.file];
      cep.writeMeta(state.customMeta);
    }
    delete state.thumbCache[m.path];
    scanLibrary();
    if (state.materialPath === m.path) {
      state.materialPath = state.builtin.length ? state.builtin[0].path : (state.custom.length ? state.custom[0].path : '');
    }
    rebuildMaterialUI();
    if (state.materialPath) selectMaterial(state.materialPath, true);
    status('已删除自定义材质', 'ok');
  }

  function currentParams(dpi) {
    return {
      depthMm: state.params.depthMm,
      relief: state.params.relief,
      spec: state.params.spec,
      gloss: state.params.gloss,
      light: state.params.light,
      texScale: state.params.texScale,
      crease: state.params.crease,
      pearl: state.pearl,
      pearlAlpha: state.params.pearlAlpha,
      pearlWhite: /珠光白/.test(state.materialName || ''),
      transparent: state.transparent,
      tranAlpha: state.params.tranAlpha,
      noDim: /冰川蓝/.test(state.materialName || ''),
      pearlColor: [state.pearlColor.r, state.pearlColor.g, state.pearlColor.b],
      pxPerMm: (dpi || 300) / 25.4,
      useCut: !!(state.cut && state.cutCanvas)
    };
  }

  function scheduleRender() {
    if (!state.session) return;
    if (renderTimer) clearTimeout(renderTimer);
    renderTimer = setTimeout(function () {
      renderTimer = 0;
      renderPreview();
    }, 120);
  }

  function renderPreview() {
    if (!renderer || !state.session || !state.materialImg) return;
    var sess = state.session;
    var rect, outW, outH;
    if (state.zoom === '100' || state.zoom === '200') {
      var k = state.zoom === '100' ? 1 : 2;
      var winW = Math.min(sess.docW, Math.round(900 / k));
      var winH = Math.min(sess.docH, Math.round(900 / k));
      rect = {
        x: Math.round((sess.docW - winW) / 2),
        y: Math.round((sess.docH - winH) / 2),
        w: winW,
        h: winH
      };
      outW = Math.round(winW * k);
      outH = Math.round(winH * k);
    } else {
      rect = { x: 0, y: 0, w: sess.docW, h: sess.docH };
      outW = Math.min(1600, Math.round(sess.docW));
      outH = Math.max(1, Math.round(sess.docH * outW / sess.docW));
    }
    renderCanvas.width = outW;
    renderCanvas.height = outH;
    renderCtx.clearRect(0, 0, outW, outH);
    try {
      renderer.render(renderCtx, outW, outH, rect, currentParams(sess.dpi));
    } catch (e) {
      status('渲染失败：' + e.message, 'err');
      return;
    }
    var pc = $('previewCanvas');
    pc.width = outW;
    pc.height = outH;
    var pctx = pc.getContext('2d');
    pctx.clearRect(0, 0, outW, outH);
    if (state.flatImg) {
      var fs = state.flatImg.naturalWidth / sess.docW;
      try {
        pctx.drawImage(state.flatImg, rect.x * fs, rect.y * fs, rect.w * fs, rect.h * fs, 0, 0, outW, outH);
      } catch (e) {}
    }
    pctx.drawImage(renderCanvas, 0, 0);
    $('emptyHint').style.display = 'none';
    $('previewWrap').classList.remove('stale');
    state.stale = false;
    applyPreviewRotation();
  }

  function maskCoverage(maskImg) {
    try {
      var c = document.createElement('canvas');
      c.width = 64;
      c.height = 64;
      var ctx = c.getContext('2d');
      ctx.drawImage(maskImg, 0, 0, 64, 64);
      var d = ctx.getImageData(0, 0, 64, 64).data;
      var on = 0;
      for (var i = 3; i < d.length; i += 4) {
        if (d[i] > 10) on++;
      }
      return on / (64 * 64);
    } catch (e) {
      return -1;
    }
  }

  function maskHasContent(maskImg) {
    var c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    var ctx = c.getContext('2d');
    ctx.drawImage(maskImg, 0, 0, 256, 256);
    var d = ctx.getImageData(0, 0, 256, 256).data;
    for (var i = 3; i < d.length; i += 4) {
      if (d[i] > 5) return true;
    }
    return false;
  }

  function updateCutUI() {
    $('cutToggle').classList.toggle('on', state.cut);
    var mbtns = document.querySelectorAll('.cutModeBtn');
    for (var mi = 0; mi < mbtns.length; mi++) {
      mbtns[mi].classList.toggle('on', mbtns[mi].getAttribute('data-cutmode') === state.cutMode);
    }
    var cv = $('cutPreviewCanvas');
    var ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, cv.width, cv.height);
    var info = state.cutInfo;
    if (!state.cut) {
      $('cutStatus').textContent = '未启用：生成的烫色图层不会被刀线裁切。';
      return;
    }
    if (info && info.found && state.cutCanvas) {
      var cw = state.cutCanvas.width;
      var ch = state.cutCanvas.height;
      var s = Math.min(cv.width / cw, cv.height / ch);
      var dw = Math.max(1, Math.round(cw * s));
      var dh = Math.max(1, Math.round(ch * s));
      ctx.drawImage(state.cutCanvas, Math.round((cv.width - dw) / 2), Math.round((cv.height - dh) / 2), dw, dh);
      var modeTxt = info.mode === 'fill' ? '填充区域' : '轮廓圈选';
      if (state.cutMode !== 'auto') modeTxt += '（手动）';
      $('cutStatus').textContent = '识别为' + modeTxt + ' | 图层：' + (info.names || '') +
        ' | 覆盖率 ' + Math.round((info.coverage || 0) * 100) + '%';
    } else if (info && !info.found) {
      $('cutStatus').textContent = '没有已设为「模切」的图层：请在主页图层列表里把刀线层设为「模切」';
    } else {
      $('cutStatus').textContent = '等待识别…';
    }
    updateGuide();
  }

  function cutRoleIds() {
    var ids = [];
    for (var i = 0; i < state.layers.length; i++) {
      if (state.layerRoles[state.layers[i].id] === 'cut') ids.push(state.layers[i].id);
    }
    return ids;
  }

  function refreshCut(cb) {
    if (typeof cb !== 'function') cb = function () {};
    if (!renderer) { cb(); return; }
    if (!state.cut) {
      renderer.setCut(null);
      state.cutInfo = null;
      state.cutCanvas = null;
      updateCutUI();
      scheduleRender();
      cb();
      return;
    }
    var cutIds = cutRoleIds();
    if (!cutIds.length) {
      renderer.setCut(null);
      state.cutInfo = { found: false };
      state.cutCanvas = null;
      updateCutUI();
      scheduleRender();
      cb();
      return;
    }
    ps.exportByIds(cep.workDir, 'cut.png', cutIds.join(','), function (res) {
      if (!res || !res.ok) {
        renderer.setCut(null);
        state.cutInfo = { found: false };
        state.cutCanvas = null;
        updateCutUI();
        status('刀线读取失败：' + ((res && res.error) || '未知错误'), 'err');
        scheduleRender();
        cb();
        return;
      }
      cep.imageDataUrl(cep.workDir + '/cut.png', function (url) {
        if (!url) {
          renderer.setCut(null);
          state.cutInfo = { found: false };
          state.cutCanvas = null;
          updateCutUI();
          cb();
          return;
        }
        var img = new Image();
        img.onload = function () {
          try {
            var docW = (state.doc && state.doc.widthPx) || img.width;
            var docH = (state.doc && state.doc.heightPx) || img.height;
            var names = [];
            for (var k = 0; k < state.layers.length; k++) {
              if (cutIds.indexOf(state.layers[k].id) >= 0) names.push(state.layers[k].name);
            }
            var p = window.FoilUCut.process(img, docW, docH, state.cutMode);
            if (p.canvas) {
              state.cutCanvas = p.canvas;
              state.cutInfo = { found: true, names: names.join('、'), mode: p.mode, coverage: p.coverage };
              renderer.setCut(p.canvas);
            } else {
              state.cutCanvas = null;
              state.cutInfo = { found: false };
              renderer.setCut(null);
            }
          } catch (e) {
            state.cutCanvas = null;
            state.cutInfo = { found: false };
            renderer.setCut(null);
            status('刀线处理失败：' + e.message, 'err');
          }
          updateCutUI();
          scheduleRender();
          cb();
        };
        img.onerror = function () {
          renderer.setCut(null);
          state.cutInfo = { found: false };
          state.cutCanvas = null;
          updateCutUI();
          cb();
        };
        img.src = url;
      });
    });
  }

  function applyPreviewRotation() {
    var pc = $('previewCanvas');
    var wrap = $('previewWrap');
    if (!pc) return;
    var ang = ((state.viewRotAngle || 0) + (state.viewRotOffset || 0)) % 360;
    pc.style.transformOrigin = 'center center';
    if (!ang || !wrap) {
      pc.style.transform = '';
      return;
    }
    var dw = pc.offsetWidth || pc.width;
    var dh = pc.offsetHeight || pc.height;
    var rad = ang * Math.PI / 180;
    var cc = Math.abs(Math.cos(rad));
    var ss = Math.abs(Math.sin(rad));
    var bw = dw * cc + dh * ss;
    var bh = dw * ss + dh * cc;
    var ww = wrap.clientWidth;
    var wh = wrap.clientHeight;
    var k = Math.min((ww || bw) / bw, (wh || bh) / bh, 1);
    pc.style.transform = 'rotate(' + ang + 'deg)' + (k < 0.999 ? ' scale(' + k + ')' : '');
  }

  function syncViewRotation() {
    if (!ps.getViewRotation) return;
    ps.getViewRotation(function (r) {
      var ang = 0;
      try { ang = r && r.ok ? Number(r.angle) || 0 : 0; } catch (e) {}
      state.viewRotAngle = ang;
      state.viewRotInfo = r ? { angle: ang, src: r.src || '', keys: r.keys || '' } : null;
      applyPreviewRotation();
    });
  }

  function finishSession(res, size) {
    state.session = {
      docW: res.widthPx,
      docH: res.heightPx,
      dpi: res.dpi,
      layerId: res.layerId,
      docName: state.doc ? state.doc.docName : '',
      maskW: size.w,
      maskH: size.h,
      lastPlacedLayerId: state.session ? state.session.lastPlacedLayerId : null,
      exportedAt: Date.now()
    };
    state.staleNotified = false;
    syncViewRotation();
    renderPreview();
    setBusy(false);
    status('预览已更新：' + (state.materialName || '') + (state.pearl ? ' · 珠光' : '') + (state.transparent ? ' · 透明' : ''), 'ok');
  }

  function refreshPreview() {
    if (!cep.available) {
      status('CEP Node 未启用，无法读写临时文件', 'err');
      return;
    }
    if (!renderer) {
      status('WebGL 不可用，无法预览', 'err');
      return;
    }
    if (state.busy) return;
    setBusy(true);
    status('正在从 Photoshop 导出所选图层…', 'busy');
    ps.getDocInfo(function (info) {
      if (!info.ok) {
        setBusy(false);
        status('读取文档失败：' + info.error, 'err');
        return;
      }
      state.doc = info;
      refreshLayerList();
      ps.exportAssets(cep.workDir, 3600, 3072, function (res) {
        if (!res.ok) {
          setBusy(false);
          status('导出图层失败：' + res.error, 'err');
          return;
        }
        cep.imageDataUrl(cep.workDir + '/mask.png', function (urlMask) {
          if (!urlMask) {
            setBusy(false);
            status('无法读取蒙版文件', 'err');
            return;
          }
          var maskImg = new Image();
          maskImg.onload = function () {
            if (!maskHasContent(maskImg)) {
              setBusy(false);
              status('所选图层没有可烫印的内容（图层为空或完全透明）', 'err');
              return;
            }
            state.maskCov = maskCoverage(maskImg);
            var size;
            try {
              size = renderer.setMask(maskImg, res.widthPx, res.heightPx, res.maskW, res.maskH);
            } catch (e) {
              setBusy(false);
              status('蒙版初始化失败：' + e.message, 'err');
              return;
            }
            var proceed = function () {
              if (!res.hasFlat) {
                state.flatImg = null;
                finishSession(res, size);
                return;
              }
              cep.imageDataUrl(cep.workDir + '/flat.png', function (urlFlat) {
                if (!urlFlat) {
                  state.flatImg = null;
                  finishSession(res, size);
                  return;
                }
                var flatImg = new Image();
                flatImg.onload = function () {
                  state.flatImg = flatImg;
                  finishSession(res, size);
                };
                flatImg.onerror = function () {
                  state.flatImg = null;
                  finishSession(res, size);
                };
                flatImg.src = urlFlat;
              });
            };
            refreshCut(proceed);
          };
          maskImg.onerror = function () {
            setBusy(false);
            status('蒙版图片解码失败', 'err');
          };
          maskImg.src = urlMask;
        });
      });
    });
  }

  function renderFoilEntry(f, res, cutCanvas, done) {
    cep.imageDataUrl(cep.workDir + '/fm_' + f.id + '.png', function (urlMask) {
      if (!urlMask) { done(); return; }
      var mimg = new Image();
      mimg.onload = function () {
        if (!maskHasContent(mimg)) {
          status('烫色层「' + f.name + '」没有可烫印内容，已跳过', 'err');
          done();
          return;
        }
        var m = findMaterialByName(f.mat);
        if (!m || !m.path) {
          status('找不到烫材「' + f.mat + '」，该层已跳过', 'err');
          done();
          return;
        }
        var mirror = !!(m.custom && state.customMeta[m.file] && state.customMeta[m.file].mirror);
        cep.imageDataUrl(m.path, function (urlFoil) {
          if (!urlFoil) { done(); return; }
          var fimg = new Image();
          fimg.onload = function () {
            try {
              var size = renderer.setMask(mimg, res.widthPx, res.heightPx, res.widthPx, res.heightPx);
              renderer.setFoil(fimg, mirror);
              renderer.setCut(cutCanvas || null);
              var pr = currentParams(res.dpi);
              pr.texScale = userScaleFor(f.mat);
              var sp = materialSpecials(f.mat);
              pr.pearl = sp.pearl;
              pr.pearlWhite = /珠光白/.test(f.mat);
              pr.transparent = sp.transparent;
              pr.noDim = sp.noDim;
              var out = document.createElement('canvas');
              out.width = size.w;
              out.height = size.h;
              var octx = out.getContext('2d');
              renderer.render(octx, size.w, size.h, { x: 0, y: 0, w: res.widthPx, h: res.heightPx }, pr);
              var bbox = null;
              try { bbox = canvasAlphaBBox(out); } catch (eB) {}
              if (!bbox) {
                status('「' + f.name + '」渲染结果为空，已跳过', 'err');
                done();
                return;
              }
              out.toBlob(function (blob) {
                if (!blob) { done(); return; }
                var fr = new FileReader();
                fr.onload = function () {
                  var bytes = new Uint8Array(fr.result);
                  var pp = cep.workDir + '/fr_' + f.id + '.png';
                  if (!cep.writeBuffer(pp, bytes)) { done(); return; }
                  f.output = pp;
                  f.scale = size.w / res.widthPx;
                  f.pngW = out.width;
                  f.pngH = out.height;
                  f.expL = bbox.x0 / f.scale;
                  f.expT = bbox.y0 / f.scale;
                  done();
                };
                fr.readAsArrayBuffer(blob);
              }, 'image/png');
            } catch (eR) {
              status('「' + f.name + '」渲染失败：' + eR.message, 'err');
              done();
            }
          };
          fimg.onerror = function () { done(); };
          fimg.src = urlFoil;
        });
      };
      mimg.onerror = function () { done(); };
      mimg.src = urlMask;
    });
  }

  function makePrintCutMulti(pim, res, cutCanvas, topLayerId, cb) {
    try {
      var pc = document.createElement('canvas');
      pc.width = res.widthPx;
      pc.height = res.heightPx;
      var ctx = pc.getContext('2d');
      ctx.drawImage(pim, 0, 0, res.widthPx, res.heightPx);
      if (cutCanvas) {
        ctx.globalCompositeOperation = 'destination-in';
        ctx.drawImage(cutCanvas, 0, 0, res.widthPx, res.heightPx);
        ctx.globalCompositeOperation = 'source-over';
      }
      var bb = null;
      try { bb = canvasAlphaBBox(pc); } catch (eP) {}
      if (!bb) { cb(false); return; }
      pc.toBlob(function (blob) {
        if (!blob) { cb(false); return; }
        var fr = new FileReader();
        fr.onload = function () {
          var pp = cep.workDir + '/printmulti.png';
          if (!cep.writeBuffer(pp, new Uint8Array(fr.result))) { cb(false); return; }
          var pSuffix = cutCanvas ? '-印刷(模切)' : '-印刷';
          var name = timestampName() + pSuffix + GEN_MARK;
          ps.placeResult(pp, name, 1, topLayerId, bb.x0, bb.y0, pSuffix + GEN_MARK, pc.width, pc.height, function (r) {
            cb(r && r.ok ? r.layerId : 0);
          });
        };
        fr.readAsArrayBuffer(blob);
      }, 'image/png');
    } catch (e) {
      cb(false);
    }
  }

  function applyMulti(roles) {
    if (!roles.foil.length) {
      status('未分配烫色层：请在图层列表中把要烫色的图层设为「烫色」', 'err');
      return;
    }
    for (var i = 0; i < roles.foil.length; i++) {
      var layer = null;
      for (var j = 0; j < state.layers.length; j++) if (state.layers[j].id === roles.foil[i]) { layer = state.layers[j]; break; }
      if (!layer || !resolveLayerMaterial(layer)) {
        status('无法获取烫材：材质库为空或手动指定的贴图已丢失，请重新选择', 'err');
        return;
      }
    }
    saveState();
    renderLayerList();
    if (!cep.available || !renderer) {
      status('环境不可用（CEP/WebGL），无法导出', 'err');
      return;
    }
    setBusy(true);
    status('正在读取文档…', 'busy');
    var topLayerId = state.layers.length ? state.layers[0].id : -1;
    var placedIds = [];
    var groupedName = '';
    ps.getDocInfo(function (info) {
      if (!info.ok) {
        setBusy(false);
        status('读取文档失败：' + info.error, 'err');
        return;
      }
      state.doc = info;
      var res = { widthPx: info.widthPx, heightPx: info.heightPx, dpi: info.dpi };
      var foils = [];
      for (var k = 0; k < roles.foil.length; k++) {
        var lid = roles.foil[k];
        var lname = '';
        for (var q = 0; q < state.layers.length; q++) {
          if (state.layers[q].id === lid) { lname = state.layers[q].name; break; }
        }
        foils.push({
          id: lid,
          name: lname || ('#' + lid),
          prio: state.layerPrio[lid] || 1,
          mat: state.layerMat[lid] || ''
        });
      }
      foils.sort(function (a, b) { return b.prio - a.prio; });
      var cutCanvas = null;
      var printImg = null;
      var printIds = roles.print.join(',');
      var cutIds = roles.cut.join(',');
      var tasks = [];
      tasks.push(function (next) {
        if (!cutIds) { next(); return; }
        status('正在导出刀线图层…', 'busy');
        ps.exportByIds(cep.workDir, 'cutall.png', cutIds, function (r) {
          if (!r || !r.ok) {
            status('刀线导出失败：' + (r && r.error ? r.error : '?') + '（本次不裁切）', 'err');
            next();
            return;
          }
          cep.imageDataUrl(cep.workDir + '/cutall.png', function (url) {
            if (!url) { next(); return; }
            var im = new Image();
            im.onload = function () {
              try {
                var p = window.FoilUCut.process(im, res.widthPx, res.heightPx, state.cutMode);
                if (p.canvas) {
                  cutCanvas = p.canvas;
                  status('刀线已识别（' + (p.mode === 'fill' ? '填充' : '轮廓') + '，覆盖率 ' + Math.round((p.coverage || 0) * 100) + '%）', 'busy');
                } else {
                  status('刀线内容为空，本次不裁切', 'err');
                }
              } catch (eC) {}
              next();
            };
            im.onerror = function () { next(); };
            im.src = url;
          });
        });
      });
      tasks.push(function (next) {
        if (!printIds) { next(); return; }
        status('正在导出印刷层…', 'busy');
        ps.exportByIds(cep.workDir, 'printall.png', printIds, function (r) {
          if (!r || !r.ok) {
            status('印刷层导出失败，将不生成印刷模切', 'err');
            next();
            return;
          }
          cep.imageDataUrl(cep.workDir + '/printall.png', function (url) {
            if (!url) { next(); return; }
            var im = new Image();
            im.onload = function () { printImg = im; next(); };
            im.onerror = function () { next(); };
            im.src = url;
          });
        });
      });
      foils.forEach(function (f) {
        tasks.push(function (next) {
          status('正在导出烫色层「' + f.name + '」…', 'busy');
          ps.exportByIds(cep.workDir, 'fm_' + f.id + '.png', String(f.id), function (r) {
            if (!r || !r.ok) {
              status('烫色层「' + f.name + '」导出失败，已跳过', 'err');
              f.skip = true;
            }
            next();
          });
        });
      });
      foils.forEach(function (f) {
        tasks.push(function (next) {
          if (f.skip) { next(); return; }
          status('正在渲染「' + f.name + '」（' + f.mat + '，优先级 ' + f.prio + '）…', 'busy');
          renderFoilEntry(f, res, cutCanvas, next);
        });
      });
      tasks.push(function (next) {
        var idx = 0;
        function placeNext() {
          if (idx >= foils.length) {
            if (printImg) {
              status('正在生成印刷层模切…', 'busy');
              makePrintCutMulti(printImg, res, cutCanvas, topLayerId, function (pid) { if (pid) placedIds.push(pid); next(); });
            } else {
              next();
            }
            return;
          }
          var f = foils[idx++];
          if (!f.output) { placeNext(); return; }
          var mshort = f.mat.slice(0, 20);
          var lname = timestampName() + '-' + mshort + GEN_MARK;
          ps.placeResult(f.output, lname, f.scale, topLayerId, f.expL, f.expT, '-' + mshort + GEN_MARK, f.pngW, f.pngH, function (r) {
            if (!r || !r.ok) status('「' + f.name + '」写回失败：' + (r && r.error ? r.error : '?'), 'err');
            if (r && r.ok) {
              placedIds.push(r.layerId);
              if (state.session) state.session.lastPlacedLayerId = r.layerId;
            }
            placeNext();
          });
        }
        placeNext();
      });
      tasks.push(function (next) {
        var hideIds = roles.foil.concat(roles.print).concat(roles.cut).join(',');
        if (!hideIds) { next(); return; }
        ps.setLayersVisible(hideIds, false, function (r) {
          if (r && r.ok) status('已隐藏 ' + r.count + ' 个原始图层（内容未改动）', 'ok');
          next();
        });
      });
      tasks.push(function (next) {
        if (!placedIds.length) { next(); return; }
        var gname = timestampName() + GEN_MARK;
        status('正在把生成结果编组…', 'busy');
        ps.groupGenerated(gname, placedIds.join(','), function (r) {
          if (r && r.ok) {
            groupedName = gname.replace(GEN_MARK, '');
            status('生成结果已编组为「' + groupedName + '」（已收起，旧生成组已隐藏）', 'ok');
          } else {
            status('编组失败：' + ((r && r.error) || '?'), 'err');
          }
          next();
        });
      });
      var runIdx = 0;
      function runner() {
        if (runIdx >= tasks.length) {
          setBusy(false);
          var placed = 0;
          for (var v = 0; v < foils.length; v++) if (foils[v].output) placed++;
          status('多图层导出完成：烫色 ' + placed + ' 层' + (printImg ? ' + 印刷模切' : '') + (cutCanvas ? '（含刀线裁切）' : '') + (groupedName ? '，已编组「' + groupedName + '」并收起' : '') + '，原始图层已隐藏', 'ok');
          refreshLayerList();
          return;
        }
        var t = tasks[runIdx++];
        t(runner);
      }
      runner();
    });
  }

  function applyFoil() {
    if (!cep.available) {
      status('CEP Node 未启用，无法写回图层', 'err');
      return;
    }
    if (!renderer) {
      status('WebGL 不可用，无法渲染', 'err');
      return;
    }
    if (state.busy) return;
    var roleIds = { foil: [], print: [], cut: [] };
    var anyRole = false;
    for (var li = 0; li < state.layers.length; li++) {
      var LL = state.layers[li];
      var rr = state.layerRoles[LL.id] || 'ignore';
      if (rr !== 'ignore') {
        anyRole = true;
        if (roleIds[rr]) roleIds[rr].push(LL.id);
      }
    }
    if (anyRole) {
      applyMulti(roleIds);
      return;
    }
    setBusy(true);
    status('正在从 Photoshop 导出所选图层…', 'busy');
    ps.getDocInfo(function (info) {
      if (!info.ok) {
        setBusy(false);
        status('读取文档失败：' + info.error, 'err');
        return;
      }
      ps.exportAssets(cep.workDir, 0, 0, function (res) {
        if (!res.ok) {
          setBusy(false);
          status('导出图层失败：' + res.error, 'err');
          return;
        }
        var printFound = false;
        var afterPrint = function () {
          cep.imageDataUrl(cep.workDir + '/mask.png', function (urlMask) {
          if (!urlMask) {
            setBusy(false);
            status('无法读取蒙版文件', 'err');
            return;
          }
          var img = new Image();
          img.onload = function () {
            if (!maskHasContent(img)) {
              setBusy(false);
              status('所选图层没有可烫印的内容（图层为空或完全透明）', 'err');
              return;
            }
            state.maskCov = maskCoverage(img);
            var size;
            try {
              size = renderer.setMask(img, res.widthPx, res.heightPx, res.maskW, res.maskH);
            } catch (e) {
              setBusy(false);
              status('蒙版初始化失败：' + e.message, 'err');
              return;
            }
            var proceed = function () {
              var out = document.createElement('canvas');
              out.width = size.w;
              out.height = size.h;
              var octx = out.getContext('2d');
              status('正在渲染全尺寸效果…', 'busy');
              setTimeout(function () {
                try {
                  renderer.render(octx, size.w, size.h, { x: 0, y: 0, w: res.widthPx, h: res.heightPx }, currentParams(res.dpi));
                } catch (e) {
                  setBusy(false);
                  status('渲染失败：' + e.message, 'err');
                  return;
                }
                var bbox = null;
                try { bbox = canvasAlphaBBox(out); } catch (eB) {}
                if (!bbox) {
                  setBusy(false);
                  status('效果内容为空（可能被刀线裁切排除），未生成图层', 'err');
                  return;
                }
                var makePrintCut = function (pim, onDone) {
                  try {
                    var pc = document.createElement('canvas');
                    pc.width = res.widthPx;
                    pc.height = res.heightPx;
                    var pctx = pc.getContext('2d');
                    pctx.drawImage(pim, 0, 0, res.widthPx, res.heightPx);
                    pctx.globalCompositeOperation = 'destination-in';
                    pctx.drawImage(state.cutCanvas, 0, 0, res.widthPx, res.heightPx);
                    pctx.globalCompositeOperation = 'source-over';
                    var pbb = null;
                    try { pbb = canvasAlphaBBox(pc); } catch (eP) {}
                    if (!pbb) {
                      onDone(false);
                      return;
                    }
                    status('正在生成印刷层模切…', 'busy');
                    pc.toBlob(function (pblob) {
                      if (!pblob) {
                        onDone(false);
                        return;
                      }
                      var pfr = new FileReader();
                      pfr.onload = function () {
                        var pbytes = new Uint8Array(pfr.result);
                        var ppath = cep.workDir + '/printcut.png';
                        if (!cep.writeBuffer(ppath, pbytes)) {
                          onDone(false);
                          return;
                        }
                        var pName = timestampName() + '-印刷(模切)' + GEN_MARK;
                        ps.placeResult(ppath, pName, 1, res.layerId, pbb.x0, pbb.y0, '-印刷(模切)' + GEN_MARK, pc.width, pc.height, function (pr) {
                          onDone(pr && pr.ok ? pr.layerId : 0);
                        });
                      };
                      pfr.readAsArrayBuffer(pblob);
                    }, 'image/png');
                  } catch (ePC) {
                    onDone(false);
                  }
                };
                var doPrintCut = function (onDone) {
                  if (!(state.cut && state.cutCanvas && printFound)) {
                    onDone(false);
                    return;
                  }
                  cep.imageDataUrl(cep.workDir + '/print.png', function (urlPrint) {
                    if (!urlPrint) {
                      onDone(false);
                      return;
                    }
                    var pim = new Image();
                    pim.onload = function () { makePrintCut(pim, onDone); };
                    pim.onerror = function () { onDone(false); };
                    pim.src = urlPrint;
                  });
                };
                status('正在写回 Photoshop…', 'busy');
                out.toBlob(function (blob) {
                  if (!blob) {
                    setBusy(false);
                    status('生成 PNG 失败（画布可能过大）', 'err');
                    return;
                  }
                  var fr = new FileReader();
                  fr.onload = function () {
                    var bytes = new Uint8Array(fr.result);
                    if (!cep.writeBuffer(cep.resultPath, bytes)) {
                      setBusy(false);
                      status('写入临时文件失败', 'err');
                      return;
                    }
                    var scale = size.w / res.widthPx;
                    var outName = timestampName() + '-' + ((state.materialName || '烫色').slice(0, 20)) + GEN_MARK;
                    var expL = bbox.x0 / scale;
                    var expT = bbox.y0 / scale;
                    var suffix = '-' + ((state.materialName || '烫色').slice(0, 20)) + GEN_MARK;
                    ps.placeResult(cep.resultPath, outName, scale, res.layerId, expL, expT, suffix, out.width, out.height, function (r) {
                      if (!r.ok) {
                        setBusy(false);
                        status('生成失败：' + r.error, 'err');
                        return;
                      }
                      if (state.session) state.session.lastPlacedLayerId = r.layerId;
                      state.placeMode = r.legacy ? ('legacy' + (r.plcErr ? '：' + r.plcErr : '')) : 'place';
                      var legacyIds = [r.layerId];
                      doPrintCut(function (printDone) {
                        if (printDone) legacyIds.push(printDone);
                        var gname = timestampName() + GEN_MARK;
                        ps.groupGenerated(gname, legacyIds.join(','), function (gr) {
                          var grouped = gr && gr.ok ? gname.replace(GEN_MARK, '') : '';
                          setBusy(false);
                          var extra = printDone ? '（含印刷层模切）' : (state.cut && state.cutCanvas && !printFound ? '（未找到名称含「印刷」或「柄图」的图层）' : '');
                          status('已生成烫色图层：' + r.layerName + (grouped ? '，已编组「' + grouped + '」并收起' : '') + extra + '（位于所选图层上方，旧生成组已隐藏）', 'ok');
                        });
                      });
                    });
                  };
                  fr.readAsArrayBuffer(blob);
                }, 'image/png');
              }, 30);
            };
            refreshCut(proceed);
          };
          img.onerror = function () {
            setBusy(false);
            status('蒙版图片解码失败', 'err');
          };
          img.src = urlMask;
          });
        };
        if (state.cut && ps.exportPrintLayer) {
          ps.exportPrintLayer(cep.workDir, function (pres) {
            printFound = !!(pres && pres.ok && pres.found);
            afterPrint();
          });
        } else {
          afterPrint();
        }
      });
    });
  }

  function safeBase(name) {
    var s = String(name).replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_').replace(/^\.+/, '').trim();
    return s || '材质';
  }

  function finishAdd(dest, label, note, mirror, specials) {
    var fname = dest.substring(dest.lastIndexOf('/') + 1);
    var meta = state.customMeta[fname] || {};
    if (mirror) meta.mirror = true; else delete meta.mirror;
    if (specials && specials.pearl) meta.pearl = true; else delete meta.pearl;
    if (specials && specials.transparent) meta.transparent = true; else delete meta.transparent;
    if (meta.mirror || meta.pearl || meta.transparent) state.customMeta[fname] = meta;
    else delete state.customMeta[fname];
    cep.writeMeta(state.customMeta);
    delete state.thumbCache[dest];
    scanLibrary();
    rebuildMaterialUI();
    selectMaterial(dest, false);
    status('已添加自定义材质：' + label + note, 'ok');
  }

  function fileMime(name) {
    var ext = String(name).split('.').pop().toLowerCase();
    var map = {
      jpg: 'image/jpeg', jpeg: 'image/jpeg', jfif: 'image/jpeg', pjpeg: 'image/jpeg',
      png: 'image/png', webp: 'image/webp', bmp: 'image/bmp', gif: 'image/gif', avif: 'image/avif'
    };
    return map[ext] || 'image/png';
  }

  function fileExt(name) {
    var ext = String(name).split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '');
    return ext || 'png';
  }

  function onCustomFile(file) {
    if (!file) return;
    if (!/\.(png|jpe?g|jfif|pjpeg|webp|bmp|gif|avif)$/i.test(file.name)) {
      status('该文件不是常见图片格式（支持 PNG / JPEG / WebP / BMP / GIF 等）', 'err');
      return;
    }
    var fr = new FileReader();
    fr.onload = function () {
      var bytes = new Uint8Array(fr.result);
      var url = URL.createObjectURL(new Blob([bytes], { type: fileMime(file.name) }));
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        startPending(file, bytes, img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        status('无法读取所选图片', 'err');
      };
      img.src = url;
    };
    fr.readAsArrayBuffer(file);
  }

  function setProcStatus(t) {
    $('procStatus').textContent = t;
  }

  function procSourceCanvas(maxDim, raw, whole) {
    var p = state.pending;
    if (!p) return null;
    var img = p.img;
    var w = img.naturalWidth;
    var h = img.naturalHeight;
    var s = Math.min(1, (maxDim || 1000) / Math.max(w, h));
    var c = document.createElement('canvas');
    c.width = Math.max(8, Math.round(w * s));
    c.height = Math.max(8, Math.round(h * s));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    if (!raw && p.angle) c = window.FoilUSwatch.rotateCanvas(c, p.angle);
    if (!raw && !whole && p.region) {
      var r=p.region,cut=document.createElement('canvas');cut.width=Math.max(8,Math.round(r.w*c.width));cut.height=Math.max(8,Math.round(r.h*c.height));
      cut.getContext('2d').drawImage(c,r.x*c.width,r.y*c.height,r.w*c.width,r.h*c.height,0,0,cut.width,cut.height);c=cut;
    }
    return c;
  }

  function drawProcSource() {
    if (!state.pending) return;
    var src=procSourceCanvas(500,false,true),cv=$('procSource');cv.width=src.width;cv.height=src.height;
    var ctx=cv.getContext('2d');ctx.drawImage(src,0,0);var r=state.pending.region;
    if(r){ctx.strokeStyle='#ffc75c';ctx.lineWidth=3;ctx.strokeRect(r.x*cv.width,r.y*cv.height,r.w*cv.width,r.h*cv.height);}
  }
  function bindProcRegion() {
    var cv=$('procSource'),start=null;
    function point(e){var b=cv.getBoundingClientRect();return {x:Math.max(0,Math.min(1,(e.clientX-b.left)/b.width)),y:Math.max(0,Math.min(1,(e.clientY-b.top)/b.height))};}
    cv.addEventListener('pointerdown',function(e){if(!state.pending)return;start=point(e);cv.setPointerCapture(e.pointerId);e.preventDefault();});
    cv.addEventListener('pointermove',function(e){if(!start || !state.pending)return;var p=point(e);state.pending.region={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};drawProcSource();});
    cv.addEventListener('pointerup',function(e){if(!start || !state.pending)return;var p=point(e);state.pending.region={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};start=null;if(state.pending.region.w<.02 || state.pending.region.h<.02)state.pending.region=null;renderProcPreview();});
    cv.addEventListener('pointercancel',function(){start=null;});
    $('procClearRegion').addEventListener('click',function(){if(state.pending){state.pending.region=null;renderProcPreview();}});
    $('procCalibrate').addEventListener('change',renderProcPreview);
    $('procReference').addEventListener('change',refreshProcReference);
    $('procName').addEventListener('input',function(){if(state.pending)state.pending.nameEdited=true;refreshProcReference();});
  }

  function refreshProcReference() {
    var p=state.pending;if(!p)return;
    var token=++p.referenceToken || (p.referenceToken=1),name=$('procName').value.toUpperCase(),hits=[];
    p.referenceImg=null;p.referenceName='';
    if ($('procReference').checked) state.builtin.forEach(function(m){
      var code=m.name.match(/(?:^|[-_])([A-Z]{1,3}[0-9]+(?:-[0-9A-Z]+)*)(?=[-_]|$)/i);
      if(code && new RegExp('(^|[^A-Z0-9])'+code[1].toUpperCase()+'(?=$|[^A-Z0-9-])').test(name))hits.push(m);
    });
    renderProcPreview();
    if(hits.length!==1)return;
    cep.imageDataUrl(hits[0].path,function(url){if(!url || state.pending!==p || p.referenceToken!==token)return;var im=new Image();im.onload=function(){if(state.pending!==p || p.referenceToken!==token)return;p.referenceImg=im;p.referenceName=hits[0].name;renderProcPreview();};im.src=url;});
  }

  function pendingSwatch() {
    var p = state.pending;
    var key = [p.angle || 0, $('procCrop').checked, $('procDering').checked, $('procCalibrate').checked, JSON.stringify(p.region || null), $('procName').value, $('procReference').checked, p.referenceName || ''].join('|');
    if (p.swatchCache && p.swatchCache.key === key) return p.swatchCache.result;
    var src = procSourceCanvas(2200, false);
    var result = window.FoilUSwatch.process(src, { crop: $('procCrop').checked, dering: $('procDering').checked });
    if ($('procReference').checked && p.referenceImg) {
      var ref=document.createElement('canvas');ref.width=p.referenceImg.naturalWidth;ref.height=p.referenceImg.naturalHeight;ref.getContext('2d').drawImage(p.referenceImg,0,0);result.canvas=ref;result.referenceName=p.referenceName;
    }
    if (!result.referenceName && $('procCalibrate').checked && (result.cropFound || p.region)) result.calibration=window.FoilUMaterialLearning.enhance(result.canvas);
    p.swatchCache = { key: key, result: result };
    return result;
  }

  function renderProcPreview() {
    var p = state.pending;
    if (!p) return;
    drawProcSource();
    var src = procSourceCanvas(2200, false);
    var opts = { crop: $('procCrop').checked, dering: $('procDering').checked };
    var pr;
    try {
      pr = pendingSwatch();
    } catch (e) {
      pr = { canvas: src, cropFound: false, ringFound: false };
    }
    var shown = pr.canvas;
    try {
      if (state.autoProcess) {
        shown = state.processMode === 'mirror'
          ? window.FoilUSeam.coverSquare(shown, 1000)
          : window.FoilUSeam.makeSeamless(shown, 1000, state.seamFeather).canvas;
      }
    } catch (e2) {}
    var cv = $('procPreview');
    var ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, cv.width, cv.height);
    var s2 = Math.min(cv.width / shown.width, cv.height / shown.height);
    var dw = Math.max(1, Math.round(shown.width * s2));
    var dh = Math.max(1, Math.round(shown.height * s2));
    ctx.drawImage(shown, Math.round((cv.width - dw) / 2), Math.round((cv.height - dh) / 2), dw, dh);
    var parts = [];
    if (p.region) parts.push('已框选单个色号');
    if (pr.referenceName) parts.push('使用库内参考：' + pr.referenceName);
    if (pr.calibration) parts.push(pr.calibration.reason);
    if (!state.autoProcess) {
      parts.push('不自动处理（按原图入库）');
    } else {
      parts.push(opts.crop ? (pr.cropFound ? '已找到色卡并裁切' : '未找到色卡（使用整图）') : '未裁切色卡');
      if (opts.crop && opts.dering) parts.push(pr.ringFound ? '已检测并去除圆环压痕' : '未检测到圆环');
      parts.push(state.processMode === 'mirror' ? '镜像平铺' : '接缝融合');
    }
    setProcStatus(parts.join(' · '));
  }

  function startPending(file, bytes, img) {
    state.pending = {
      file: file,
      bytes: bytes,
      img: img,
      angle: 0,
      name: safeBase(file.name),
      referenceToken: 0,
      ocrText: '',
      confirmed: false
    };
    $('processPanel').style.display = '';
    $('procName').value = state.pending.name;
    $('procCrop').checked = true;
    $('procDering').checked = true;
    $('procCalibrate').checked = true;
    $('procReference').checked = true;
    $('procAutoName').checked = true;
    $('procPearl').checked = /珠光/.test(state.pending.name);
    $('procTransparent').checked = /透明/.test(state.pending.name);
    refreshProcReference();
    autoOrientPending();
  }

  function cancelPending() {
    state.pending = null;
    $('processPanel').style.display = 'none';
    var cv = $('procPreview');
    cv.getContext('2d').clearRect(0, 0, cv.width, cv.height);
  }

  function autoOrientPending() {
    var p = state.pending;
    if (!p || p.confirmed) return;
    if (!window.FoilUOcr || !window.FoilUOcr.available()) {
      setProcStatus('文字识别不可用，可手动旋转');
      return;
    }
    p.ocrRunning = true;
    setProcStatus('正在识别文字方向…');
    var raw = procSourceCanvas(1800, true);
    window.FoilUOcr.detectOrientation(raw, function (best) {
      if (!state.pending || state.pending !== p || p.confirmed) return;
      p.ocrRunning = false;
      var text = best && best.text ? window.FoilUOcr.cleanText(best.text) : '';
      if (best && best.score >= 3) {
        if (p.angle !== best.angle) p.region = null;
        p.angle = best.angle;
        p.ocrText = text;
        if (!p.nameEdited && $('procAutoName').checked && text) $('procName').value = text;
        refreshProcReference();
        setProcStatus($('procStatus').textContent + ' · 已按文字自动校正方向' + (text ? '，识别文字：' + text : ''));
      } else {
        p.ocrText = text;
        if (!p.nameEdited && text && $('procAutoName').checked) $('procName').value = text;
        refreshProcReference();
        setProcStatus($('procStatus').textContent + ' · ' + (text ? '识别到文字：' + text + '（方向置信度低，可手动旋转）' : '未识别到文字，可手动旋转'));
      }
    });
  }

  function saveProcessedCanvas(cv, baseName, note, mirror, specials, done) {
    cv.toBlob(function (outBlob) {
      if (!outBlob) {
        status('处理结果编码失败', 'err');
        done();
        return;
      }
      var fr = new FileReader();
      fr.onload = function () {
        var dest = cep.customDir + '/' + baseName + '.png';
        if (cep.fs.existsSync(dest) && !window.confirm('已存在同名材质，覆盖？')) {
          done();
          return;
        }
        if (!cep.writeBuffer(dest, new Uint8Array(fr.result))) {
          status('写入失败：无法写入自定义材质目录', 'err');
          done();
          return;
        }
        finishAdd(dest, baseName, note, mirror, specials);
        done();
      };
      fr.readAsArrayBuffer(outBlob);
    }, 'image/png');
  }

  function pendingFlags() {
    return {
      pearl: !!(($('procPearl') || {}).checked),
      transparent: !!(($('procTransparent') || {}).checked)
    };
  }

  function confirmPending() {
    var p = state.pending;
    if (!p || p.confirmed || state.busy) return;
    var name = safeBase($('procName').value || p.name);
    p.confirmed = true;
    setBusy(true);
    status('正在处理素材…', 'busy');
    setTimeout(function () {
      try {
        if (!state.autoProcess) {
          var ext = fileExt(p.file.name);
          var dest = cep.customDir + '/' + name + '.' + ext;
          if (cep.fs.existsSync(dest) && !window.confirm('已存在同名材质，覆盖？')) {
            p.confirmed = false;
            setBusy(false);
            return;
          }
          if (!cep.writeBuffer(dest, p.bytes)) {
            p.confirmed = false;
            setBusy(false);
            status('写入失败：无法写入自定义材质目录', 'err');
            return;
          }
          cancelPending();
          setBusy(false);
          finishAdd(dest, name, '', false, pendingFlags());
          return;
        }
        var src = procSourceCanvas(2200, false);
        var pr = pendingSwatch();
        var outCanvas;
        var note;
        if (state.processMode === 'mirror') {
          outCanvas = window.FoilUSeam.coverSquare(pr.canvas, 1000);
          note = '（镜像平铺，零拼接线）';
        } else if (window.FoilUSeam.hasSignificantAlpha(pr.canvas) &&
                   !window.confirm('检测到贴图含透明区域，接缝融合会混合透明图案。仍然融合吗？（取消则仅缩放不融合）')) {
          outCanvas = window.FoilUSeam.coverSquare(pr.canvas, 1000);
          note = '（未融合，仅缩放）';
        } else {
          var sm = window.FoilUSeam.makeSeamless(pr.canvas, 1000, state.seamFeather);
          outCanvas = sm.canvas;
          note = sm.blended ? '（已处理为 1000×1000 四方连续）' : '（已处理为 1000×1000，原图已接近连续）';
        }
        if (pr.cropFound) note = '（已裁切色卡' + (pr.ringFound ? '、去除圆环' : '') + '）' + note;
        saveProcessedCanvas(outCanvas, name, note, state.processMode === 'mirror', pendingFlags(), function () {
          cancelPending();
          setBusy(false);
        });
      } catch (e) {
        p.confirmed = false;
        setBusy(false);
        status('处理失败：' + e.message, 'err');
      }
    }, 30);
  }

  function startRenameCustom(m, nameEl) {
    if (nameEl.querySelector('input')) return;
    var old = m.name;
    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'renameInput';
    input.value = old;
    nameEl.textContent = '';
    nameEl.appendChild(input);
    input.focus();
    input.select();
    var done = false;
    function cancel() {
      if (done) return;
      done = true;
      rebuildMaterialUI();
    }
    function commit() {
      if (done) return;
      done = true;
      var v = input.value.replace(/[\\/:*?"<>|]/g, '_').replace(/^\.+/, '').trim();
      if (!v || v === old) {
        rebuildMaterialUI();
        return;
      }
      var dot = m.path.lastIndexOf('.');
      var ext = dot >= 0 ? m.path.substring(dot) : '.png';
      var dest = cep.customDir + '/' + v + ext;
      if (cep.fs.existsSync(dest)) {
        status('已存在同名材质：' + v, 'err');
        rebuildMaterialUI();
        return;
      }
      try {
        cep.fs.renameSync(m.path, dest);
      } catch (e) {
        status('重命名失败：' + e.message, 'err');
        rebuildMaterialUI();
        return;
      }
      if (state.customMeta[m.file]) {
        state.customMeta[v + ext] = state.customMeta[m.file];
        delete state.customMeta[m.file];
        cep.writeMeta(state.customMeta);
      }
      delete state.thumbCache[m.path];
      if (state.materialPath === m.path) {
        state.materialPath = dest;
        state.materialName = v;
      }
      scanLibrary();
      rebuildMaterialUI();
      saveState();
      status('已重命名为：' + v, 'ok');
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        commit();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        cancel();
      }
    });
    input.addEventListener('blur', commit);
    input.addEventListener('click', function (e) {
      e.stopPropagation();
    });
    input.addEventListener('dblclick', function (e) {
      e.stopPropagation();
    });
  }

  function initFxUI() {
    var p = state.params;
    $('rngDepth').value = Math.round(p.depthMm * 100);
    $('valDepth').textContent = p.depthMm.toFixed(2) + 'mm';
    $('rngRelief').value = Math.round(p.relief * 100);
    $('valRelief').textContent = Math.round(p.relief * 100) + '%';
    $('rngSpec').value = Math.round(p.spec * 100);
    $('valSpec').textContent = Math.round(p.spec * 100) + '%';
    $('rngLight').value = p.light;
    $('valLight').textContent = p.light + '°';
    $('rngScale').value = Math.round(p.texScale * 100);
    $('valScale').textContent = (30 / p.texScale).toFixed(1) + 'mm';
    $('rngCrease').value = Math.round(p.crease * 100);
    $('valCrease').textContent = Math.round(p.crease * 100) + '%';
    $('rngPearlAlpha').value = Math.round(p.pearlAlpha * 100);
    $('valPearlAlpha').textContent = Math.round(p.pearlAlpha * 100) + '%';
    $('rngTranAlpha').value = Math.round(p.tranAlpha * 100);
    $('valTranAlpha').textContent = Math.round(p.tranAlpha * 100) + '%';
    updateSpecialLabels();
  }

  function setWheelColor(r, g, b) {
    state.pearlColor = { r: r, g: g, b: b };
    if (wheel) wheel.set(r, g, b);
    $('inR').value = r;
    $('inG').value = g;
    $('inB').value = b;
    updatePearlSwatches();
    saveState();
    scheduleRender();
  }

  function initWheel() {
    wheel = new window.FoilWheel($('wheelCanvas'), function (rgb) {
      state.pearlColor = rgb;
      $('inR').value = rgb.r;
      $('inG').value = rgb.g;
      $('inB').value = rgb.b;
      updatePearlSwatches();
      saveState();
      scheduleRender();
    });
    wheel.set(state.pearlColor.r, state.pearlColor.g, state.pearlColor.b);
    ['inR', 'inG', 'inB'].forEach(function (id) {
      $(id).addEventListener('input', function () {
        var r = Math.max(0, Math.min(255, Number($('inR').value) || 0));
        var g = Math.max(0, Math.min(255, Number($('inG').value) || 0));
        var b = Math.max(0, Math.min(255, Number($('inB').value) || 0));
        if (wheel) wheel.set(r, g, b);
        state.pearlColor = { r: r, g: g, b: b };
        updatePearlSwatches();
        saveState();
        scheduleRender();
      });
    });
  }

  function showView(name) {
    state.view = name;
    document.querySelectorAll('.view').forEach(function (v) {
      v.classList.remove('active');
    });
    var el = $('view-' + name);
    if (el) el.classList.add('active');
    document.querySelectorAll('.railBtn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.view === name);
    });
    if (name === 'lib') { buildLibBrands(); buildLibTags(); buildLibGrid(); }
    if (name === 'custom') buildCustomList();
    if (name === 'wheel' && wheel) wheel.redraw();
  }

  function updateDocStatus() {
    if (Date.now() - lastMsg.time < 4000) return;
    if (!state.doc) {
      status('未检测到打开的 Photoshop 文档，请先打开文档并选中图层', 'info');
      return;
    }
    var i = state.doc;
    var name = i.docName.length > 18 ? i.docName.slice(0, 17) + '…' : i.docName;
    status(name + ' · ' + i.widthPx + '×' + i.heightPx + 'px · ' + i.dpi + 'dpi · ' + mmOf(i.widthPx, i.dpi) + '×' + mmOf(i.heightPx, i.dpi) + 'mm · 选中：' + i.layerName, 'info');
  }

  function markStale() {
    state.stale = true;
    $('previewWrap').classList.add('stale');
    if (!state.staleNotified) {
      state.staleNotified = true;
      status('检测到图层或文档变化，请点击「刷新」更新预览', 'info');
    }
  }

  function poll() {
    if (!cep.available || state.busy) return;
    ps.getDocInfo(function (info) {
      if (!info.ok) {
        state.doc = null;
        updateDocStatus();
        return;
      }
      var docSwitched = !state.doc || state.doc.docName !== info.docName;
      state.doc = info;
      updateDocStatus();
      if (state.session) {
        var matches = info.layerId === state.session.layerId || info.layerId === state.session.lastPlacedLayerId;
        if (docSwitched || !matches) markStale();
      } else if (state.materialImg && !state.busy && !state.autoTried) {
        state.autoTried = true;
        refreshPreview();
      }
    });
  }

  function bindUI() {
    document.querySelectorAll('.railBtn').forEach(function (b) {
      b.addEventListener('click', function () {
        showView(b.dataset.view);
      });
    });
    $('pearlDot').addEventListener('click', function (e) {
      e.stopPropagation();
      showView('wheel');
    });
    $('btnApply').addEventListener('click', applyFoil);
    $('btnCopyStatus').addEventListener('click', onCopyStatus);
    $('btnGoCustom').addEventListener('click', function () {
      showView('custom');
    });
    $('btnGoWheel').addEventListener('click', function () {
      showView('wheel');
    });
    $('cutToggle').addEventListener('click', function () {
      state.cut = !state.cut;
      saveState();
      updateCutUI();
      refreshCut();
    });
    $('cutPattern').addEventListener('change', function () {
      state.cutPattern = this.value || '模切|刀线';
      this.value = state.cutPattern;
      saveState();
    });
    $('btnCutRefresh').addEventListener('click', function () {
      refreshCut();
    });
    var cutModeBtns = document.querySelectorAll('.cutModeBtn');
    for (var mb = 0; mb < cutModeBtns.length; mb++) {
      cutModeBtns[mb].addEventListener('click', function () {
        state.cutMode = this.getAttribute('data-cutmode') || 'auto';
        saveState();
        updateCutUI();
        if (state.cut) refreshCut();
      });
    }
    $('btnPickFile').addEventListener('click', function () {
      $('customFile').click();
    });
    $('customFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      onCustomFile(f);
      e.target.value = '';
    });
    $('remountFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      e.target.value = '';
      if (f && remountName) {
        var nm = remountName;
        remountName = '';
        handleRemount(f, nm);
      }
    });
    $('libSearch').addEventListener('input', function () {
      state.libSearch = this.value || '';
      if (libSearchTimer) clearTimeout(libSearchTimer);
      libSearchTimer = setTimeout(function () {
        buildLibGrid();
      }, 180);
    });
    $('libSearchClear').addEventListener('click', function () {
      state.libSearch = '';
      $('libSearch').value = '';
      buildLibGrid();
    });
    $('btnRandomMatch').addEventListener('click', randomMatchMaterials);
    $('poolClear').addEventListener('click', function () {
      state.matPool = [];
      updatePoolUI();
      renderLayerList();
      buildLibGrid();
      status('已清空备选烫材池', 'ok');
    });
    $('btnAutoMatch').addEventListener('click', function () {
      if (!state.layers.length) {
        status('还没有读取到图层：请先点预览区的「刷新」', 'err');
        return;
      }
      runAutoMatch(true);
      if (state.cut) refreshCut();
      status('已更新自动匹配，保留手动用途及烫材；重置单层后可重新匹配', 'ok');
    });
    var routeLinks = document.querySelectorAll('.routeGo');
    for (var rg = 0; rg < routeLinks.length; rg++) {
      routeLinks[rg].addEventListener('click', function () {
        showView(this.getAttribute('data-go') || 'main');
      });
    }
    $('autoProcess').addEventListener('change', function () {
      state.autoProcess = this.checked;
      syncSeamUI();
      saveState();
      if (state.pending) renderProcPreview();
    });
    $('rngSeamFeather').addEventListener('input', function () {
      state.seamFeather = Number(this.value) / 100;
      $('valSeamFeather').textContent = this.value + '%';
      saveState();
    });
    $('processMode').addEventListener('change', function () {
      state.processMode = this.value === 'mirror' ? 'mirror' : 'fusion';
      syncSeamUI();
      saveState();
      if (state.pending) renderProcPreview();
    });
    $('procRotL').addEventListener('click', function () {
      if (!state.pending) return;
      state.pending.region = null;
      state.pending.angle = (state.pending.angle + 270) % 360;
      renderProcPreview();
    });
    $('procRotR').addEventListener('click', function () {
      if (!state.pending) return;
      state.pending.region = null;
      state.pending.angle = (state.pending.angle + 90) % 360;
      renderProcPreview();
    });
    $('procRot180').addEventListener('click', function () {
      if (!state.pending) return;
      state.pending.region = null;
      state.pending.angle = (state.pending.angle + 180) % 360;
      renderProcPreview();
    });
    $('procAutoRot').addEventListener('click', autoOrientPending);
    bindProcRegion();
    $('procCrop').addEventListener('change', renderProcPreview);
    $('procDering').addEventListener('change', renderProcPreview);
    $('procAutoName').addEventListener('change', function () {
      if (this.checked && state.pending && state.pending.ocrText) {
        $('procName').value = state.pending.ocrText;
        refreshProcReference();
      }
    });
    $('procConfirm').addEventListener('click', confirmPending);
    $('procCancel').addEventListener('click', function () {
      if (state.pending) state.pending.confirmed = true;
      cancelPending();
    });
    ['zoomFit', 'zoom100', 'zoom200'].forEach(function (id) {
      $(id).addEventListener('click', function () {
        state.zoom = id === 'zoomFit' ? 'fit' : id === 'zoom100' ? '100' : '200';
        saveState();
        updateZoomButtons();
        renderPreview();
      });
    });
    $('rotL').addEventListener('click', function () {
      state.viewRotOffset = ((state.viewRotOffset || 0) - 90) % 360;
      saveState();
      applyPreviewRotation();
    });
    $('rotR').addEventListener('click', function () {
      state.viewRotOffset = ((state.viewRotOffset || 0) + 90) % 360;
      saveState();
      applyPreviewRotation();
    });
    $('btnRefresh').addEventListener('click', function () {
      refreshPreview();
    });
    $('rngDepth').addEventListener('input', function () {
      state.params.depthMm = Number(this.value) / 100;
      $('valDepth').textContent = state.params.depthMm.toFixed(2) + 'mm';
      saveState();
      scheduleRender();
    });
    $('rngRelief').addEventListener('input', function () {
      state.params.relief = Number(this.value) / 100;
      $('valRelief').textContent = Math.round(state.params.relief * 100) + '%';
      saveState();
      scheduleRender();
    });
    $('rngSpec').addEventListener('input', function () {
      state.params.spec = Number(this.value) / 100;
      $('valSpec').textContent = Math.round(state.params.spec * 100) + '%';
      saveState();
      scheduleRender();
    });
    $('rngLight').addEventListener('input', function () {
      state.params.light = Number(this.value);
      $('valLight').textContent = state.params.light + '°';
      saveState();
      scheduleRender();
    });
    $('rngScale').addEventListener('input', function () {
      state.params.texScale = Number(this.value) / 100;
      $('valScale').textContent = (30 / state.params.texScale).toFixed(1) + 'mm';
      if (state.materialName) state.matScales[state.materialName] = state.params.texScale;
      saveState();
      scheduleRender();
    });
    $('btnScaleReset').addEventListener('click', function () {
      if (state.materialName) delete state.matScales[state.materialName];
      state.params.texScale = materialDefaultScale(state.materialName || '');
      syncScaleUI();
      saveState();
      scheduleRender();
      status('已重置为默认缩放：' + (30 / state.params.texScale).toFixed(1) + 'mm', 'ok');
    });
    $('rngCrease').addEventListener('input', function () {
      state.params.crease = Number(this.value) / 100;
      $('valCrease').textContent = Math.round(state.params.crease * 100) + '%';
      saveState();
      scheduleRender();
    });
    $('rngPearlAlpha').addEventListener('input', function () {
      state.params.pearlAlpha = Number(this.value) / 100;
      $('valPearlAlpha').textContent = Math.round(state.params.pearlAlpha * 100) + '%';
      updateSpecialLabels();
      saveState();
      scheduleRender();
    });
    $('btnPearlAlphaReset').addEventListener('click', function () {
      state.params.pearlAlpha = DEFAULT_PARAMS.pearlAlpha;
      $('rngPearlAlpha').value = Math.round(state.params.pearlAlpha * 100);
      $('valPearlAlpha').textContent = Math.round(state.params.pearlAlpha * 100) + '%';
      updateSpecialLabels();
      saveState();
      scheduleRender();
      status('珠光不透明度已重置为默认 ' + Math.round(DEFAULT_PARAMS.pearlAlpha * 100) + '%', 'ok');
    });
    $('rngTranAlpha').addEventListener('input', function () {
      state.params.tranAlpha = Number(this.value) / 100;
      $('valTranAlpha').textContent = Math.round(state.params.tranAlpha * 100) + '%';
      updateSpecialLabels();
      saveState();
      scheduleRender();
    });
    $('btnTranAlphaReset').addEventListener('click', function () {
      state.params.tranAlpha = DEFAULT_PARAMS.tranAlpha;
      $('rngTranAlpha').value = Math.round(state.params.tranAlpha * 100);
      $('valTranAlpha').textContent = Math.round(state.params.tranAlpha * 100) + '%';
      updateSpecialLabels();
      saveState();
      scheduleRender();
      status('透明不透明度已重置为默认 ' + Math.round(DEFAULT_PARAMS.tranAlpha * 100) + '%', 'ok');
    });
    $('btnResetFx').addEventListener('click', function () {
      state.params = JSON.parse(JSON.stringify(DEFAULT_PARAMS));
      initFxUI();
      saveState();
      renderPreview();
    });
    $('btnPearlWhite').addEventListener('click', function () {
      setWheelColor(255, 255, 255);
    });
  }

  function updateZoomButtons() {
    $('zoomFit').classList.toggle('on', state.zoom === 'fit');
    $('zoom100').classList.toggle('on', state.zoom === '100');
    $('zoom200').classList.toggle('on', state.zoom === '200');
  }

  var UI_ZOOM_BASE = 2.5;
  var UI_ZOOM_MIN = 0.5 / UI_ZOOM_BASE;
  var UI_ZOOM_MAX = 5 / UI_ZOOM_BASE;

  function applyUiZoom(mult) {
    mult = Math.max(UI_ZOOM_MIN, Math.min(UI_ZOOM_MAX, mult));
    document.documentElement.style.zoom = mult;
    try { localStorage.setItem('foilu.uiZoom', String(mult)); } catch (e) {}
    return mult;
  }

  function initUiZoom() {
    var m = 1;
    var hadZoom = false;
    try {
      var v = parseFloat(localStorage.getItem('foilu.uiZoom'));
      if (isFinite(v) && v > 0) { m = v; hadZoom = true; }
    } catch (e) {}
    applyUiZoom(m);
    if (!hadZoom && UI_ZOOM_BASE !== 1) {
      setTimeout(function () {
        status('提示：按住 Ctrl + 滚轮可调整面板缩放（当前 ' + String(Math.round(UI_ZOOM_BASE * 100) / 100) + 'x，自动记忆）');
      }, 1500);
    }
    document.addEventListener('wheel', function (e) {
      if (!e.ctrlKey) return;
      e.preventDefault();
      var cur = parseFloat(document.documentElement.style.zoom) || 1;
      var next = applyUiZoom(e.deltaY < 0 ? cur * 1.1 : cur / 1.1);
      ddClose();
      var abs = String(Math.round(next * UI_ZOOM_BASE * 100) / 100);
      status('面板缩放 ' + abs + 'x（Ctrl+滚轮，0.5x–5x）');
    }, { passive: false });
  }

  var ddPop = null;
  var ddSel = null;

  function ddClose() {
    if (ddPop) {
      if (ddPop.parentNode) ddPop.parentNode.removeChild(ddPop);
      ddPop = null;
      ddSel = null;
    }
  }

  function ddOpen(sel) {
    if (ddSel === sel && ddPop) { ddClose(); return; }
    ddClose();
    ddSel = sel;
    var z = parseFloat(document.documentElement.style.zoom) || 1;
    var pop = document.createElement('div');
    pop.className = 'ddPop';
    var lastGroup = null;
    for (var i = 0; i < sel.options.length; i++) {
      var op = sel.options[i];
      var g = op.parentNode && op.parentNode.tagName === 'OPTGROUP' ? op.parentNode.label : '';
      if (g && g !== lastGroup) {
        var h = document.createElement('div');
        h.className = 'ddHead';
        h.textContent = g;
        pop.appendChild(h);
      }
      lastGroup = g;
      var it = document.createElement('div');
      it.className = 'ddItem' + (i === sel.selectedIndex ? ' on' : '') + (op.disabled ? ' dis' : '');
      it.textContent = op.textContent;
      it.setAttribute('data-i', String(i));
      pop.appendChild(it);
    }
    pop.style.visibility = 'hidden';
    var maxHV = Math.max(140, Math.min(300, window.innerHeight * 0.55));
    pop.style.maxHeight = (maxHV / z) + 'px';
    document.body.appendChild(pop);
    var sr = sel.getBoundingClientRect();
    var pr = pop.getBoundingClientRect();
    var wV = Math.max(sr.width, Math.min(pr.width, 300));
    pop.style.width = (wV / z) + 'px';
    pr = pop.getBoundingClientRect();
    var leftV = Math.min(Math.max(4, sr.left), Math.max(4, window.innerWidth - wV - 4));
    var topV = sr.bottom + 2;
    if (topV + pr.height > window.innerHeight - 6) {
      var up = sr.top - pr.height - 2;
      topV = up >= 6 ? up : Math.max(6, window.innerHeight - pr.height - 6);
    }
    pop.style.left = (leftV / z) + 'px';
    pop.style.top = (topV / z) + 'px';
    pr = pop.getBoundingClientRect();
    var dx = pr.left - leftV;
    var dy = pr.top - topV;
    if (Math.abs(dx) > 0.5) pop.style.left = ((leftV - dx) / z) + 'px';
    if (Math.abs(dy) > 0.5) pop.style.top = ((topV - dy) / z) + 'px';
    pop.style.visibility = 'visible';
    ddPop = pop;
    var cur = pop.querySelector('.ddItem.on');
    if (cur && cur.scrollIntoView) { try { cur.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
    pop.addEventListener('mousedown', function (e) {
      var it = e.target;
      while (it && it !== pop && (!it.className || String(it.className).indexOf('ddItem') !== 0)) it = it.parentNode;
      if (!it || it === pop) return;
      e.preventDefault();
      if (String(it.className).indexOf('dis') >= 0) return;
      var idx = parseInt(it.getAttribute('data-i'), 10);
      if (!isNaN(idx)) {
        sel.selectedIndex = idx;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
      }
      ddClose();
    });
  }

  function initCustomDropdowns() {
    document.addEventListener('mousedown', function (e) {
      var t = e.target;
      if (t && t.tagName === 'SELECT' && !t.disabled) {
        e.preventDefault();
        ddOpen(t);
        return;
      }
      if (ddPop && !ddPop.contains(t)) ddClose();
    }, true);
    document.addEventListener('keydown', function (e) {
      var t = e.target;
      if (t && t.tagName === 'SELECT' && !t.disabled && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        ddOpen(t);
      } else if (e.key === 'Escape') {
        ddClose();
      }
    }, true);
    window.addEventListener('resize', ddClose);
    window.addEventListener('blur', ddClose);
    document.addEventListener('scroll', function (e) {
      if (ddPop && e.target && ddPop.contains(e.target)) return;
      ddClose();
    }, true);
    document.addEventListener('wheel', function (e) {
      if (ddPop && e.target && ddPop.contains(e.target)) return;
      ddClose();
    }, true);
  }

  var tpEl = null;
  var tpNode = null;
  var tpTimer = 0;

  function tpHide() {
    if (tpTimer) { clearTimeout(tpTimer); tpTimer = 0; }
    if (tpNode) {
      if (tpNode.parentNode) tpNode.parentNode.removeChild(tpNode);
      tpNode = null;
    }
  }

  function tpShow(el) {
    var text = el.getAttribute('data-title');
    if (!text || ddPop) { return; }
    var tp = document.createElement('div');
    tp.className = 'tpPop';
    tp.textContent = text;
    tp.style.visibility = 'hidden';
    document.body.appendChild(tp);
    var z = parseFloat(document.documentElement.style.zoom) || 1;
    var maxWV = Math.max(140, Math.min(300, window.innerWidth * 0.7));
    tp.style.maxWidth = (maxWV / z) + 'px';
    var er = el.getBoundingClientRect();
    var tr = tp.getBoundingClientRect();
    var leftV = Math.min(Math.max(4, er.left + er.width / 2 - tr.width / 2), Math.max(4, window.innerWidth - tr.width - 4));
    var topV = er.top - tr.height - 6;
    if (topV < 4) topV = er.bottom + 6;
    if (topV + tr.height > window.innerHeight - 4) topV = Math.max(4, window.innerHeight - tr.height - 4);
    tp.style.left = (leftV / z) + 'px';
    tp.style.top = (topV / z) + 'px';
    tr = tp.getBoundingClientRect();
    var dx = tr.left - leftV;
    var dy = tr.top - topV;
    if (Math.abs(dx) > 0.5) tp.style.left = ((leftV - dx) / z) + 'px';
    if (Math.abs(dy) > 0.5) tp.style.top = ((topV - dy) / z) + 'px';
    tp.style.visibility = 'visible';
    tpNode = tp;
  }

  function convTitle(el) {
    if (!el.getAttribute) return;
    var t = el.getAttribute('title');
    if (t) {
      el.setAttribute('data-title', t);
      el.removeAttribute('title');
    }
  }

  function initCustomTooltips() {
    var mo = new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var r = recs[i];
        if (r.type === 'attributes') {
          convTitle(r.target);
        } else if (r.type === 'childList') {
          var nodes = r.addedNodes;
          for (var j = 0; j < nodes.length; j++) {
            var n = nodes[j];
            if (n.nodeType !== 1) continue;
            convTitle(n);
            var subs = n.querySelectorAll ? n.querySelectorAll('[title]') : [];
            for (var k = 0; k < subs.length; k++) convTitle(subs[k]);
          }
        }
      }
    });
    mo.observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ['title'], childList: true });
    var all = document.querySelectorAll('[title]');
    for (var i = 0; i < all.length; i++) convTitle(all[i]);
    document.addEventListener('mouseover', function (e) {
      var el = e.target && e.target.closest ? e.target.closest('[data-title]') : null;
      if (!el || el === tpEl) return;
      tpHide();
      tpEl = el;
      tpTimer = setTimeout(function () { tpShow(el); }, 350);
    }, true);
    document.addEventListener('mouseout', function (e) {
      var el = e.target && e.target.closest ? e.target.closest('[data-title]') : null;
      if (!el || el !== tpEl) return;
      if (e.relatedTarget && el.contains(e.relatedTarget)) return;
      tpEl = null;
      tpHide();
    }, true);
    document.addEventListener('mousedown', tpHide, true);
    document.addEventListener('scroll', tpHide, true);
    document.addEventListener('wheel', tpHide, true);
    window.addEventListener('blur', tpHide);
  }

  function init() {
    loadState();
    if (!cep.available) {
      status('CEP Node 未启用：请先运行 install/install.ps1 并重启 Photoshop', 'err');
    }
    try {
      renderer = new window.FoilRenderer();
    } catch (e) {
      renderer = null;
      status('WebGL 初始化失败：' + e.message, 'err');
    }
    scanLibrary();
    rebuildMaterialUI();
    bindUI();
    initUiZoom();
    initCustomDropdowns();
    initCustomTooltips();
    initFxUI();
    initWheel();
    updatePearlSwatches();
    updateZoomButtons();
    $('cutPattern').value = state.cutPattern;
    updateCutUI();
    updatePoolUI();
    renderLayerList();
    syncSeamUI();
    $('customDirText').textContent = '自定义材质目录：' + cep.customDir;
    var start = findMaterial(state.materialPath) ? state.materialPath : (state.builtin.length ? state.builtin[0].path : (state.custom.length ? state.custom[0].path : ''));
    if (start) selectMaterial(start, true);
    else status('未找到烫材贴图：请确认 materials 目录存在贴图', 'err');
    if (cep.available && cep.nativePath) {
      ps.loadHost(cep.nativePath + '/jsx/host.jsx', function () {
        poll();
        setInterval(poll, 3000);
      });
    } else {
      poll();
      setInterval(poll, 3000);
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
