(function () {
  'use strict';

  var cep = window.FoilUCep;
  var ps = {};
  window.FoilUPs = ps;

  function ulit(s) {
    s = String(s);
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      var code = s.charCodeAt(i);
      if (c === '\\' || c === '"') out += '\\' + c;
      else if (code >= 32 && code < 127) out += c;
      else out += '\\u' + ('0000' + code.toString(16)).slice(-4);
    }
    return '"' + out + '"';
  }

  function pathLit(p) {
    return ulit(String(p).replace(/\\/g, '/'));
  }

  function call(expr, cb) {
    cep.evalScript(expr, function (res) {
      if (!res || res === 'EvalScript error.') {
        cb({ ok: false, error: '无法与 Photoshop 通信（请确认已打开文档）' });
        return;
      }
      var obj = null;
      try {
        obj = JSON.parse(res);
      } catch (e) {
        var s = String(res);
        obj = {
          ok: false,
          error: '返回值异常(长度' + s.length + ')：' + s.slice(0, 80) + ' … ' + s.slice(-48)
        };
      }
      cb(obj);
    });
  }

  ps.loadHost = function (jsxPath, cb) {
    cep.evalScript('$.evalFile(' + pathLit(jsxPath) + '); "FOILU_JSX_OK"', function (res) {
      cb(res === 'FOILU_JSX_OK' || res === '"FOILU_JSX_OK"');
    });
  };

  ps.getDocInfo = function (cb) {
    call('FoilU.getDocInfo()', cb);
  };

  ps.exportAssets = function (workDir, previewMax, maskMax, cb) {
    call('FoilU.exportAssets(' + pathLit(workDir) + ', ' + Number(previewMax || 0) + ', ' + Number(maskMax || 0) + ')', cb);
  };

  ps.exportCutLayer = function (workDir, pattern, cb) {
    call('FoilU.exportCutLayer(' + pathLit(workDir) + ', ' + ulit(pattern) + ')', cb);
  };

  ps.exportPrintLayer = function (workDir, cb) {
    call('FoilU.exportPrintLayer(' + pathLit(workDir) + ')', cb);
  };

  ps.placeResult = function (pngPath, layerName, scale, layerId, expLeft, expTop, replaceSuffix, pngW, pngH, cb) {
    call('FoilU.placeResult(' + pathLit(pngPath) + ', ' + ulit(layerName) + ', ' + Number(scale) + ', ' + Number(layerId) +
      ', ' + Number(expLeft || 0) + ', ' + Number(expTop || 0) + ', ' + ulit(replaceSuffix || '') +
      ', ' + Number(pngW || 0) + ', ' + Number(pngH || 0) + ')', cb);
  };

  ps.getViewRotation = function (cb) {
    call('FoilU.getViewRotation()', cb);
  };

  ps.listLayers = function (workDir, thumbMax, cb) {
    call('FoilU.listLayers(' + pathLit(workDir) + ', ' + Number(thumbMax || 0) + ')', cb);
  };

  ps.exportByIds = function (workDir, fileName, idsCsv, cb) {
    call('FoilU.exportByIds(' + pathLit(workDir) + ', ' + ulit(fileName) + ', ' + ulit(idsCsv) + ')', cb);
  };

  ps.setLayersVisible = function (idsCsv, vis, cb) {
    call('FoilU.setLayersVisible(' + ulit(idsCsv) + ', ' + (vis ? 'true' : 'false') + ')', cb);
  };

  ps.groupGenerated = function (groupName, idsCsv, cb) {
    call('FoilU.groupGenerated(' + ulit(groupName) + ', ' + ulit(idsCsv) + ')', cb);
  };
})();
