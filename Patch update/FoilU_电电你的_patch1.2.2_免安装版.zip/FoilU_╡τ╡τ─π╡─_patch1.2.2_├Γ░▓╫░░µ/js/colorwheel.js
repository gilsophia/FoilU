(function () {
  'use strict';

  function clamp(v, a, b) {
    return v < a ? a : (v > b ? b : v);
  }

  function hsvToRgb(h, s, v) {
    h = ((h % 360) + 360) % 360;
    var c = v * s;
    var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    var m = v - c;
    var r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; }
    else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; }
    else { r = c; b = x; }
    return {
      r: Math.round((r + m) * 255),
      g: Math.round((g + m) * 255),
      b: Math.round((b + m) * 255)
    };
  }

  function rgbToHsv(r, g, b) {
    r = r / 255;
    g = g / 255;
    b = b / 255;
    var max = Math.max(r, g, b);
    var min = Math.min(r, g, b);
    var d = max - min;
    var h = 0;
    if (d > 0) {
      if (max === r) h = 60 * (((g - b) / d) % 6);
      else if (max === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
    }
    if (h < 0) h += 360;
    var s = max === 0 ? 0 : d / max;
    return { h: h, s: s, v: max };
  }

  function FoilWheel(canvas, onChange) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.onChange = onChange || function () {};
    this.size = canvas.width;
    this.cx = this.size / 2;
    this.cy = this.size / 2;
    this.ringOuter = this.size * 0.475;
    this.ringInner = this.size * 0.368;
    this.sq = this.size * 0.50;
    this.sqX = (this.size - this.sq) / 2;
    this.sqY = (this.size - this.sq) / 2;
    this.h = 0;
    this.s = 0;
    this.v = 1;
    this._ring = null;
    this._drag = '';
    this._buildRing();
    this._bind();
    this.redraw();
  }

  FoilWheel.prototype._buildRing = function () {
    var s = this.size;
    var c = document.createElement('canvas');
    c.width = s;
    c.height = s;
    var ctx = c.getContext('2d');
    var img = ctx.createImageData(s, s);
    var d = img.data;
    for (var y = 0; y < s; y++) {
      for (var x = 0; x < s; x++) {
        var dx = x - this.cx;
        var dy = y - this.cy;
        var r = Math.sqrt(dx * dx + dy * dy);
        var i = (y * s + x) * 4;
        if (r >= this.ringInner && r <= this.ringOuter) {
          var ang = Math.atan2(dy, dx) * 180 / Math.PI;
          var rgb = hsvToRgb(ang, 1, 1);
          d[i] = rgb.r;
          d[i + 1] = rgb.g;
          d[i + 2] = rgb.b;
          d[i + 3] = 255;
        } else {
          d[i + 3] = 0;
        }
      }
    }
    ctx.putImageData(img, 0, 0);
    this._ring = c;
  };

  FoilWheel.prototype._bind = function () {
    var self = this;
    function pos(e) {
      var r = self.canvas.getBoundingClientRect();
      return {
        x: (e.clientX - r.left) * self.size / r.width,
        y: (e.clientY - r.top) * self.size / r.height
      };
    }
    function hit(p) {
      var dx = p.x - self.cx;
      var dy = p.y - self.cy;
      var dist = Math.sqrt(dx * dx + dy * dy);
      if (dist >= self.ringInner * 0.92 && dist <= self.ringOuter * 1.08) return 'ring';
      if (p.x >= self.sqX && p.x <= self.sqX + self.sq && p.y >= self.sqY && p.y <= self.sqY + self.sq) return 'square';
      return '';
    }
    function apply(p, mode) {
      if (mode === 'ring') {
        var ang = Math.atan2(p.y - self.cy, p.x - self.cx) * 180 / Math.PI;
        self.h = ((ang % 360) + 360) % 360;
      } else if (mode === 'square') {
        self.s = clamp((p.x - self.sqX) / self.sq, 0, 1);
        self.v = clamp(1 - (p.y - self.sqY) / self.sq, 0, 1);
      }
      self.redraw();
      self.onChange(hsvToRgb(self.h, self.s, self.v));
    }
    this.canvas.addEventListener('mousedown', function (e) {
      var p = pos(e);
      var mode = hit(p);
      if (!mode) return;
      self._drag = mode;
      apply(p, mode);
      e.preventDefault();
    });
    window.addEventListener('mousemove', function (e) {
      if (!self._drag) return;
      apply(pos(e), self._drag);
    });
    window.addEventListener('mouseup', function () {
      self._drag = '';
    });
  };

  FoilWheel.prototype.redraw = function () {
    var ctx = this.ctx;
    var s = this.size;
    ctx.clearRect(0, 0, s, s);
    ctx.drawImage(this._ring, 0, 0);
    var hue = hsvToRgb(this.h, 1, 1);
    var g1 = ctx.createLinearGradient(this.sqX, 0, this.sqX + this.sq, 0);
    g1.addColorStop(0, 'rgb(255,255,255)');
    g1.addColorStop(1, 'rgb(' + hue.r + ',' + hue.g + ',' + hue.b + ')');
    ctx.fillStyle = g1;
    ctx.fillRect(this.sqX, this.sqY, this.sq, this.sq);
    var g2 = ctx.createLinearGradient(0, this.sqY, 0, this.sqY + this.sq);
    g2.addColorStop(0, 'rgba(0,0,0,0)');
    g2.addColorStop(1, 'rgb(0,0,0)');
    ctx.fillStyle = g2;
    ctx.fillRect(this.sqX, this.sqY, this.sq, this.sq);
    var ringAng = this.h * Math.PI / 180;
    var rr = (this.ringInner + this.ringOuter) / 2;
    var hx = this.cx + Math.cos(ringAng) * rr;
    var hy = this.cy + Math.sin(ringAng) * rr;
    ctx.beginPath();
    ctx.arc(hx, hy, Math.max(5, this.size * 0.026), 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(0,0,0,0.85)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(hx, hy, Math.max(4, this.size * 0.024), 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    var px = this.sqX + this.s * this.sq;
    var py = this.sqY + (1 - this.v) * this.sq;
    ctx.beginPath();
    ctx.arc(px, py, Math.max(5, this.size * 0.026), 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(0,0,0,0.85)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(px, py, Math.max(4, this.size * 0.024), 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  };

  FoilWheel.prototype.set = function (r, g, b) {
    var hsv = rgbToHsv(clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255));
    this.h = hsv.h;
    this.s = hsv.s;
    this.v = hsv.v;
    if (this.v === 0) this.v = 0.0001;
    this.redraw();
  };

  window.FoilWheel = FoilWheel;
  window.FoilWheelUtil = { hsvToRgb: hsvToRgb, rgbToHsv: rgbToHsv };
})();
