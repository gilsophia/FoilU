(function () {
  'use strict';

  var ns = {};
  window.FoilUCep = ns;
  ns.available = false;
  ns.fs = null;
  ns.path = null;
  ns.os = null;

  function tryRequire(name) {
    try {
      if (window.cep_node && window.cep_node.require) return window.cep_node.require(name);
    } catch (e) {}
    try {
      if (typeof require === 'function') return require(name);
    } catch (e2) {}
    try {
      if (window.require) return window.require(name);
    } catch (e3) {}
    return null;
  }

  ns.require = tryRequire;
  ns.fs = tryRequire('fs');
  ns.path = tryRequire('path');
  ns.os = tryRequire('os');

  ns.evalScript = function (script, cb) {
    if (typeof cb !== 'function') cb = function () {};
    try {
      window.__adobe_cep__.evalScript(script, cb);
    } catch (e) {
      cb('EvalScript error: ' + e.message);
    }
  };

  ns.nativePath = '';
  try {
    var p = window.__adobe_cep__.getSystemPath('extension');
    if (p) {
      if (/^file:/i.test(p)) p = decodeURI(p.replace(/^file:\/{2,3}/i, ''));
      else p = decodeURI(p);
      ns.nativePath = p.replace(/\\/g, '/');
    }
  } catch (e) {}

  ns.ensureDir = function (dir) {
    if (!ns.fs || !dir) return;
    var d = dir.replace(/\\/g, '/');
    var parts = d.split('/');
    var cur = '';
    for (var i = 0; i < parts.length; i++) {
      if (i === 0) {
        cur = parts[0];
        if (cur === '') cur = '/';
        continue;
      }
      cur = cur === '/' ? '/' + parts[i] : cur + '/' + parts[i];
      try {
        if (!ns.fs.existsSync(cur)) ns.fs.mkdirSync(cur);
      } catch (e) {}
    }
  };

  ns.workDir = '';
  ns.resultPath = '';
  ns.customDir = '';
  if (ns.fs && ns.os && ns.path) {
    try {
      ns.workDir = ns.path.join(ns.os.tmpdir(), 'FoilU').replace(/\\/g, '/');
      ns.ensureDir(ns.workDir);
      ns.resultPath = ns.workDir + '/result.png';
      var appdata = window.process && window.process.env ? window.process.env.APPDATA : null;
      var customBase = appdata ? ns.path.join(appdata, 'FoilU') : (ns.nativePath ? ns.path.join(ns.nativePath, 'userdata') : ns.workDir + '/custom');
      ns.customDir = ns.path.join(customBase, 'custom').replace(/\\/g, '/');
      ns.ensureDir(ns.customDir);
      ns.available = true;
    } catch (e) {}
  }

  ns.metaFile = function () {
    return ns.customDir + '/_foilu_meta.json';
  };

  ns.starsPath = ns.customDir ? ns.customDir.replace(/\/custom$/, '') + '/stars.json' : '';

  ns.readStars = function () {
    try {
      var txt = ns.fs.readFileSync(ns.starsPath, 'utf8');
      var arr = JSON.parse(txt);
      return Object.prototype.toString.call(arr) === '[object Array]' ? arr : [];
    } catch (e) {
      return [];
    }
  };

  ns.writeStars = function (list) {
    try {
      ns.fs.writeFileSync(ns.starsPath, JSON.stringify(list));
      return true;
    } catch (e) {
      return false;
    }
  };

  ns.readMeta = function () {
    try {
      var txt = ns.fs.readFileSync(ns.metaFile(), 'utf8');
      var obj = JSON.parse(txt);
      return obj && typeof obj === 'object' ? obj : {};
    } catch (e) {
      return {};
    }
  };

  ns.writeMeta = function (meta) {
    try {
      ns.fs.writeFileSync(ns.metaFile(), JSON.stringify(meta));
      return true;
    } catch (e) {
      return false;
    }
  };

  ns.imageDataUrl = function (filePath, cb) {
    try {
      ns.fs.readFile(filePath, function (err, buf) {
        if (err || !buf) {
          cb(null);
          return;
        }
        var ext = String(filePath).toLowerCase();
        var mime = (ext.indexOf('.jpg') >= 0 || ext.indexOf('.jpeg') >= 0 || ext.indexOf('.jfif') >= 0) ? 'image/jpeg' :
          (ext.indexOf('.webp') >= 0 ? 'image/webp' : 'image/png');
        cb('data:' + mime + ';base64,' + buf.toString('base64'));
      });
    } catch (e) {
      cb(null);
    }
  };

  ns.thumbsDir = ns.customDir ? ns.customDir.replace(/\/custom$/, '') + '/thumbs' : '';
  ns.ensureDir(ns.thumbsDir);
  ns.packThumbsDir = ns.nativePath ? ns.nativePath + '/thumbs' : '';

  ns.readThumb = function (key, cb) {
    try {
      if (!key) { cb(null); return; }
      var dirs = [ns.packThumbsDir, ns.thumbsDir];
      for (var di = 0; di < dirs.length; di++) {
        if (!dirs[di]) continue;
        var p = dirs[di] + '/' + key + '.webp';
        if (ns.fs.existsSync(p)) {
          var buf = ns.fs.readFileSync(p);
          cb('data:image/webp;base64,' + buf.toString('base64'));
          return;
        }
      }
      cb(null);
    } catch (e) {
      cb(null);
    }
  };

  ns.writeThumb = function (key, bytes) {
    try {
      if (!key || !ns.thumbsDir) return false;
      var B = null;
      try { B = ns.require('buffer').Buffer; } catch (e1) {}
      if (!B && typeof Buffer !== 'undefined') B = Buffer;
      if (!B) return false;
      ns.ensureDir(ns.thumbsDir);
      ns.fs.writeFileSync(ns.thumbsDir + '/' + key + '.webp', B.from(bytes));
      return true;
    } catch (e) {
      return false;
    }
  };

  ns.listImages = function (dir) {
    try {
      if (!ns.fs.existsSync(dir)) return [];
      var names = ns.fs.readdirSync(dir);
      var out = [];
      for (var i = 0; i < names.length; i++) {
        var n = names[i];
        if (/\.(png|jpe?g|webp)$/i.test(n)) out.push(n);
      }
      out.sort(function (a, b) {
        return a.localeCompare(b, 'zh-Hans-CN');
      });
      return out;
    } catch (e) {
      return [];
    }
  };

  ns.readImageBase64 = function (filePath, cb) {
    try {
      cb(ns.fs.readFileSync(filePath).toString('base64'));
    } catch (e) {
      cb(null);
    }
  };

  ns.writeBuffer = function (filePath, bytes) {
    try {
      var B = null;
      try { B = ns.require('buffer').Buffer; } catch (e1) {}
      if (!B && typeof Buffer !== 'undefined') B = Buffer;
      if (!B || !ns.fs) return false;
      ns.fs.writeFileSync(filePath, B.from(bytes));
      return true;
    } catch (e) {
      return false;
    }
  };
})();
