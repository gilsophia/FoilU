(function () {
  'use strict';

  function rotateCanvas(src, deg) {
    deg = ((deg % 360) + 360) % 360;
    if (deg === 0) return src;
    var w = src.width || src.naturalWidth;
    var h = src.height || src.naturalHeight;
    var c = document.createElement('canvas');
    var ctx;
    if (deg === 180) {
      c.width = w;
      c.height = h;
      ctx = c.getContext('2d');
      ctx.translate(w, h);
      ctx.rotate(Math.PI);
      ctx.drawImage(src, 0, 0);
      return c;
    }
    c.width = h;
    c.height = w;
    ctx = c.getContext('2d');
    ctx.translate(h / 2, w / 2);
    ctx.rotate(deg * Math.PI / 180);
    ctx.drawImage(src, -w / 2, -h / 2);
    return c;
  }

  function morph(B, w, h, r, dilate) {
    var cur = B;
    for (var k = 0; k < r; k++) {
      var out = new Uint8Array(w * h);
      for (var y = 0; y < h; y++) {
        var row = y * w;
        for (var x = 0; x < w; x++) {
          var i = row + x;
          var v = cur[i];
          if (dilate) {
            if (v) { out[i] = 1; continue; }
            if ((x > 0 && cur[i - 1]) || (x < w - 1 && cur[i + 1]) ||
                (y > 0 && cur[i - w]) || (y < h - 1 && cur[i + w])) out[i] = 1;
          } else {
            if (!v) continue;
            if (x > 0 && x < w - 1 && y > 0 && y < h - 1 &&
                cur[i - 1] && cur[i + 1] && cur[i - w] && cur[i + w]) out[i] = 1;
          }
        }
      }
      cur = out;
    }
    return cur;
  }

  function fillHoles(B, w, h) {
    var n = w * h;
    var outside = new Uint8Array(n);
    var stack = new Int32Array(n);
    var top = 0;
    function push(i) {
      if (!B[i] && !outside[i]) {
        outside[i] = 1;
        stack[top++] = i;
      }
    }
    var x, y;
    for (x = 0; x < w; x++) {
      push(x);
      push((h - 1) * w + x);
    }
    for (y = 0; y < h; y++) {
      push(y * w);
      push(y * w + w - 1);
    }
    while (top > 0) {
      var i = stack[--top];
      x = i % w;
      y = (i - x) / w;
      if (x > 0) push(i - 1);
      if (x < w - 1) push(i + 1);
      if (y > 0) push(i - w);
      if (y < h - 1) push(i + w);
    }
    var R = new Uint8Array(n);
    for (var j = 0; j < n; j++) {
      R[j] = (B[j] || !outside[j]) ? 1 : 0;
    }
    return R;
  }

  function detectSwatch(src) {
    var sw = src.width || src.naturalWidth;
    var sh = src.height || src.naturalHeight;
    var s = Math.min(1, 256 / Math.max(sw, sh));
    var aw = Math.max(16, Math.round(sw * s));
    var ah = Math.max(16, Math.round(sh * s));
    var c = document.createElement('canvas');
    c.width = aw;
    c.height = ah;
    var ctx = c.getContext('2d');
    ctx.drawImage(src, 0, 0, aw, ah);
    var data = ctx.getImageData(0, 0, aw, ah).data;
    var n = aw * ah;
    var x, y, i;
    var sr = 0, sg = 0, sb = 0, bn = 0;
    for (x = 0; x < aw; x += 2) {
      i = (2 * aw + x) * 4;
      sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; bn++;
      i = ((ah - 3) * aw + x) * 4;
      sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; bn++;
    }
    for (y = 0; y < ah; y += 2) {
      i = (y * aw + 2) * 4;
      sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; bn++;
      i = (y * aw + aw - 3) * 4;
      sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; bn++;
    }
    var br = sr / bn, bg = sg / bn, bb = sb / bn;
    var bgLum = (br + bg + bb) / 3;
    var mask = new Uint8Array(n);
    for (i = 0; i < n; i++) {
      var r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2];
      var dr = r - br, dg = g - bg, db = b - bb;
      var dist = Math.sqrt(dr * dr + dg * dg + db * db);
      var lum = (r + g + b) / 3;
      if (dist > 75 && lum < bgLum * 0.9 + 24) mask[i] = 1;
    }
    mask = morph(mask, aw, ah, 1, false);
    mask = morph(mask, aw, ah, 2, true);
    var label = new Int32Array(n);
    var queue = new Int32Array(n);
    var bestArea = 0;
    var bestId = 0;
    var room = 0;
    for (i = 0; i < n; i++) {
      if (!mask[i] || label[i]) continue;
      room++;
      var head = 0, tail = 0;
      queue[tail++] = i;
      label[i] = room;
      var area = 0;
      while (head < tail) {
        var cur = queue[head++];
        area++;
        var cx = cur % aw;
        var cy = (cur - cx) / aw;
        if (cx > 0) {
          var nb = cur - 1;
          if (mask[nb] && !label[nb]) { label[nb] = room; queue[tail++] = nb; }
        }
        if (cx < aw - 1) {
          nb = cur + 1;
          if (mask[nb] && !label[nb]) { label[nb] = room; queue[tail++] = nb; }
        }
        if (cy > 0) {
          nb = cur - aw;
          if (mask[nb] && !label[nb]) { label[nb] = room; queue[tail++] = nb; }
        }
        if (cy < ah - 1) {
          nb = cur + aw;
          if (mask[nb] && !label[nb]) { label[nb] = room; queue[tail++] = nb; }
        }
      }
      if (area > bestArea) {
        bestArea = area;
        bestId = room;
      }
    }
    if (!bestId || bestArea < n * 0.015) return null;
    var minX = aw, minY = ah, maxX = -1, maxY = -1;
    for (i = 0; i < n; i++) {
      if (label[i] !== bestId) continue;
      x = i % aw;
      y = (i - x) / aw;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    var bw = maxX - minX + 1;
    var bh = maxY - minY + 1;
    var sub = new Uint8Array(bw * bh);
    for (y = minY; y <= maxY; y++) {
      for (x = minX; x <= maxX; x++) {
        if (label[y * aw + x] === bestId) sub[(y - minY) * bw + (x - minX)] = 1;
      }
    }
    sub = fillHoles(sub, bw, bh);
    sub = morph(sub, bw, bh, 2, false);
    var dp = new Int32Array(bw * bh);
    var bestSize = 0, bestX = 0, bestY = 0;
    for (y = 0; y < bh; y++) {
      for (x = 0; x < bw; x++) {
        var idx = y * bw + x;
        if (!sub[idx]) continue;
        var a = x > 0 ? dp[idx - 1] : 0;
        var b2 = y > 0 ? dp[idx - bw] : 0;
        var c2 = (x > 0 && y > 0) ? dp[idx - bw - 1] : 0;
        var v = 1 + Math.min(a, Math.min(b2, c2));
        dp[idx] = v;
        if (v > bestSize) {
          bestSize = v;
          bestX = x - v + 1;
          bestY = y - v + 1;
        }
      }
    }
    if (bestSize < Math.max(16, Math.min(bw, bh) * 0.35)) return null;
    var fx = sw / aw;
    var fy = sh / ah;
    var rect = {
      x: Math.max(0, Math.round((minX + bestX) * fx)),
      y: Math.max(0, Math.round((minY + bestY) * fy)),
      w: Math.max(8, Math.round(bestSize * fx)),
      h: Math.max(8, Math.round(bestSize * fy))
    };
    if (rect.x + rect.w > sw) rect.w = sw - rect.x;
    if (rect.y + rect.h > sh) rect.h = sh - rect.y;
    if (rect.w < 24 || rect.h < 24) return null;
    return { srcRect: rect, bg: { r: br, g: bg, b: bb } };
  }

  function boxBlur(src, w, h, r) {
    var ii = new Float64Array((w + 1) * (h + 1));
    var x, y;
    for (y = 0; y < h; y++) {
      var rowSum = 0;
      for (x = 0; x < w; x++) {
        rowSum += src[y * w + x];
        ii[(y + 1) * (w + 1) + x + 1] = ii[y * (w + 1) + x + 1] + rowSum;
      }
    }
    var out = new Float32Array(w * h);
    for (y = 0; y < h; y++) {
      var y0 = y > r ? y - r : 0;
      var y1 = y < h - 1 - r ? y + r : h - 1;
      for (x = 0; x < w; x++) {
        var x0 = x > r ? x - r : 0;
        var x1 = x < w - 1 - r ? x + r : w - 1;
        var s = ii[(y1 + 1) * (w + 1) + x1 + 1] - ii[y0 * (w + 1) + x1 + 1] -
                ii[(y1 + 1) * (w + 1) + x0] + ii[y0 * (w + 1) + x0];
        out[y * w + x] = s / ((y1 - y0 + 1) * (x1 - x0 + 1));
      }
    }
    return out;
  }

  function detectRing(src, rect) {
    var WORK = 400;
    var sk = Math.min(1, WORK / Math.max(rect.w, rect.h));
    var aw = Math.max(16, Math.round(rect.w * sk));
    var ah = Math.max(16, Math.round(rect.h * sk));
    var c = document.createElement('canvas');
    c.width = aw;
    c.height = ah;
    var ctx = c.getContext('2d');
    ctx.drawImage(src, rect.x, rect.y, rect.w, rect.h, 0, 0, aw, ah);
    var data = ctx.getImageData(0, 0, aw, ah).data;
    var n = aw * ah;
    var i, x, y;
    var L = new Float32Array(n);
    var sat = new Uint8Array(n);
    for (i = 0; i < n; i++) {
      var r = data[i * 4];
      var g = data[i * 4 + 1];
      var b = data[i * 4 + 2];
      L[i] = r * 0.299 + g * 0.587 + b * 0.114;
      var mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
      var mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
      sat[i] = mx - mn;
    }
    var blur = boxBlur(L, aw, ah, 10);
    var px = [];
    var py = [];
    for (y = 0; y < ah; y++) {
      var row = y * aw;
      for (x = 0; x < aw; x++) {
        i = row + x;
        if (L[i] - blur[i] > 20 && sat[i] < 160 && L[i] > 60) {
          px.push(x);
          py.push(y);
        }
      }
    }
    var m = px.length;
    if (m < 120) return null;
    var dmin = Math.min(aw, ah);
    var rMin = dmin * 0.08;
    var rMax = dmin * 0.62;
    var bins = new Uint8Array(72);
    function evalCircle(cx, cy, rr) {
      var inl = 0;
      var cov = 0;
      bins.fill(0);
      for (var k = 0; k < m; k++) {
        var dx = px[k] - cx;
        var dy = py[k] - cy;
        var dist = Math.sqrt(dx * dx + dy * dy);
        if (dist - rr > 2 || rr - dist > 2) continue;
        inl++;
        var a = Math.atan2(dy, dx);
        var bi = Math.floor((a + 3.14159265) / 6.2831853 * 72);
        if (bi < 0) bi = 0;
        if (bi > 71) bi = 71;
        bins[bi] = 1;
      }
      for (var q = 0; q < 72; q++) if (bins[q]) cov++;
      cov = cov / 72;
      return { inl: inl, cov: cov, score: inl * Math.min(1, cov / 0.45) };
    }
    var bcx = -1;
    var bcy = -1;
    var br = -1;
    var bscore = -1;
    for (var it = 0; it < 1500; it++) {
      var i1 = (Math.random() * m) | 0;
      var i2 = (Math.random() * m) | 0;
      var i3 = (Math.random() * m) | 0;
      if (i1 === i2 || i1 === i3 || i2 === i3) continue;
      var x1 = px[i1], y1 = py[i1], x2 = px[i2], y2 = py[i2], x3 = px[i3], y3 = py[i3];
      var d = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));
      if (d > -1e-9 && d < 1e-9) continue;
      var ux = ((x1 * x1 + y1 * y1) * (y2 - y3) + (x2 * x2 + y2 * y2) * (y3 - y1) + (x3 * x3 + y3 * y3) * (y1 - y2)) / d;
      var uy = ((x1 * x1 + y1 * y1) * (x3 - x2) + (x2 * x2 + y2 * y2) * (x1 - x3) + (x3 * x3 + y3 * y3) * (x2 - x1)) / d;
      var rr2 = Math.sqrt((x1 - ux) * (x1 - ux) + (y1 - uy) * (y1 - uy));
      if (rr2 < rMin || rr2 > rMax) continue;
      if (ux < 0 || ux >= aw || uy < 0 || uy >= ah) continue;
      var ev = evalCircle(ux, uy, rr2);
      if (ev.score > bscore) {
        bscore = ev.score;
        bcx = ux;
        bcy = uy;
        br = rr2;
      }
    }
    if (bscore < 0) return null;
    for (var round = 0; round < 8; round++) {
      var step = round < 4 ? 4 : 1.5;
      var bst = evalCircle(bcx, bcy, br).score;
      for (var dcx = -1; dcx <= 1; dcx++) {
        for (var dcy = -1; dcy <= 1; dcy++) {
          for (var dr = -1; dr <= 1; dr++) {
            if (!dcx && !dcy && !dr) continue;
            var nx = bcx + dcx * step;
            var ny = bcy + dcy * step;
            var nr = br + dr * step;
            if (nr < rMin || nr > rMax) continue;
            var ev2 = evalCircle(nx, ny, nr);
            if (ev2.score > bst) {
              bst = ev2.score;
              bcx = nx;
              bcy = ny;
              br = nr;
            }
          }
        }
      }
    }
    var fin = evalCircle(bcx, bcy, br);
    if (fin.inl < 420 * dmin / 400 || fin.cov < 0.45) return null;
    var gsum = 0;
    var gcnt = 0;
    for (y = 1; y < ah - 1; y++) {
      for (x = 1; x < aw - 1; x++) {
        i = y * aw + x;
        var gx = L[i + 1] - L[i - 1];
        var gy = L[i + aw] - L[i - aw];
        gsum += Math.sqrt(gx * gx + gy * gy);
        gcnt++;
      }
    }
    var gmean = gsum / gcnt;
    var gvs = 0;
    for (y = 1; y < ah - 1; y++) {
      for (x = 1; x < aw - 1; x++) {
        i = y * aw + x;
        var gx2 = L[i + 1] - L[i - 1];
        var gy2 = L[i + aw] - L[i - aw];
        var gd = Math.sqrt(gx2 * gx2 + gy2 * gy2) - gmean;
        gvs += gd * gd;
      }
    }
    var gthr = gmean + Math.sqrt(gvs / gcnt) * 0.9;
    var total = 0;
    var non = 0;
    for (y = 1; y < ah - 1; y++) {
      for (x = 1; x < aw - 1; x++) {
        i = y * aw + x;
        var gx3 = L[i + 1] - L[i - 1];
        var gy3 = L[i + aw] - L[i - aw];
        var gm = Math.sqrt(gx3 * gx3 + gy3 * gy3);
        if (gm < gthr || gm < 12) continue;
        var dx2 = x - bcx;
        var dy2 = y - bcy;
        var dist2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
        if (dist2 - br > 2 || br - dist2 > 2) continue;
        total++;
        var dot = Math.abs(gx3 * (dx2 / dist2) + gy3 * (dy2 / dist2)) / gm;
        if (dot < 0.70) non++;
      }
    }
    var nrf = total > 0 ? non / total : 1;
    if (nrf > 0.35) return null;
    var relCx = bcx / aw;
    var relCy = bcy / ah;
    if (relCx < 0.05 || relCx > 0.95 || relCy < 0.05 || relCy > 0.95) return null;
    var kx = rect.w / aw;
    var ky = rect.h / ah;
    return {
      cx: rect.x + bcx * kx,
      cy: rect.y + bcy * ky,
      r: br * (kx + ky) / 2,
      conf: fin.cov * (1 - nrf),
      coverage: fin.cov,
      relCx: relCx,
      relCy: relCy
    };
  }

  function inpaintRing(canvas, ring) {
    var w = canvas.width;
    var h = canvas.height;
    if (ring.r < Math.min(w, h) * 0.06) return false;
    if (ring.relCx > 0.85 || ring.relCx < 0.15 || ring.relCy > 0.85 || ring.relCy < 0.15) return false;
    var ctx = canvas.getContext('2d');
    var imgData = ctx.getImageData(0, 0, w, h);
    var d = imgData.data;
    var cx = ring.cx;
    var cy = ring.cy;
    var r = ring.r;
    var band = Math.max(2, r * 0.20);
    var m = new Float32Array(w * h);
    var minX = w, maxX = 0, minY = h, maxY = 0;
    var x, y;
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var dx = x - cx;
        var dy = y - cy;
        var dist = Math.sqrt(dx * dx + dy * dy);
        var diff = Math.abs(dist - r);
        if (diff < band) {
          m[y * w + x] = 1 - diff / band;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX < minX) return false;
    var shifts = [
      [1.8 * r, 1.8 * r], [-1.8 * r, 1.8 * r], [1.8 * r, -1.8 * r], [-1.8 * r, -1.8 * r],
      [2.6 * r, 0], [-2.6 * r, 0], [0, 2.6 * r], [0, -2.6 * r],
      [1.2 * r, 1.2 * r], [-1.2 * r, 1.2 * r], [1.2 * r, -1.2 * r], [-1.2 * r, -1.2 * r],
      [1.4 * r, 0], [-1.4 * r, 0], [0, 1.4 * r], [0, -1.4 * r]
    ];
    var scores = [];
    var order = [];
    var si;
    var bestScore = -1;
    for (si = 0; si < shifts.length; si++) {
      var dxs = Math.round(shifts[si][0]);
      var dys = Math.round(shifts[si][1]);
      var good = 0;
      var total = 0;
      for (y = minY; y <= maxY; y += 2) {
        for (x = minX; x <= maxX; x += 2) {
          if (m[y * w + x] <= 0) continue;
          total++;
          var sx = x + dxs;
          var sy = y + dys;
          if (sx >= 0 && sx < w && sy >= 0 && sy < h && m[sy * w + sx] === 0) good++;
        }
      }
      var sc = total ? good / total : 0;
      scores.push(sc);
      order.push(si);
      if (sc > bestScore) bestScore = sc;
    }
    if (bestScore < 0.30) return false;
    order.sort(function (a, b) { return scores[b] - scores[a]; });
    for (y = minY; y <= maxY; y++) {
      for (x = minX; x <= maxX; x++) {
        var i2 = y * w + x;
        var mv = m[i2];
        if (mv <= 0) continue;
        for (var oi = 0; oi < order.length; oi++) {
          var sdx = Math.round(shifts[order[oi]][0]);
          var sdy = Math.round(shifts[order[oi]][1]);
          var sxp = x + sdx;
          var syp = y + sdy;
          if (sxp < 0 || sxp >= w || syp < 0 || syp >= h) continue;
          if (m[syp * w + sxp] !== 0) continue;
          var sidx = (syp * w + sxp) * 4;
          var didx = i2 * 4;
          d[didx] = d[sidx] * mv + d[didx] * (1 - mv);
          d[didx + 1] = d[sidx + 1] * mv + d[didx + 1] * (1 - mv);
          d[didx + 2] = d[sidx + 2] * mv + d[didx + 2] * (1 - mv);
          d[didx + 3] = 255;
          break;
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
    return true;
  }

  // Detect connected dark relief, including oblique/partially cropped rings.
  // Do not assume that a photographed circle is still circular.
  function repairRelief(canvas, preset) {
    var w = Math.min(420, canvas.width);
    var h = Math.max(8, Math.round(canvas.height * w / canvas.width));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var ctx = c.getContext('2d'); ctx.drawImage(canvas, 0, 0, w, h);
    var im = ctx.getImageData(0, 0, w, h), d = im.data, n = w * h;
    var L = new Float32Array(n), i, x, y;
    for (i = 0; i < n; i++) L[i] = .299 * d[4*i] + .587 * d[4*i+1] + .114 * d[4*i+2];
    var local = boxBlur(L, w, h, Math.max(7, Math.round(w * .025)));
    var dark = new Uint8Array(n);
    for (i = 0; i < n; i++) if (d[i*4+3] > 245 && local[i] - L[i] > 17 && L[i] < local[i] * .72) dark[i] = 1;
    var joined = morph(morph(dark, w, h, 2, true), w, h, 2, false);
    var visited = new Uint8Array(n), queue = new Int32Array(n), defects = new Uint8Array(n), found = false;
    for (i = 0; i < n; i++) {
      if (preset || !joined[i] || visited[i]) continue;
      var head = 0, tail = 1, x0=w, x1=0, y0=h, y1=0;
      queue[0]=i; visited[i]=1;
      while (head < tail) {
        var p=queue[head++]; x=p%w; y=(p-x)/w;
        x0=Math.min(x0,x); x1=Math.max(x1,x); y0=Math.min(y0,y); y1=Math.max(y1,y);
        var nb=[x>0?p-1:-1,x<w-1?p+1:-1,y>0?p-w:-1,y<h-1?p+w:-1];
        for(var k=0;k<4;k++) if(nb[k]>=0 && joined[nb[k]] && !visited[nb[k]]) {visited[nb[k]]=1;queue[tail++]=nb[k];}
      }
      var bw=x1-x0+1,bh=y1-y0+1;
      // A ring is a long, thin component; isolated grains and broad shadows are not defects.
      if(bw<w*.22 || bh<h*.22 || tail<80 || tail>bw*bh*.42) continue;
      found=true; for(var q=0;q<tail;q++) defects[queue[q]]=1;
    }
    if(preset){found=true;for(var iy=0;iy<h;iy++)for(var ix=0;ix<w;ix++)defects[iy*w+ix]=preset.mask[Math.min(preset.h-1,Math.floor(iy*preset.h/h))*preset.w+Math.min(preset.w-1,Math.floor(ix*preset.w/w))];}
    if(!found) return {found:false};
    if(!preset)defects=morph(defects,w,h,Math.max(8,Math.round(w*.045)),true);
    // Harmonic extension at reduced resolution preserves the local colour gradient.
    var fw=160, fh=Math.max(8,Math.round(h*fw/w));
    var mc=document.createElement('canvas');mc.width=w;mc.height=h;
    var mi=mc.getContext('2d').createImageData(w,h);
    for(i=0;i<n;i++) mi.data[i*4+3]=defects[i]?255:0;
    mc.getContext('2d').putImageData(mi,0,0);
    var small=document.createElement('canvas');small.width=fw;small.height=fh;
    var sc=small.getContext('2d');sc.drawImage(canvas,0,0,fw,fh);
    var sd=sc.getImageData(0,0,fw,fh).data;
    var maskc=document.createElement('canvas');maskc.width=fw;maskc.height=fh;
    maskc.getContext('2d').drawImage(mc,0,0,fw,fh);
    var md=maskc.getContext('2d').getImageData(0,0,fw,fh).data;
    var fn=fw*fh, field=new Float32Array(fn*3), known=new Uint8Array(fn), dist=new Int32Array(fn), nearest=new Int32Array(fn), qq=new Int32Array(fn);
    var ht=0,tt=0;
    for(i=0;i<fn;i++) {for(k=0;k<3;k++)field[i*3+k]=sd[i*4+k]; if(md[i*4+3]<12){known[i]=1;nearest[i]=i;qq[tt++]=i;} else dist[i]=-1;}
    while(ht<tt) {
      p=qq[ht++]; x=p%fw;y=(p-x)/fw;
      nb=[x>0?p-1:-1,x<fw-1?p+1:-1,y>0?p-fw:-1,y<fh-1?p+fw:-1];
      for(k=0;k<4;k++)if(nb[k]>=0 && dist[nb[k]]===-1){var j=nb[k];dist[j]=dist[p]+1;nearest[j]=nearest[p];for(q=0;q<3;q++)field[j*3+q]=field[nearest[j]*3+q];qq[tt++]=j;}
    }
    for(var it=0;it<420;it++) for(i=0;i<fn;i++) {
      if(known[i])continue;x=i%fw;y=(i-x)/fw;
      nb=[x>0?i-1:i,x<fw-1?i+1:i,y>0?i-fw:i,y<fh-1?i+fw:i];
      for(k=0;k<3;k++)field[i*3+k]=(field[nb[0]*3+k]+field[nb[1]*3+k]+field[nb[2]*3+k]+field[nb[3]*3+k])*.25;
    }
    var fi=sc.createImageData(fw,fh);
    for(i=0;i<fn;i++){for(k=0;k<3;k++)fi.data[i*4+k]=field[i*3+k];fi.data[i*4+3]=255;}
    sc.putImageData(fi,0,0);
    var ow=canvas.width,oh=canvas.height,oc=canvas.getContext('2d'),oi=oc.getImageData(0,0,ow,oh),original=oi.data;
    var filled=document.createElement('canvas');filled.width=ow;filled.height=oh;
    filled.getContext('2d').drawImage(small,0,0,ow,oh);
    var fd=filled.getContext('2d').getImageData(0,0,ow,oh).data;
    var fullMeans=[];
    for(k=0;k<3;k++){var channel=new Float32Array(ow*oh);for(i=0;i<ow*oh;i++)channel[i]=original[i*4+k];fullMeans[k]=boxBlur(channel,ow,oh,Math.max(3,Math.round(ow*.012)));}
    var soft=boxBlur(defects,w,h,3);
    var donors=[],patch=Math.max(16,Math.round(ow*.06)),step=Math.max(8,Math.floor(patch/2));
    for(y=0;y<=oh-patch;y+=step)for(x=0;x<=ow-patch;x+=step){
      var clean=true;
      for(var sy=0;sy<=patch && clean;sy+=Math.max(1,Math.floor(patch/4)))for(var sx=0;sx<=patch;sx+=Math.max(1,Math.floor(patch/4))){
        var ax=Math.min(w-1,Math.floor((x+sx)*w/ow)),ay=Math.min(h-1,Math.floor((y+sy)*h/oh));
        if(defects[ay*w+ax] || soft[ay*w+ax]>.01){clean=false;break;}
      }
      if(clean)donors.push({x:x,y:y,p:Math.min(oh-1,y+(patch>>1))*ow+Math.min(ow-1,x+(patch>>1))});
    }
    if(!donors.length)return {found:false};
    var sums=[new Float32Array(ow*oh),new Float32Array(ow*oh),new Float32Array(ow*oh)],weights=new Float32Array(ow*oh);
    for(y=-step;y<oh;y+=step)for(x=-step;x<ow;x+=step){
      var tx=Math.max(0,Math.min(ow-1,x+(patch>>1))),ty=Math.max(0,Math.min(oh-1,y+(patch>>1)));
      var di=ty*ow+tx,bi=Math.min(h-1,Math.floor(ty*h/oh))*w+Math.min(w-1,Math.floor(tx*w/ow));
      var affected=defects[bi] || soft[bi]>.001;
      if(!affected){
        for(sy=0;sy<patch && !affected;sy+=step)for(sx=0;sx<patch;sx+=step){var aa=Math.max(0,Math.min(h-1,Math.floor((y+sy)*h/oh)))*w+Math.max(0,Math.min(w-1,Math.floor((x+sx)*w/ow)));if(defects[aa] || soft[aa]>.001)affected=true;}
      }
      if(!affected)continue;
      var chosen=null,bestScore=1e20;
      for(var dd=0;dd<donors.length;dd++){
        var donor=donors[dd],score=0;
        for(k=0;k<3;k++){var delta=fullMeans[k][donor.p]-fd[di*4+k];score+=delta*delta;}
        score+=((donor.x-x)*(donor.x-x)+(donor.y-y)*(donor.y-y))*.0005;
        score+=((dd*17+x*3+y*7)%31+31)%31;
        if(score<bestScore){bestScore=score;chosen=donor;}
      }
      for(sy=0;sy<patch;sy++)for(sx=0;sx<patch;sx++){
        var ox=x+sx,oy=y+sy;if(ox<0 || oy<0 || ox>=ow || oy>=oh)continue;
        var dst=oy*ow+ox,srcp=(chosen.y+sy)*ow+chosen.x+sx;
        var ww=Math.sin(Math.PI*(sx+.5)/patch)*Math.sin(Math.PI*(sy+.5)/patch);ww*=ww;
        for(k=0;k<3;k++)sums[k][dst]+=(original[srcp*4+k]-fullMeans[k][srcp])*ww;
        weights[dst]+=ww;
      }
    }
    for(y=0;y<oh;y++)for(x=0;x<ow;x++){
      var a=Math.min(h-1,Math.floor(y*h/oh))*w+Math.min(w-1,Math.floor(x*w/ow));
      var weight=defects[a]?1:soft[a];if(weight<.001)continue;
      var dst=y*ow+x;
      for(k=0;k<3;k++){var texture=weights[dst]>0?sums[k][dst]/weights[dst]*1.35:0;original[dst*4+k]=original[dst*4+k]*(1-weight)+(fd[dst*4+k]+texture)*weight;}
    }
    oc.putImageData(oi,0,0);
    return {found:true,mask:mc};
  }

  // Fit complete elliptical relief before the card is cropped. Polygon edges are not masks.
  function ellipseRelief(src, radiusLimit) {
    var scale=Math.min(1,420/Math.max(src.width,src.height)),w=Math.round(src.width*scale),h=Math.round(src.height*scale);
    var c=document.createElement('canvas');c.width=w;c.height=h;var ctx=c.getContext('2d');ctx.drawImage(src,0,0,w,h);
    var d=ctx.getImageData(0,0,w,h).data,n=w*h,L=new Float32Array(n),mag=new Float32Array(n),gx=new Float32Array(n),gy=new Float32Array(n),i,x,y;
    for(i=0;i<n;i++)L[i]=.299*d[i*4]+.587*d[i*4+1]+.114*d[i*4+2];
    L=boxBlur(L,w,h,1);
    for(y=2;y<h-2;y++)for(x=2;x<w-2;x++){i=y*w+x;gx[i]=L[i+1]-L[i-1];gy[i]=L[i+w]-L[i-w];mag[i]=Math.sqrt(gx[i]*gx[i]+gy[i]*gy[i]);}
    var edge=new Uint8Array(n);
    for(y=2;y<h-2;y++)for(x=2;x<w-2;x++){i=y*w+x;var dx=Math.abs(gx[i]),dy=Math.abs(gy[i]),a,b;if(dy<dx*.414){a=i-1;b=i+1;}else if(dx<dy*.414){a=i-w;b=i+w;}else if(gx[i]*gy[i]>0){a=i-w-1;b=i+w+1;}else{a=i-w+1;b=i+w-1;}if(mag[i]>7 && mag[i]>=mag[a] && mag[i]>=mag[b])edge[i]=1;}
    var points=[];for(i=0;i<n;i++)if(edge[i])points.push(i);
    var seen=new Uint8Array(n),queue=new Int32Array(n),best=null;
    function solve(M,v){for(var j=0;j<5;j++){var pivot=j;for(var k=j+1;k<5;k++)if(Math.abs(M[k][j])>Math.abs(M[pivot][j]))pivot=k;var rr=M[j];M[j]=M[pivot];M[pivot]=rr;var vv=v[j];v[j]=v[pivot];v[pivot]=vv;if(Math.abs(M[j][j])<1e-8)return null;var div=M[j][j];for(k=j;k<5;k++)M[j][k]/=div;v[j]/=div;for(var l=0;l<5;l++){if(l===j)continue;var f=M[l][j];for(k=j;k<5;k++)M[l][k]-=f*M[j][k];v[l]-=f*v[j];}}return v;}
    for(i=0;i<n;i++){if(!edge[i] || seen[i])continue;var head=0,tail=1;queue[0]=i;seen[i]=1;while(head<tail){var q=queue[head++],xx=q%w,yy=(q-xx)/w;for(var sy=-1;sy<=1;sy++)for(var sx=-1;sx<=1;sx++){var ni=q+sy*w+sx;if(xx+sx<1 || xx+sx>=w-1 || yy+sy<1 || yy+sy>=h-1)continue;if(edge[ni]&&!seen[ni]){seen[ni]=1;queue[tail++]=ni;}}}
      if(tail<55)continue;
      for(var trial=0;trial<240;trial++){
      var M=[],v=[0,0,0,0,0];for(var j=0;j<5;j++)M[j]=[0,0,0,0,0];
      for(var z=0;z<(trial?5:tail);z++){q=queue[trial?((trial*7381+z*19391+trial*z*997)%tail):z];xx=(q%w)/w-.5;yy=Math.floor(q/w)/w-.5;var row=[xx*xx,xx*yy,yy*yy,xx,yy];for(j=0;j<5;j++){v[j]+=row[j];for(var k=0;k<5;k++)M[j][k]+=row[j]*row[k];}}
      var f=solve(M,v);if(!f)continue;var A=f[0],B=f[1],C=f[2],D=f[3],E=f[4],det=4*A*C-B*B;if(det<=0)continue;
      var cx=(B*E-2*C*D)/det,cy=(B*D-2*A*E)/det,F=1-(A*cx*cx+B*cx*cy+C*cy*cy+D*cx+E*cy),disc=Math.sqrt((A-C)*(A-C)+B*B),l1=(A+C+disc)/2,l2=(A+C-disc)/2;
      if(F/l1<=0 || F/l2<=0)continue;var r1=Math.sqrt(F/l1)*w,r2=Math.sqrt(F/l2)*w,angle=.5*Math.atan2(B,A-C),ct=Math.cos(angle),st=Math.sin(angle);cx=(cx+.5)*w;cy=(cy+.5)*w;
      var lo=Math.min(r1,r2),hi=Math.max(r1,r2),dm=Math.min(w,h);if(lo<dm*.08 || hi>dm*(radiusLimit || .30) || hi/lo>2.3 || cx<hi*.65 || cy<hi*.65 || cx>w-hi*.65 || cy>h-hi*.65)continue;
      var ownInliers=0;for(z=0;z<tail;z++){q=queue[z];xx=q%w-cx;yy=Math.floor(q/w)-cy;var ou=(ct*xx+st*yy)/r1,ov=(-st*xx+ct*yy)/r2;if(Math.abs(Math.sqrt(ou*ou+ov*ov)-1)*lo<2.5)ownInliers++;}if(ownInliers/tail<.55 || ownInliers<60)continue;
      var inliers=0,bins=new Uint8Array(36),error=0;
      for(z=0;z<points.length;z++){q=points[z];xx=q%w-cx;yy=Math.floor(q/w)-cy;var u=(ct*xx+st*yy)/r1,t=(-st*xx+ct*yy)/r2,rad=Math.sqrt(u*u+t*t),err=Math.abs(rad-1)*lo;if(err<2.5){inliers++;bins[Math.min(35,Math.floor((Math.atan2(t,u)+Math.PI)/(2*Math.PI)*36))]=1;}error+=Math.min(10,err);}
      var coverage=0;for(z=0;z<36;z++)coverage+=bins[z];if(inliers<70 || coverage<21)continue;
      var score=inliers*(coverage/36)/(1+error/points.length);if(!best || score>best.score)best={cx:cx/scale,cy:cy/scale,r1:r1/scale,r2:r2/scale,angle:angle,score:score,coverage:coverage/36};
      }
    }
    if(best){
      for(var refine=0;refine<3;refine++){
        var bc=best.cx*scale,by=best.cy*scale,br1=best.r1*scale,br2=best.r2*scale,ca=Math.cos(best.angle),sa=Math.sin(best.angle),M=[],v=[0,0,0,0,0],cnt=0;for(var j=0;j<5;j++)M[j]=[0,0,0,0,0];
        for(var z=0;z<points.length;z++){var p=points[z],dx=p%w-bc,dy=Math.floor(p/w)-by,u=(ca*dx+sa*dy)/br1,t=(-sa*dx+ca*dy)/br2;if(Math.abs(Math.sqrt(u*u+t*t)-1)*Math.min(br1,br2)>3)continue;var xx=(p%w)/w-.5,yy=Math.floor(p/w)/w-.5,row=[xx*xx,xx*yy,yy*yy,xx,yy];cnt++;for(j=0;j<5;j++){v[j]+=row[j];for(var k=0;k<5;k++)M[j][k]+=row[j]*row[k];}}
        var f=solve(M,v);if(!f || cnt<70)break;var A=f[0],B=f[1],C=f[2],D=f[3],E=f[4],det=4*A*C-B*B;if(det<=0)break;var cx=(B*E-2*C*D)/det,cy=(B*D-2*A*E)/det,F=1-(A*cx*cx+B*cx*cy+C*cy*cy+D*cx+E*cy),disc=Math.sqrt((A-C)*(A-C)+B*B),l1=(A+C+disc)/2,l2=(A+C-disc)/2;if(F/l1<=0 || F/l2<=0)break;var r1=Math.sqrt(F/l1)*w,r2=Math.sqrt(F/l2)*w;cx=(cx+.5)*w;cy=(cy+.5)*w;
        if(Math.abs(cx-bc)+Math.abs(cy-by)>8 || Math.abs(r1-br1)+Math.abs(r2-br2)>10)break;best.cx=cx/scale;best.cy=cy/scale;best.r1=r1/scale;best.r2=r2/scale;best.angle=.5*Math.atan2(B,A-C);
      }
    }
    return best;
  }
  function repairEllipse(canvas,ellipse,rect) {
    var ctx=canvas.getContext('2d'),im=ctx.getImageData(0,0,canvas.width,canvas.height),d=im.data,w=canvas.width,h=canvas.height,n=w*h,mask=new Uint8Array(n),count=0;
    var ct=Math.cos(ellipse.angle),st=Math.sin(ellipse.angle),lo=Math.min(ellipse.r1,ellipse.r2),band=Math.max(4,lo*.17),i,x,y,k;
    var darkPixels=0;for(i=0;i<n;i++)if((d[i*4]+d[i*4+1]+d[i*4+2])/3<25)darkPixels++;if(darkPixels>n*.40)band=Math.max(4,lo*.085);
    for(y=0;y<h;y++)for(x=0;x<w;x++){var dx=x+rect.x-ellipse.cx,dy=y+rect.y-ellipse.cy,u=(ct*dx+st*dy)/ellipse.r1,v=(-st*dx+ct*dy)/ellipse.r2;if(Math.abs(Math.sqrt(u*u+v*v)-1)*lo<band){mask[y*w+x]=1;count++;}}
    if(!count)return false;
    if(darkPixels<=n*.40)return repairRelief(canvas,{mask:mask,w:w,h:h}).found;

    // Thin-band diffusion leaves the existing polygon shapes on either side intact.
    var a=new Float32Array(n*3),b=new Float32Array(n*3);for(i=0;i<n;i++)for(k=0;k<3;k++)a[i*3+k]=d[i*4+k];
    for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!mask[i])continue;var dx=x+rect.x-ellipse.cx,dy=y+rect.y-ellipse.cy,uu=ct*dx+st*dy,vv=-st*dx+ct*dy,nx=ct*uu/(ellipse.r1*ellipse.r1)-st*vv/(ellipse.r2*ellipse.r2),ny=st*uu/(ellipse.r1*ellipse.r1)+ct*vv/(ellipse.r2*ellipse.r2),len=Math.sqrt(nx*nx+ny*ny);nx/=len;ny/=len;
      var ends=[],steps=[];for(var side=-1;side<=1;side+=2){for(var distance=1;distance<band*4+8;distance++){var ex=Math.round(x+nx*distance*side),ey=Math.round(y+ny*distance*side);if(ex<0 || ey<0 || ex>=w || ey>=h)break;var ep=ey*w+ex;if(!mask[ep]){ends.push(ep);steps.push(distance);break;}}}
      if(ends.length===2)for(k=0;k<3;k++)a[i*3+k]=(d[ends[0]*4+k]*steps[1]+d[ends[1]*4+k]*steps[0])/(steps[0]+steps[1]);else if(ends.length)for(k=0;k<3;k++)a[i*3+k]=d[ends[0]*4+k];
    }
    for(var iter=0;iter<180;iter++){b.set(a);for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!mask[i])continue;var left=x?i-1:i,right=x<w-1?i+1:i,up=y?i-w:i,down=y<h-1?i+w:i;for(k=0;k<3;k++)b[i*3+k]=(a[left*3+k]+a[right*3+k]+a[up*3+k]+a[down*3+k])*.25;}var tmp=a;a=b;b=tmp;}
    for(i=0;i<n;i++)if(mask[i])for(k=0;k<3;k++)d[i*4+k]=a[i*3+k];ctx.putImageData(im,0,0);return true;
  }

  function process(src, opts) {
    opts=opts||{};
    var out={canvas:src,cropFound:false,ringFound:false};
    // An existing close-up texture must remain usable with crop disabled or no card found.
    var opaque=!hasAlpha(src);
    var sw=opts.crop && opaque?detectSwatch(src):null;
    var ring=opts.dering && opaque?ellipseRelief(src,sw?.30:.48):null;
    var rect=sw?sw.srcRect:{x:0,y:0,w:src.width||src.naturalWidth,h:src.height||src.naturalHeight};
    var sq=document.createElement('canvas');sq.width=rect.w;sq.height=rect.h;
    sq.getContext('2d').drawImage(src,rect.x,rect.y,rect.w,rect.h,0,0,rect.w,rect.h);
    out.cropFound=!!sw;out.rect=rect;
    if(ring)out.ringFound=repairEllipse(sq,ring,rect);
    out.ringGeometry=ring;
    out.canvas=sq;return out;
  }

  function hasAlpha(c) {
    var t=document.createElement('canvas');t.width=32;t.height=32;t.getContext('2d').drawImage(c,0,0,32,32);
    var d=t.getContext('2d').getImageData(0,0,32,32).data;
    for(var i=3;i<d.length;i+=4)if(d[i]<245)return true;
    return false;
  }


  window.FoilUSwatch = {
    rotateCanvas: rotateCanvas,
    detectSwatch: detectSwatch,
    detectRing: detectRing,
    ellipseRelief: ellipseRelief,
    process: process
  };
})();
