(function (root) {
  'use strict';
  var brands = ['皇泰烫金','金昌泰','金合彩','金彩虹','金穗','臻彩','库尔兹','卓鑫','鑫昌泰','恒昌','晨辉','辉煌','殷帆','升盛'];
  var patterns = [
    ['猫眼'],['彩虹','幻彩','七彩','镭射'],['拉丝','布纹','丝纹'],['冰霜','冰花','冰川','冰块'],
    ['万花筒','棱镜'],['流沙','沙点','磨砂','砂'],['玻璃碎','碎玻璃','碎面','碎裂','碎片'],
    ['圆圈','圆环','圆点','乱点','晶点','亮点','网点'],['回字','迷宫'],['光柱','光炬','光带','光波'],
    ['火焰','岩浆','烧箔'],['云彩','彩云','云'],['爱心','心形'],['星星','五角星','白星','星'],
    ['方格','方块','矩形','砖石','宝石'],['水纹','波浪','涟漪'],['橘皮'],['松针'],['素面','金属','亮面','哑']
  ];
  var colors = {jin:['金'],yin:['银'],tou:['透明'],zhu:['珠光'],hong:['红'],fen:['粉','桃','玫'],lv:['绿'],lan:['蓝','青'],zi:['紫'],huang:['黄'],cheng:['橙'],tong:['铜','棕','咖啡'],hei:['黑'],bai:['白','white'],hui:['灰'],cai:['彩虹','幻彩','七彩','镭射','彩云']};
  function normal(s) {return String(s||'').toLowerCase().replace(/kurz/g,'库尔兹').replace(/蘭|兰/g,'蓝').replace(/[\s\-—_()（）\[\]【】+＋、,，.]/g,'');}
  function brand(s) {s=normal(s);for(var i=0;i<brands.length;i++)if(s.indexOf(brands[i])>=0)return brands[i];return '';}
  function core(s) {s=normal(s);for(var i=0;i<brands.length;i++)s=s.split(brands[i]).join('');return s.replace(/单烫|双烫|烫色|烫印|图层|烫/g,'');}
  function models(s) {return normal(s).match(/[a-z]*\d+[a-z\d]*/g)||[];}
  function tailLetter(s) {var m=String(s||'').match(/[a-z]$/);return m?m[0]:'';}
  function features(s,tags) {
    s=core(s);var p=[],c=[];
    for(var i=0;i<patterns.length;i++)for(var j=0;j<patterns[i].length;j++)if(s.indexOf(patterns[i][j])>=0){p.push(i);break;}
    for(var k in colors)if(colors.hasOwnProperty(k))for(j=0;j<colors[k].length;j++)if(s.indexOf(colors[k][j])>=0){c.push(k);break;}
    (tags||[]).forEach(function(t){if(colors[t] && c.indexOf(t)<0)c.push(t);});
    return {p:p,c:c};
  }
  function overlap(a,b) {var n=0;for(var i=0;i<a.length;i++)if(b.indexOf(a[i])>=0)n++;return n;}
  function distance(a,b) {
    var row=[],i,j;for(j=0;j<=b.length;j++)row[j]=j;
    for(i=1;i<=a.length;i++){var prev=row[0];row[0]=i;for(j=1;j<=b.length;j++){var old=row[j];row[j]=Math.min(row[j]+1,row[j-1]+1,prev+(a[i-1]===b[j-1]?0:1));prev=old;}}return row[b.length];
  }
  function match(name,materials) {
    if(!materials.length)return null;
    var ln=normal(name),lc=core(name),lb=brand(name),lm=models(name),lf=features(name),lt=tailLetter(lc),best=null;
    for(var i=0;i<materials.length;i++) {
      var m=materials[i],mn=normal(m.name),mc=core(m.name),mb=brand(m.name),mm=models(m.name),mf=features(m.name,m.tags),mt2=tailLetter(mc);
      var score=0,method='';
      var bp=lb&&mb===lb?20:0;
      if(mn.length>=2 && ln.indexOf(mn)>=0){score=1000+mn.length+bp;method='exact';}
      else if(mc.length>=2 && lc.indexOf(mc)>=0){score=850+mc.length+bp;method='name';}
      else {
        var sameModel=overlap(lm,mm),fuzzyModel=0;
        for(var a=0;a<lm.length;a++)for(var b=0;b<mm.length;b++)if(lm[a].length>=4 && mm[b].length>=4 && distance(lm[a],mm[b])===1)fuzzyModel=1;
        var pc=overlap(lf.p,mf.p),cc=overlap(lf.c,mf.c);
        // Model hits outrank semantic fallbacks. Wrong colours lower pattern-only matches.
        var fuzzyName=lc.length>=3 && mc.length>=3 && Math.abs(lc.length-mc.length)<=1 && distance(lc,mc)===1 && (!lf.c.length || cc);
        score=sameModel?700+bp:(fuzzyModel?400+bp:(fuzzyName?300+bp:bp));
        if(pc)score+=80*pc;else if(lf.p.length&&mf.p.length)score-=20;
        if(cc)score+=55*cc;else if(lf.c.length)score-=65;
        if(sameModel || fuzzyModel || fuzzyName)method='fuzzy';
        else if(pc || cc)method='similar';
        if(!method)continue;
        // 型号尾字母（A/B/C/D 等变体）区分：相同加分、不同降权，避免永远命中首个变体
        if(lt && mt2) { if(lt === mt2) score += 60; else score -= 200; }
        // Exact named pattern words distinguish members of a related family.
        for(a=0;a<patterns.length;a++)for(b=0;b<patterns[a].length;b++)if(lc.indexOf(patterns[a][b])>=0 && mc.indexOf(patterns[a][b])>=0)score+=12;
      }
      if(!best || score>best.score)best={name:m.name,method:method,score:score};
    }
    return best;
  }
  root.FoilUMatching={match:match,normal:normal};
  if(typeof module!=='undefined' && module.exports)module.exports=root.FoilUMatching;
})(typeof window!=='undefined'?window:this);
