(function () {
  'use strict';

  var cep = window.FoilUCep;
  var cp = null;
  try {
    cp = cep.require('child_process');
  } catch (e) {}

  var PS1 = [
    'param([string]$Path, [string]$Out)',
    '$ProgressPreference = "SilentlyContinue"',
    'Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null',
    '$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq "IAsyncOperation``1" })[0]',
    'function Await($op, $t) {',
    '  $m = $asTaskGeneric.MakeGenericMethod($t)',
    '  $task = $m.Invoke($null, @($op))',
    '  $task.Wait(-1) | Out-Null',
    '  $task.Result',
    '}',
    '[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null',
    '[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null',
    '[Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null',
    '[Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null',
    '$engine = $null',
    'foreach ($tag in @("zh-Hans-CN", "zh-Hans", "zh-Hant-HK", "ja")) {',
    '  try {',
    '    $lg = New-Object Windows.Globalization.Language $tag',
    '    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lg)',
    '  } catch {}',
    '  if ($engine -ne $null) { break }',
    '}',
    'if ($engine -eq $null) { try { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() } catch {} }',
    'if ($engine -eq $null) {',
    '  try {',
    '    $langs = [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages',
    '    foreach ($lg in $langs) {',
    '      try { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lg) } catch {}',
    '      if ($engine -ne $null) { break }',
    '    }',
    '  } catch {}',
    '}',
    'if ($engine -eq $null) { [IO.File]::WriteAllText($Out, "", [Text.Encoding]::UTF8); exit }',
    '$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])',
    '$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])',
    '$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])',
    '$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])',
    '$res = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])',
    '$txt = ""',
    'foreach ($line in $res.Lines) { $txt = $txt + $line.Text + " " }',
    '[IO.File]::WriteAllText($Out, $txt, [Text.Encoding]::UTF8)'
  ].join('\r\n');

  var scriptReady = false;

  function available() {
    return !!(cp && cep.fs && cep.workDir);
  }

  function ensureScript() {
    if (scriptReady) return true;
    try {
      cep.fs.writeFileSync(cep.workDir + '/foilu_ocr.ps1', PS1);
      scriptReady = true;
      return true;
    } catch (e) {
      return false;
    }
  }

  function native(p) {
    return String(p).replace(/\//g, '\\');
  }

  function savePng(canvas, path, cb) {
    try {
      canvas.toBlob(function (blob) {
        if (!blob) { cb(false); return; }
        var fr = new FileReader();
        fr.onload = function () {
          cb(cep.writeBuffer(path, new Uint8Array(fr.result)));
        };
        fr.readAsArrayBuffer(blob);
      }, 'image/png');
    } catch (e) {
      cb(false);
    }
  }

  function runOcr(pngPath, outPath, cb) {
    var args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', native(cep.workDir + '/foilu_ocr.ps1'), '-Path', native(pngPath), '-Out', native(outPath)];
    try {
      cp.execFile('powershell.exe', args, { timeout: 30000, windowsHide: true }, function (err) {
        if (err) { cb(null); return; }
        try {
          var txt = cep.fs.readFileSync(outPath, 'utf8');
          cb(String(txt).replace(/\s+/g, ' ').trim());
        } catch (e) {
          cb(null);
        }
      });
    } catch (e) {
      cb(null);
    }
  }

  function ocrCanvas(canvas, tag, cb) {
    if (!available() || !ensureScript()) { cb(null); return; }
    var png = cep.workDir + '/ocr_' + tag + '.png';
    var out = cep.workDir + '/ocr_' + tag + '.txt';
    savePng(canvas, png, function (ok) {
      if (!ok) { cb(null); return; }
      runOcr(png, out, cb);
    });
  }

  function cleanText(t) {
    if (!t) return '';
    var s = String(t).replace(/\s+/g, '');
    s = s.replace(/([A-Za-z0-9])[一\-－—–_]([A-Za-z0-9])/g, '$1-$2');
    s = s.replace(/[－—–]/g, '-');
    return s;
  }

  function scoreText(t) {
    if (!t) return 0;
    var n = 0;
    for (var i = 0; i < t.length; i++) {
      var c = t.charCodeAt(i);
      if ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c > 0x2E80) n++;
    }
    return n;
  }

  function detectOrientation(sourceCanvas, cb) {
    if (!available() || !ensureScript() || !window.FoilUSwatch) { cb(null); return; }
    var angles = [0, 90, 180, 270];
    var idx = 0;
    var results = [];
    function next() {
      if (idx >= angles.length) {
        var best = null;
        for (var i = 0; i < results.length; i++) {
          if (!best || results[i].score > best.score) best = results[i];
        }
        cb(best);
        return;
      }
      var a = angles[idx++];
      var rot = window.FoilUSwatch.rotateCanvas(sourceCanvas, a);
      ocrCanvas(rot, 'r' + a, function (text) {
        results.push({ angle: a, score: scoreText(text), text: text || '' });
        next();
      });
    }
    next();
  }

  window.FoilUOcr = {
    available: available,
    ocrCanvas: ocrCanvas,
    detectOrientation: detectOrientation,
    scoreText: scoreText,
    cleanText: cleanText
  };
})();
