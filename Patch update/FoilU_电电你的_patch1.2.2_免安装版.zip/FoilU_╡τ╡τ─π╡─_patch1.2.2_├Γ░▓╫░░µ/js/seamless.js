(function () {
  'use strict';

  function coverSquare(img, size) {
    var c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    var ctx = c.getContext('2d');
    var iw = img.naturalWidth || img.width;
    var ih = img.naturalHeight || img.height;
    var s = Math.max(size / iw, size / ih);
    var dw = Math.round(iw * s);
    var dh = Math.round(ih * s);
    ctx.drawImage(img, Math.round((size - dw) / 2), Math.round((size - dh) / 2), dw, dh);
    return c;
  }

  function edgeDiff(canvas) {
    var size = canvas.width;
    var ctx = canvas.getContext('2d');
    var left = ctx.getImageData(0, 0, 1, size).data;
    var right = ctx.getImageData(size - 1, 0, 1, size).data;
    var top = ctx.getImageData(0, 0, size, 1).data;
    var bottom = ctx.getImageData(0, size - 1, size, 1).data;
    var sum = 0;
    for (var i = 0; i < size; i++) {
      var j = i * 4;
      sum += Math.abs(left[j] - right[j]) + Math.abs(left[j + 1] - right[j + 1]) +
        Math.abs(left[j + 2] - right[j + 2]) + Math.abs(left[j + 3] - right[j + 3]);
      sum += Math.abs(top[j] - bottom[j]) + Math.abs(top[j + 1] - bottom[j + 1]) +
        Math.abs(top[j + 2] - bottom[j + 2]) + Math.abs(top[j + 3] - bottom[j + 3]);
    }
    return sum / (size * 8);
  }

  function pixelCost(da, db, ia, ib) {
    return Math.abs(da[ia] - db[ib]) + Math.abs(da[ia + 1] - db[ib + 1]) +
      Math.abs(da[ia + 2] - db[ib + 2]) + Math.abs(da[ia + 3] - db[ib + 3]);
  }

  function findCutPath(cost, bandW, steps) {
    var prev = new Float64Array(bandW);
    var next = new Float64Array(bandW);
    var parents = new Uint8Array(bandW * steps);
    var x, y;
    for (x = 0; x < bandW; x++) prev[x] = cost[x];
    for (y = 1; y < steps; y++) {
      var off = y * bandW;
      for (x = 0; x < bandW; x++) {
        var best = prev[x];
        var dir = 1;
        if (x > 0 && prev[x - 1] < best) {
          best = prev[x - 1];
          dir = 0;
        }
        if (x < bandW - 1 && prev[x + 1] < best) {
          best = prev[x + 1];
          dir = 2;
        }
        next[x] = best + cost[off + x];
        parents[off + x] = dir;
      }
      var tmp = prev;
      prev = next;
      next = tmp;
    }
    var path = new Int32Array(steps);
    var bx = 0;
    var bv = prev[0];
    for (x = 1; x < bandW; x++) {
      if (prev[x] < bv) {
        bv = prev[x];
        bx = x;
      }
    }
    path[steps - 1] = bx;
    for (y = steps - 1; y > 0; y--) {
      var d = parents[y * bandW + path[y]];
      path[y - 1] = path[y] + (d === 0 ? -1 : (d === 2 ? 1 : 0));
      if (path[y - 1] < 0) path[y - 1] = 0;
      if (path[y - 1] > bandW - 1) path[y - 1] = bandW - 1;
    }
    return path;
  }

  function closePath(path, n, k) {
    var start = Math.max(0, n - k - 1);
    var a = path[start];
    var b = path[0];
    if (a === b) return;
    for (var i = start + 1; i < n; i++) {
      var t = (i - start) / (n - start);
      path[i] = Math.round(a + (b - a) * t);
    }
  }

  function legacySeamless(img, size, featherRatio) {
    var base = coverSquare(img, size);
    var diff = edgeDiff(base);
    if (diff < 10) {
      return { canvas: base, blended: false, edgeDiff: diff };
    }
    var w = size;
    var h = size;
    var hw = Math.round(w / 2);
    var hh = Math.round(h / 2);
    var f = Math.max(8, Math.min(Math.round(w * featherRatio), Math.floor(w / 2) - 4, Math.floor(h / 2) - 4));
    var ctx = base.getContext('2d');
    var I = ctx.getImageData(0, 0, w, h).data;

    var S = new Uint8ClampedArray(I.length);
    var y, x, i;
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var sx = (x + hw) % w;
        i = (y * w + x) * 4;
        var si = (y * w + sx) * 4;
        S[i] = I[si];
        S[i + 1] = I[si + 1];
        S[i + 2] = I[si + 2];
        S[i + 3] = I[si + 3];
      }
    }

    var costL = new Float64Array(f * h);
    var costR = new Float64Array(f * h);
    for (y = 0; y < h; y++) {
      for (x = 0; x < f; x++) {
        var li = (y * w + hw - f + x) * 4;
        var ri = (y * w + hw + x) * 4;
        costL[y * f + x] = pixelCost(I, S, li, li);
        costR[y * f + x] = pixelCost(I, S, ri, ri);
      }
    }
    var pathL = findCutPath(costL, f, h);
    var pathR = findCutPath(costR, f, h);

    var T1 = new Uint8ClampedArray(I.length);
    T1.set(S);
    for (y = 0; y < h; y++) {
      var c1 = hw - f + pathL[y];
      var c2 = hw + pathR[y];
      for (x = c1; x < c2; x++) {
        i = (y * w + x) * 4;
        T1[i] = I[i];
        T1[i + 1] = I[i + 1];
        T1[i + 2] = I[i + 2];
        T1[i + 3] = I[i + 3];
      }
    }

    var S2 = new Uint8ClampedArray(I.length);
    for (y = 0; y < h; y++) {
      var sy = (y + hh) % h;
      S2.set(T1.subarray(sy * w * 4, (sy + 1) * w * 4), y * w * 4);
    }

    var costT = new Float64Array(w * f);
    var costB = new Float64Array(w * f);
    for (x = 0; x < w; x++) {
      for (y = 0; y < f; y++) {
        var ti = ((hh - f + y) * w + x) * 4;
        var bi = ((hh + y) * w + x) * 4;
        costT[x * f + y] = pixelCost(T1, S2, ti, ti);
        costB[x * f + y] = pixelCost(T1, S2, bi, bi);
      }
    }
    var pathT = findCutPath(costT, f, w);
    var pathB = findCutPath(costB, f, w);
    closePath(pathT, w, f);
    closePath(pathB, w, f);

    var T2 = new Uint8ClampedArray(I.length);
    T2.set(S2);
    for (x = 0; x < w; x++) {
      var r1 = hh - f + pathT[x];
      var r2 = hh + pathB[x];
      for (y = r1; y < r2; y++) {
        i = (y * w + x) * 4;
        T2[i] = T1[i];
        T2[i + 1] = T1[i + 1];
        T2[i + 2] = T1[i + 2];
        T2[i + 3] = T1[i + 3];
      }
    }

    var out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    var octx = out.getContext('2d');
    var outData = octx.createImageData(w, h);
    outData.data.set(T2);
    octx.putImageData(outData, 0, 0);
    return { canvas: out, blended: true, edgeDiff: diff };
  }

  function blurChannel(src,w,h,r) {
    var stride=w+1,ii=new Float64Array(stride*(h+1)),out=new Float32Array(w*h),x,y;
    for(y=0;y<h;y++){var sum=0;for(x=0;x<w;x++){sum+=src[y*w+x];ii[(y+1)*stride+x+1]=ii[y*stride+x+1]+sum;}}
    for(y=0;y<h;y++)for(x=0;x<w;x++){
      var x0=Math.max(0,x-r),x1=Math.min(w-1,x+r),y0=Math.max(0,y-r),y1=Math.min(h-1,y+r);
      out[y*w+x]=(ii[(y1+1)*stride+x1+1]-ii[y0*stride+x1+1]-ii[(y1+1)*stride+x0]+ii[y0*stride+x0])/((x1-x0+1)*(y1-y0+1));
    }return out;
  }

  // Match both sides symmetrically, leaving the centre and grain intact.
  function periodicEdges(d,w,h,band) {
    var x,y,k;
    for(y=0;y<h;y++)for(x=0;x<band;x++) {
      var t=x/Math.max(1,band-1),a=.25*(1+Math.cos(Math.PI*t));
      var l=(y*w+x)*4,r=(y*w+w-1-x)*4;
      for(k=0;k<4;k++){var v=d[l+k],u=d[r+k];d[l+k]=v*(1-a)+u*a;d[r+k]=u*(1-a)+v*a;}
    }
    for(y=0;y<band;y++)for(x=0;x<w;x++) {
      var t2=y/Math.max(1,band-1),a2=.25*(1+Math.cos(Math.PI*t2));
      var top=(y*w+x)*4,bot=((h-1-y)*w+x)*4;
      for(k=0;k<4;k++){var v2=d[top+k],u2=d[bot+k];d[top+k]=v2*(1-a2)+u2*a2;d[bot+k]=u2*(1-a2)+v2*a2;}
    }
  }

  function makeSeamless(img,size,featherRatio) {
    var base=coverSquare(img,size),ctx=base.getContext('2d'),im=ctx.getImageData(0,0,size,size),d=im.data;
    var diff=edgeDiff(base),n=size*size,i,k;
    if(hasSignificantAlpha(base)){
      // Blend in premultiplied space so transparent borders do not create black fringes.
      var pm=new Float32Array(d.length);for(i=0;i<n;i++){for(k=0;k<3;k++)pm[i*4+k]=d[i*4+k]*d[i*4+3]/255;pm[i*4+3]=d[i*4+3];}
      periodicEdges(pm,size,size,Math.max(8,Math.round(size*.16)));
      for(i=0;i<n;i++){for(k=0;k<3;k++)d[i*4+k]=pm[i*4+3]>0?pm[i*4+k]*255/pm[i*4+3]:0;d[i*4+3]=pm[i*4+3];}
      ctx.putImageData(im,0,0);return {canvas:base,blended:true,edgeDiff:diff};
    }
    // A large colour gradient cannot be repaired by a hard minimum-cost cut.
    // Separate colour and texture; cut only the small residual, blend the colour smoothly.
    var lows=[],rc=document.createElement('canvas');rc.width=size;rc.height=size;
    var ri=rc.getContext('2d').createImageData(size,size),lowRGBA=new Float32Array(n*4);
    for(k=0;k<3;k++){
      var ch=new Float32Array(n);for(i=0;i<n;i++)ch[i]=d[i*4+k];
      var low=blurChannel(ch,size,size,Math.max(4,Math.round(size*.045)));lows[k]=low;
      for(i=0;i<n;i++){ri.data[i*4+k]=128+(d[i*4+k]-low[i]);lowRGBA[i*4+k]=low[i];}
    }
    for(i=0;i<n;i++){ri.data[i*4+3]=255;lowRGBA[i*4+3]=255;}
    rc.getContext('2d').putImageData(ri,0,0);
    var residual=legacySeamless(rc,size,featherRatio).canvas;
    var rd=residual.getContext('2d').getImageData(0,0,size,size).data;
    periodicEdges(rd,size,size,Math.max(3,Math.round(size*.008)));
    periodicEdges(lowRGBA,size,size,Math.round(size*Math.max(.22,Math.min(.35,featherRatio||.18))));
    for(i=0;i<n;i++)for(k=0;k<3;k++)d[i*4+k]=lowRGBA[i*4+k]+rd[i*4+k]-128;
    // Quantisation can differ by one at the seam; force an exact shared edge.
    periodicEdges(d,size,size,2);
    ctx.putImageData(im,0,0);
    return {canvas:base,blended:true,edgeDiff:diff};
  }

  function hasSignificantAlpha(img) {
    var c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    var ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, 64, 64);
    var d = ctx.getImageData(0, 0, 64, 64).data;
    var n = 0;
    for (var i = 3; i < d.length; i += 4) {
      if (d[i] < 245) n++;
    }
    return n > 40;
  }

  window.FoilUSeam = {
    makeSeamless: makeSeamless,
    coverSquare: coverSquare,
    hasSignificantAlpha: hasSignificantAlpha
  };
})();
