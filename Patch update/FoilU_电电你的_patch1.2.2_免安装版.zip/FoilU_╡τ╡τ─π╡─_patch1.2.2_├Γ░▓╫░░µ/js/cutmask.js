(function () {
  'use strict';

  var MAX_WORK = 2048;

  function dilate(B, w, h, r) {
    var cur = B;
    for (var k = 0; k < r; k++) {
      var out = new Uint8Array(w * h);
      for (var y = 0; y < h; y++) {
        var row = y * w;
        for (var x = 0; x < w; x++) {
          var i = row + x;
          if (cur[i]) { out[i] = 1; continue; }
          if ((x > 0 && cur[i - 1]) || (x < w - 1 && cur[i + 1]) ||
              (y > 0 && cur[i - w]) || (y < h - 1 && cur[i + w])) {
            out[i] = 1;
          }
        }
      }
      cur = out;
    }
    return cur;
  }

  function parityRegion(B, w, h) {
    var n = w * h;
    var label = new Int32Array(n);
    var queue = new Int32Array(n);
    var roomCount = 0;
    var i, x, y, nb;
    for (i = 0; i < n; i++) {
      if (B[i] || label[i]) continue;
      roomCount++;
      var head = 0;
      var tail = 0;
      queue[tail++] = i;
      label[i] = roomCount;
      while (head < tail) {
        var cur = queue[head++];
        var cx = cur % w;
        var cy = (cur - cx) / w;
        if (cx > 0) {
          nb = cur - 1;
          if (!B[nb] && !label[nb]) { label[nb] = roomCount; queue[tail++] = nb; }
        }
        if (cx < w - 1) {
          nb = cur + 1;
          if (!B[nb] && !label[nb]) { label[nb] = roomCount; queue[tail++] = nb; }
        }
        if (cy > 0) {
          nb = cur - w;
          if (!B[nb] && !label[nb]) { label[nb] = roomCount; queue[tail++] = nb; }
        }
        if (cy < h - 1) {
          nb = cur + w;
          if (!B[nb] && !label[nb]) { label[nb] = roomCount; queue[tail++] = nb; }
        }
      }
    }
    if (roomCount === 0) {
      var R0 = new Uint8Array(n);
      for (i = 0; i < n; i++) R0[i] = B[i] ? 1 : 0;
      return R0;
    }
    var neigh = new Array(roomCount + 1);
    function addEdge(a, b) {
      if (!a || !b || a === b) return;
      if (!neigh[a]) neigh[a] = {};
      neigh[a][b] = true;
    }
    var found = new Int32Array(24);
    for (y = 0; y < h; y++) {
      var y0 = y > 3 ? y - 3 : 0;
      var y1 = y < h - 4 ? y + 3 : h - 1;
      for (x = 0; x < w; x++) {
        i = y * w + x;
        if (!B[i]) continue;
        var x0 = x > 3 ? x - 3 : 0;
        var x1 = x < w - 4 ? x + 3 : w - 1;
        var seen = 0;
        for (var yy = y0; yy <= y1; yy++) {
          var row2 = yy * w;
          for (var xx = x0; xx <= x1; xx++) {
            var l = label[row2 + xx];
            if (!l) continue;
            var dup = false;
            for (var s = 0; s < seen; s++) {
              if (found[s] === l) { dup = true; break; }
            }
            if (!dup && seen < 24) found[seen++] = l;
          }
        }
        for (var ai = 0; ai < seen; ai++) {
          for (var bi = ai + 1; bi < seen; bi++) addEdge(found[ai], found[bi]);
        }
      }
    }
    var contact = new Int32Array(roomCount + 1);
    for (x = 0; x < w; x++) {
      if (label[x]) contact[label[x]]++;
      if (label[(h - 1) * w + x]) contact[label[(h - 1) * w + x]]++;
    }
    for (y = 0; y < h; y++) {
      if (label[y * w]) contact[label[y * w]]++;
      if (label[y * w + w - 1]) contact[label[y * w + w - 1]]++;
    }
    var depth = new Int32Array(roomCount + 1);
    var order = new Int32Array(roomCount + 1);
    for (i = 0; i <= roomCount; i++) depth[i] = -1;
    var head2 = 0;
    var tail2 = 0;
    function seedWallAdj(l) {
      if (l && depth[l] < 0) {
        depth[l] = 1;
        order[tail2++] = l;
      }
    }
    var K2 = 6;
    var seeded = 0;
    for (var ci = 0; ci < 4; ci++) {
      var cnx = (ci === 1 || ci === 3) ? w - 1 : 0;
      var cny = ci >= 2 ? h - 1 : 0;
      for (var dy = 0; dy <= K2; dy++) {
        var yy2 = cny === 0 ? dy : h - 1 - dy;
        if (yy2 < 0 || yy2 >= h) continue;
        for (var dx = 0; dx <= K2; dx++) {
          var xx2 = cnx === 0 ? dx : w - 1 - dx;
          if (xx2 < 0 || xx2 >= w) continue;
          var l2 = label[yy2 * w + xx2];
          if (l2 && depth[l2] < 0) {
            depth[l2] = 0;
            order[tail2++] = l2;
            seeded++;
          }
        }
      }
    }
    if (seeded === 0) {
      var anchor = 0;
      var maxC = 0;
      for (i = 1; i <= roomCount; i++) {
        if (contact[i] > maxC) {
          maxC = contact[i];
          anchor = i;
        }
      }
      if (anchor) {
        depth[anchor] = 0;
        order[tail2++] = anchor;
      }
    }
    if (tail2 === 0) {
      for (x = 0; x < w; x++) {
        if (!label[x] && h > 1) seedWallAdj(label[x + w]);
        if (!label[(h - 1) * w + x] && h > 1) seedWallAdj(label[(h - 2) * w + x]);
      }
      for (y = 0; y < h; y++) {
        if (!label[y * w] && w > 1) seedWallAdj(label[y * w + 1]);
        if (!label[y * w + w - 1] && w > 1) seedWallAdj(label[y * w + w - 2]);
      }
    }
    while (head2 < tail2) {
      var r = order[head2++];
      var ns = neigh[r];
      if (!ns) continue;
      for (var key in ns) {
        var r2 = key | 0;
        if (depth[r2] < 0) {
          depth[r2] = depth[r] + 1;
          order[tail2++] = r2;
        }
      }
    }
    var R = new Uint8Array(n);
    for (i = 0; i < n; i++) {
      if (B[i]) {
        R[i] = 1;
        continue;
      }
      var l = label[i];
      if (l && depth[l] >= 0 && (depth[l] % 2) === 1) R[i] = 1;
    }
    return R;
  }

  function countInterior(B, w, h) {
    var n = w * h;
    var hrun = new Uint8Array(n);
    var run, x, y, i;
    for (y = 0; y < h; y++) {
      run = 0;
      var row = y * w;
      for (x = 0; x < w; x++) {
        i = row + x;
        run = B[i] ? run + 1 : 0;
        if (run >= 5) hrun[i] = 1;
      }
    }
    var interior = 0;
    for (x = 0; x < w; x++) {
      run = 0;
      for (y = 0; y < h; y++) {
        i = y * w + x;
        run = hrun[i] ? run + 1 : 0;
        if (run >= 5) interior++;
      }
    }
    return interior;
  }

  function sealEdges(B, w, h, K) {
    var x, y, xx, yy;
    for (y = 0; y < h; y++) {
      for (x = 0; x < K && x < w; x++) {
        if (B[y * w + x]) {
          for (xx = 0; xx <= x; xx++) B[y * w + xx] = 1;
          break;
        }
      }
      for (x = w - 1; x >= w - K && x >= 0; x--) {
        if (B[y * w + x]) {
          for (xx = x; xx < w; xx++) B[y * w + xx] = 1;
          break;
        }
      }
    }
    for (x = 0; x < w; x++) {
      for (y = 0; y < K && y < h; y++) {
        if (B[y * w + x]) {
          for (yy = 0; yy <= y; yy++) B[yy * w + x] = 1;
          break;
        }
      }
      for (y = h - 1; y >= h - K && y >= 0; y--) {
        if (B[y * w + x]) {
          for (yy = y; yy < h; yy++) B[yy * w + x] = 1;
          break;
        }
      }
    }
  }

  function process(img, docW, docH, modeOverride) {
    var s = Math.min(1, MAX_WORK / docW, MAX_WORK / docH);
    var w = Math.max(4, Math.round(docW * s));
    var h = Math.max(4, Math.round(docH * s));
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    var ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    var data = ctx.getImageData(0, 0, w, h).data;
    var n = w * h;
    var B = new Uint8Array(n);
    var count = 0;
    for (var i = 0; i < n; i++) {
      if (data[i * 4 + 3] > 10) {
        B[i] = 1;
        count++;
      }
    }
    if (count === 0) {
      return { canvas: null, mode: 'empty', coverage: 0, workW: w, workH: h };
    }
    var interior = countInterior(B, w, h);
    var isFill;
    if (modeOverride === 'fill') {
      isFill = true;
    } else if (modeOverride === 'line') {
      isFill = false;
    } else {
      isFill = (interior / count) > 0.10;
    }
    var R;
    if (isFill) {
      R = B;
    } else {
      var B2 = dilate(B, w, h, 1);
      sealEdges(B2, w, h, 4);
      R = parityRegion(B2, w, h);
    }
    var out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    var octx = out.getContext('2d');
    var imgData = octx.createImageData(w, h);
    var od = imgData.data;
    for (var j = 0; j < n; j++) {
      if (R[j]) {
        od[j * 4] = 255;
        od[j * 4 + 1] = 255;
        od[j * 4 + 2] = 255;
        od[j * 4 + 3] = 255;
      }
    }
    octx.putImageData(imgData, 0, 0);
    var soft = document.createElement('canvas');
    soft.width = w;
    soft.height = h;
    var sctx = soft.getContext('2d');
    try {
      sctx.filter = 'blur(1px)';
    } catch (e) {}
    sctx.drawImage(out, 0, 0);
    return {
      canvas: soft,
      mode: isFill ? 'fill' : 'line',
      coverage: count / (w * h),
      workW: w,
      workH: h
    };
  }

  window.FoilUCut = { process: process };
})();
