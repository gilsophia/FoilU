var FoilU = (function () {
  try { app.displayDialogs = DialogModes.NO; } catch (eDD) {}
  var GENMARK = String.fromCharCode(8203);

  function q(s) {
    var t = String(s);
    t = t.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
    return '"' + t + '"';
  }
  function err(e, tag) {
    var m = e && e.message ? e.message : String(e);
    if (tag) m = tag + " -> " + m;
    return '{"ok":false,"error":' + q(shortName(m, 150)) + '}';
  }
  function shortName(s, max) {
    s = String(s);
    if (s.length <= max) return s;
    return s.substring(0, max - 1) + "~";
  }
  function n2(v) {
    var n = Number(v);
    return isFinite(n) ? String(n) : "0";
  }
  function findLayer(container, id) {
    var layers = container.layers;
    for (var i = 0; i < layers.length; i++) {
      var l = layers[i];
      if (l.id === Number(id)) return l;
      if (l.typename === "LayerSet") {
        var f = findLayer(l, id);
        if (f) return f;
      }
    }
    return null;
  }
  function hideDocWindow(d) {
    try {
      if (d.windows && d.windows.length > 0) {
        d.windows[0].visible = false;
      }
    } catch (e) {}
  }

  function setVisibleAll(container, vis) {
    var layers = container.layers;
    for (var i = 0; i < layers.length; i++) {
      var l = layers[i];
      try { l.visible = vis; } catch (e) {}
      if (l.typename === "LayerSet") setVisibleAll(l, vis);
    }
  }
  function revealTarget(container, id, chain) {
    var layers = container.layers;
    for (var i = 0; i < layers.length; i++) {
      var l = layers[i];
      var c = chain.concat([l]);
      if (l.id === Number(id)) {
        for (var k = 0; k < c.length; k++) {
          try {
            c[k].visible = true;
            c[k].opacity = 100;
          } catch (e) {}
        }
        return true;
      }
      if (l.typename === "LayerSet") {
        if (revealTarget(l, id, c)) return true;
      }
    }
    return false;
  }
  function modeName(mode) {
    if (mode === DocumentMode.RGB) return "RGB";
    if (mode === DocumentMode.CMYK) return "CMYK";
    if (mode === DocumentMode.GRAYSCALE) return "Grayscale";
    if (mode === DocumentMode.BITMAP) return "Bitmap";
    if (mode === DocumentMode.LAB) return "Lab";
    if (mode === DocumentMode.INDEXEDCOLOR) return "Indexed";
    if (mode === DocumentMode.MULTICHANNEL) return "Multichannel";
    if (mode === DocumentMode.DUOTONE) return "Duotone";
    return String(mode);
  }
  function collectBySuffix(container, suffix, out) {
    var k = container.layers.length;
    for (var i = 0; i < k; i++) {
      var ly = container.layers[i];
      try {
        if (ly.typename === "LayerSet") {
          if (String(ly.name).indexOf(GENMARK) >= 0) continue;
          collectBySuffix(ly, suffix, out);
        } else {
          var nm = String(ly.name);
          if (nm.length > suffix.length && nm.substr(nm.length - suffix.length) === suffix && /^[0-9]{6}-[0-9]{6}-/.test(nm)) {
            out.push(ly);
          }
        }
      } catch (es) {}
    }
  }

  function getViewRotation() {
    var angle = 0;
    var found = "";
    var info = "";
    function addInfo(s) {
      if (info.length < 130) info += (info ? ";" : "") + s;
    }
    try {
      var ref = new ActionReference();
      ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("viewRotation"));
      ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
      var desc = executeActionGet(ref);
      var key = stringIDToTypeID("viewRotation");
      if (desc.hasKey(key)) {
        angle = Number(desc.getDouble(key));
        found = "direct";
      } else {
        addInfo("direct:noKey");
      }
    } catch (e0) {
      addInfo("direct:err");
    }
    function scan(desc, label) {
      try {
        var n = Number(desc.count);
        var cnt = 0;
        for (var i = 0; i < n && cnt < 6; i++) {
          var k = desc.getKey(i);
          var s = String(k);
          var low = s.toLowerCase();
          if (low.indexOf("view") < 0 && low.indexOf("rot") < 0 && low.indexOf("angle") < 0) continue;
          cnt++;
          var tv = "";
          var t = null;
          try {
            t = desc.getType(k);
            tv = String(t);
          } catch (et) {}
          addInfo(label + s + ":" + tv);
          if (found) continue;
          try {
            if (t === DescValueType.DOUBLETYPE || t === DescValueType.INTEGERTYPE) {
              angle = Number(desc.getDouble(k));
              found = label + s;
            } else if (t === DescValueType.DESCRIPTORTYPE) {
              var sub = desc.getObjectValue(k);
              var ns = Number(sub.count);
              for (var j = 0; j < ns; j++) {
                var ks = sub.getKey(j);
                var ss = String(ks);
                var lo = ss.toLowerCase();
                if (lo.indexOf("rot") < 0 && lo.indexOf("angle") < 0) continue;
                var ts = sub.getType(ks);
                addInfo(s + "/" + ss + ":" + String(ts));
                if (!found && (ts === DescValueType.DOUBLETYPE || ts === DescValueType.INTEGERTYPE)) {
                  angle = Number(sub.getDouble(ks));
                  found = label + s + "/" + ss;
                }
              }
            }
          } catch (ev) {}
        }
        addInfo(label + "n=" + n);
      } catch (e) {
        addInfo(label + "scanErr");
      }
    }
    if (!found) {
      try {
        var ref2 = new ActionReference();
        ref2.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        scan(executeActionGet(ref2), "doc.");
      } catch (e2) {
        addInfo("docErr");
      }
    }
    if (!found) {
      try {
        var ref3 = new ActionReference();
        ref3.putEnumerated(charIDToTypeID("capp"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        scan(executeActionGet(ref3), "app.");
      } catch (e4) {
        addInfo("appErr");
      }
    }
    return '{"ok":true,"angle":' + angle + ',"src":' + q(found) + ',"keys":' + q(info) + '}';
  }

  function isGeneratedName(s) {
    var nm = String(s);
    if (nm.indexOf("\u200b") >= 0) return true;
    return /^[0-9]{6}-[0-9]{6}-/.test(nm);
  }

  function collectByName(container, re, out) {
    var layers = container.layers;
    for (var i = 0; i < layers.length; i++) {
      var l = layers[i];
      var nm = String(l.name);
      if (!isGeneratedName(nm) && re.test(nm)) out.push(l);
      if (l.typename === "LayerSet") collectByName(l, re, out);
    }
  }
  function exportCutLayer(workDir, pattern) {
    var doc = null;
    var dup = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var re = null;
      try {
        re = new RegExp(String(pattern), "i");
      } catch (er) {
        return '{"ok":false,"error":"\u6b63\u5219\u8868\u8fbe\u5f0f\u65e0\u6548"}';
      }
      var matched = [];
      collectByName(doc, re, matched);
      if (matched.length === 0) return '{"ok":true,"found":false}';
      var cutPath = workDir + "/cut.png";
      step = "duplicate";
      dup = doc.duplicate("FoilU_cut", false);
      hideDocWindow(dup);
      if (dup.mode !== DocumentMode.RGB) {
        var cm = changeEnumFor(DocumentMode.RGB);
        if (cm !== null) {
          step = "changeMode(RGB)";
          dup.changeMode(cm);
        }
      }
      step = "isolate";
      setVisibleAll(dup, false);
      for (var i = 0; i < matched.length; i++) {
        var id = matched[i].id;
        if (!revealTarget(dup, id, [])) continue;
        var tl = findLayer(dup, id);
        if (tl && tl.typename === "LayerSet") setVisibleAll(tl, true);
      }
      step = "saveCutPNG";
      dup.saveAs(new File(cutPath), new PNGSaveOptions(), true);
      dup.close(SaveOptions.DONOTSAVECHANGES);
      dup = null;
      var names = "";
      for (var k = 0; k < matched.length && k < 3; k++) {
        if (k > 0) names += ",";
        names += shortName(matched[k].name, 10);
      }
      var w0 = Number(doc.width.as("px"));
      var h0 = Number(doc.height.as("px"));
      return '{"ok":true,"found":true,"names":' + q(names) +
        ',"widthPx":' + n2(w0) + ',"heightPx":' + n2(h0) + '}';
    } catch (e) {
      try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
      return err(e, step);
    }
  }
  function exportPrintLayer(workDir) {
    var doc = null;
    var dup = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var re = new RegExp("\u5370\u5237|\u67c4\u56fe", "i");
      var matched = [];
      collectByName(doc, re, matched);
      if (matched.length === 0) return '{"ok":true,"found":false}';
      var outPath = workDir + "/print.png";
      step = "duplicate";
      dup = doc.duplicate("FoilU_print", false);
      hideDocWindow(dup);
      if (dup.mode !== DocumentMode.RGB) {
        var cm = changeEnumFor(DocumentMode.RGB);
        if (cm !== null) {
          step = "changeMode(RGB)";
          dup.changeMode(cm);
        }
      }
      step = "isolate";
      setVisibleAll(dup, false);
      for (var i = 0; i < matched.length; i++) {
        var id = matched[i].id;
        if (!revealTarget(dup, id, [])) continue;
        var tl = findLayer(dup, id);
        if (tl && tl.typename === "LayerSet") setVisibleAll(tl, true);
      }
      step = "savePrintPNG";
      dup.saveAs(new File(outPath), new PNGSaveOptions(), true);
      dup.close(SaveOptions.DONOTSAVECHANGES);
      dup = null;
      var names = "";
      for (var k = 0; k < matched.length && k < 3; k++) {
        if (k > 0) names += ",";
        names += shortName(matched[k].name, 10);
      }
      var w0 = Number(doc.width.as("px"));
      var h0 = Number(doc.height.as("px"));
      return '{"ok":true,"found":true,"names":' + q(names) +
        ',"widthPx":' + n2(w0) + ',"heightPx":' + n2(h0) + '}';
    } catch (e) {
      try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
      return err(e, step);
    }
  }

  function collectAllLayers(container, out, depth) {
    var layers = container.layers;
    for (var i = 0; i < layers.length; i++) {
      var l = layers[i];
      out.push({ id: l.id, name: String(l.name), depth: depth, group: l.typename === "LayerSet" });
      if (l.typename === "LayerSet") collectAllLayers(l, out, depth + 1);
    }
  }

  function listLayers(workDir, thumbMax) {
    var doc = null;
    var dup = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var list = [];
      collectAllLayers(doc, list, 0);
      var arr = [];
      for (var i = 0; i < list.length; i++) {
        arr.push('{"id":' + list[i].id + ',"name":' + q(shortName(list[i].name, 40)) +
          ',"depth":' + list[i].depth + ',"group":' + (list[i].group ? "true" : "false") + '}');
      }
      var f = new File(workDir + "/layerlist.json");
      f.encoding = "UTF-8";
      f.open("w");
      f.write("[" + arr.join(",") + "]");
      f.close();
      var tm = Number(thumbMax) || 0;
      if (tm > 0) {
        step = "duplicate";
        dup = doc.duplicate("FoilU_thumbs", false);
        hideDocWindow(dup);
        var w0 = Number(dup.width.as("px"));
        var h0 = Number(dup.height.as("px"));
        var s = Math.min(1, tm / Math.max(w0, h0));
        if (s < 1) {
          var tw = Math.max(1, Math.round(w0 * s));
          var th = Math.max(1, Math.round(h0 * s));
          dup.resizeImage(UnitValue(tw, "px"), UnitValue(th, "px"), dup.resolution, ResampleMethod.BICUBIC);
        }
        step = "thumbs";
        for (var j = 0; j < list.length; j++) {
          setVisibleAll(dup, false);
          if (!revealTarget(dup, list[j].id, [])) continue;
          var tl = findLayer(dup, list[j].id);
          if (tl && tl.typename === "LayerSet") setVisibleAll(tl, true);
          try {
            dup.saveAs(new File(workDir + "/thumb_" + list[j].id + ".png"), new PNGSaveOptions(), true);
          } catch (eTh) {}
        }
        dup.close(SaveOptions.DONOTSAVECHANGES);
        dup = null;
      }
      return '{"ok":true,"count":' + list.length + '}';
    } catch (e) {
      try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
      return err(e, step);
    }
  }

  function exportByIds(workDir, fileName, idsCsv) {
    var doc = null;
    var dup = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var parts = String(idsCsv).split(",");
      var ids = [];
      for (var i = 0; i < parts.length; i++) {
        var v = parseInt(parts[i], 10);
        if (!isNaN(v)) ids.push(v);
      }
      if (!ids.length) return '{"ok":false,"error":"\u65e0\u56fe\u5c42ID"}';
      step = "duplicate";
      dup = doc.duplicate("FoilU_exp", false);
      hideDocWindow(dup);
      if (dup.mode !== DocumentMode.RGB) {
        var cm = changeEnumFor(DocumentMode.RGB);
        if (cm !== null) dup.changeMode(cm);
      }
      step = "isolate";
      setVisibleAll(dup, false);
      for (var j = 0; j < ids.length; j++) {
        if (!revealTarget(dup, ids[j], [])) continue;
        var tl = findLayer(dup, ids[j]);
        if (tl && tl.typename === "LayerSet") setVisibleAll(tl, true);
      }
      step = "save";
      dup.saveAs(new File(workDir + "/" + String(fileName)), new PNGSaveOptions(), true);
      dup.close(SaveOptions.DONOTSAVECHANGES);
      dup = null;
      return '{"ok":true}';
    } catch (e) {
      try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
      return err(e, step);
    }
  }

  function setLayersVisible(idsCsv, vis) {
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      var doc = app.activeDocument;
      var parts = String(idsCsv).split(",");
      var n = 0;
      for (var i = 0; i < parts.length; i++) {
        var v = parseInt(parts[i], 10);
        if (isNaN(v)) continue;
        var l = findLayer(doc, v);
        if (l) { l.visible = !!vis; n++; }
      }
      return '{"ok":true,"count":' + n + '}';
    } catch (e) {
      return err(e);
    }
  }

  function changeEnumFor(mode) {
    if (mode === DocumentMode.CMYK) return ChangeMode.CMYK;
    if (mode === DocumentMode.GRAYSCALE) return ChangeMode.GRAYSCALE;
    if (mode === DocumentMode.LAB) return ChangeMode.LAB;
    if (mode === DocumentMode.RGB) return ChangeMode.RGB;
    return null;
  }
  function getDocInfo() {
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      var d = app.activeDocument;
      var wPx = Number(d.width.as("px"));
      var hPx = Number(d.height.as("px"));
      var dpi = Number(d.resolution) || 72;
      var layerId = -1;
      var layerName = "";
      var layerKind = "";
      try {
        if (d.activeLayer) {
          layerId = d.activeLayer.id;
          layerName = d.activeLayer.name;
          layerKind = d.activeLayer.typename;
        }
      } catch (e0) {}
      var psVer = "";
      try { psVer = String(app.version); } catch (ev) {}
      return '{"ok":true,"docName":' + q(shortName(d.name, 18)) + ',"layerId":' + layerId +
        ',"layerName":' + q(shortName(layerName, 12)) +
        ',"widthPx":' + n2(wPx) + ',"heightPx":' + n2(hPx) + ',"dpi":' + n2(dpi) +
        ',"mode":' + q(modeName(d.mode)) + ',"bits":' + n2(d.bitsPerChannel) +
        ',"psv":' + q(shortName(psVer, 12)) + '}';
    } catch (e) { return err(e); }
  }
  function exportAssets(workDir, previewMax, maskMax) {
    var doc = null;
    var dup = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      if (!doc.activeLayer) return '{"ok":false,"error":"\u6ca1\u6709\u9009\u4e2d\u56fe\u5c42"}';
      var layerId = doc.activeLayer.id;
      var maskPath = workDir + "/mask.png";
      var flatPath = workDir + "/flat.png";
      var w0 = Number(doc.width.as("px"));
      var h0 = Number(doc.height.as("px"));
      step = "duplicate";
      dup = doc.duplicate("FoilU_temp", false);
      hideDocWindow(dup);
      if (dup.mode !== DocumentMode.RGB) {
        var cm = changeEnumFor(DocumentMode.RGB);
        if (cm !== null) {
          step = "changeMode(RGB)";
          dup.changeMode(cm);
        }
      }
      step = "hideLayers";
      setVisibleAll(dup, false);
      if (!revealTarget(dup, layerId, [])) throw new Error("\u5728\u526f\u672c\u4e2d\u627e\u4e0d\u5230\u6240\u9009\u56fe\u5c42");
      var targetLayer = findLayer(dup, layerId);
      if (targetLayer && targetLayer.typename === "LayerSet") setVisibleAll(targetLayer, true);
      var ms = 1;
      if (maskMax > 0) ms = Math.min(1, maskMax / Math.max(w0, h0));
      var maskW = w0;
      var maskH = h0;
      if (ms < 1) {
        step = "resizeMask";
        maskW = Math.max(1, Math.round(w0 * ms));
        maskH = Math.max(1, Math.round(h0 * ms));
        dup.resizeImage(UnitValue(maskW, "px"), UnitValue(maskH, "px"), dup.resolution, ResampleMethod.BICUBIC);
      }
      step = "saveMaskPNG";
      dup.saveAs(new File(maskPath), new PNGSaveOptions(), true);
      var hasFlat = false;
      if (previewMax > 0) {
        step = "mergeVisible";
        setVisibleAll(dup, true);
        try { dup.mergeVisibleLayers(); } catch (em) {}
        var cw = Number(dup.width.as("px"));
        var ch = Number(dup.height.as("px"));
        var s = Math.min(1, previewMax / Math.max(cw, ch));
        if (s < 1) {
          step = "resizeFlat";
          var nw = Math.max(1, Math.round(cw * s));
          var nh = Math.max(1, Math.round(ch * s));
          dup.resizeImage(UnitValue(nw, "px"), UnitValue(nh, "px"), dup.resolution, ResampleMethod.BICUBIC);
        }
        step = "saveFlatPNG";
        dup.saveAs(new File(flatPath), new PNGSaveOptions(), true);
        hasFlat = true;
      }
      step = "closeTemp";
      dup.close(SaveOptions.DONOTSAVECHANGES);
      dup = null;
      var dpi = Number(doc.resolution) || 72;
      return '{"ok":true,"hasFlat":' + (hasFlat ? 'true' : 'false') +
        ',"maskW":' + maskW + ',"maskH":' + maskH +
        ',"widthPx":' + w0 + ',"heightPx":' + h0 + ',"dpi":' + n2(dpi) +
        ',"layerId":' + layerId + '}';
    } catch (e) {
      try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
      return err(e, step);
    }
  }
  function placeLegacy(doc, f, layerName, scale, target, expLeft, expTop) {
    var opened = null;
    try {
      opened = app.open(f);
      var cm2 = changeEnumFor(doc.mode);
      if (cm2 !== null && opened.mode !== doc.mode) opened.changeMode(cm2);
      try {
        var prof = doc.colorProfileName;
        if (prof && String(prof).length > 0) opened.convertProfile(prof, Intent.RELATIVECOLORIMETRIC, true, false);
      } catch (e3) {}
      opened.selection.selectAll();
      opened.selection.copy();
      opened.close(SaveOptions.DONOTSAVECHANGES);
      opened = null;
      app.activeDocument = doc;
      doc.activeLayer = target;
      doc.paste();
      var nl = doc.activeLayer;
      nl.name = layerName;
      if (scale < 0.9999) nl.resize(100 / scale, AnchorPosition.TOPLEFT);
      try {
        var b = nl.bounds;
        var dx = Number(expLeft) - Number(b[0].as("px"));
        var dy = Number(expTop) - Number(b[1].as("px"));
        if (Math.abs(dx) > 0.01 || Math.abs(dy) > 0.01) {
          nl.translate(new UnitValue(dx, "px"), new UnitValue(dy, "px"));
        }
      } catch (eb) {}
      return nl;
    } catch (eL) {
      try { if (opened) opened.close(SaveOptions.DONOTSAVECHANGES); } catch (e4) {}
      throw eL;
    }
  }

  function placeResult(pngPath, layerName, scale, layerId, expLeft, expTop, replaceSuffix, pngW, pngH) {
    var doc = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var f = new File(pngPath);
      if (!f.exists) throw new Error("\u6e32\u67d3\u7ed3\u679c\u6587\u4ef6\u4e0d\u5b58\u5728");
      var target = null;
      try { target = findLayer(doc, layerId); } catch (e1) {}
      if (!target) target = doc.activeLayer;
      if (replaceSuffix && String(replaceSuffix).length > 0) {
        step = "replaceOld";
        var olds = [];
        collectBySuffix(doc, String(replaceSuffix), olds);
        for (var oi = 0; oi < olds.length; oi++) {
          try { if (olds[oi].id !== layerId) olds[oi].remove(); } catch (eo) {}
        }
      }
      try { doc.activeLayer = target; } catch (ea) {}
      var nl = null;
      var usedLegacy = false;
      var plcErr = "";
      try {
        step = "placeFile";
        var idPlc = charIDToTypeID("Plc ");
        var dPlc = new ActionDescriptor();
        dPlc.putPath(charIDToTypeID("null"), f);
        dPlc.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
        var dOfst = new ActionDescriptor();
        dOfst.putUnitDouble(charIDToTypeID("Hrzn"), charIDToTypeID("Pxl"), 0);
        dOfst.putUnitDouble(charIDToTypeID("Vrtc"), charIDToTypeID("Pxl"), 0);
        dPlc.putObject(charIDToTypeID("Ofst"), charIDToTypeID("Ofst"), dOfst);
        executeAction(idPlc, dPlc, DialogModes.NO);
        nl = doc.activeLayer;
        if (!nl || (target && nl.id === target.id)) throw new Error("\u7f6e\u5165\u672a\u751f\u6210\u56fe\u5c42");
        step = "rasterize";
        try { nl.rasterize(RasterizeType.ENTIRELAYER); } catch (er) {}
        nl.name = layerName;
        step = "resizeLayer";
        var pw = Number(pngW) || 0;
        var ph = Number(pngH) || 0;
        var sc = Number(scale) || 1;
        if (pw > 0 && sc > 0.0001) {
          try {
            var b0 = nl.bounds;
            var curW = Number(b0[2].as("px")) - Number(b0[0].as("px"));
            var curH = Number(b0[3].as("px")) - Number(b0[1].as("px"));
            var tgtW = pw / sc;
            if (curW > 0.5 && curH > 0.5) {
              var fct = (tgtW / curW) * 100;
              if (Math.abs(fct - 100) > 0.05) nl.resize(fct, AnchorPosition.TOPLEFT);
            }
          } catch (ez) {}
        } else if (sc < 0.9999) {
          nl.resize(100 / sc, AnchorPosition.TOPLEFT);
        }
        step = "alignLayer";
        try {
          var b = nl.bounds;
          var dx = Number(expLeft) - Number(b[0].as("px"));
          var dy = Number(expTop) - Number(b[1].as("px"));
          if (Math.abs(dx) > 0.01 || Math.abs(dy) > 0.01) {
            nl.translate(new UnitValue(dx, "px"), new UnitValue(dy, "px"));
          }
        } catch (eb) {}
      } catch (ePlc) {
        plcErr = String(ePlc && ePlc.message ? ePlc.message : ePlc);
        step = "legacyPlace";
        nl = placeLegacy(doc, f, layerName, Number(scale) || 1, target, expLeft, expTop);
        usedLegacy = true;
      }
      return '{"ok":true,"layerName":' + q(nl.name) + ',"layerId":' + nl.id + ',"legacy":' + (usedLegacy ? 'true' : 'false') +
        ',"plcErr":' + q(shortName(plcErr, 40)) + '}';
    } catch (e) {
      return err(e, step);
    }
  }
  function groupGenerated(groupName, idsCsv) {
    var doc = null;
    var step = "start";
    try {
      if (app.documents.length === 0) return '{"ok":false,"error":"\u6ca1\u6709\u6253\u5f00\u7684\u6587\u6863"}';
      doc = app.activeDocument;
      var parts = String(idsCsv).split(",");
      var ids = [];
      for (var i = 0; i < parts.length; i++) {
        var v = parseInt(parts[i], 10);
        if (!isNaN(v)) ids.push(v);
      }
      if (!ids.length) return '{"ok":false,"error":"\u65e0\u56fe\u5c42ID"}';
      step = "hideOld";
      for (var h = 0; h < doc.layers.length; h++) {
        var top = doc.layers[h];
        try {
          if (top.typename === "LayerSet" && String(top.name).indexOf(GENMARK) >= 0) top.visible = false;
        } catch (eh) {}
      }
      step = "group";
      var grp = doc.layerSets.add();
      grp.name = groupName;
      grp.move(doc, ElementPlacement.PLACEATBEGINNING);
      var prev = null;
      for (var k = 0; k < ids.length; k++) {
        var ly = null;
        try { ly = findLayer(doc, ids[k]); } catch (ef) {}
        if (!ly) continue;
        if (!prev) ly.move(grp, ElementPlacement.INSIDE);
        else ly.move(prev, ElementPlacement.PLACEAFTER);
        prev = ly;
      }
      try { grp.collapsed = true; } catch (ec) {}
      return '{"ok":true,"id":' + grp.id + ',"count":' + ids.length + '}';
    } catch (e) {
      return err(e, step);
    }
  }

  return {
    getDocInfo: getDocInfo,
    exportAssets: exportAssets,
    exportCutLayer: exportCutLayer,
    exportPrintLayer: exportPrintLayer,
    placeResult: placeResult,
    getViewRotation: getViewRotation,
    listLayers: listLayers,
    exportByIds: exportByIds,
    setLayersVisible: setLayersVisible,
    groupGenerated: groupGenerated
  };
})();
